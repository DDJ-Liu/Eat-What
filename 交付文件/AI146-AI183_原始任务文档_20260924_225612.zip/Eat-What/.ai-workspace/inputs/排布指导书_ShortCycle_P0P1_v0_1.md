# 场景排布指导书 · ShortCycle_P0P1 · v0.1

> 定位：C6 闸门要求的单场景"施工图"，供 C-T5（场景重构+复原验证）及后续段3/4 排布任务作为 inputs 引用。服从附录 A 通则；实例问题以本书为准。
> 依据：需求基准 v1.3（待升 v1.4 的结论已并入）、schema v2.1（v2.2 结论已并入）、三张有效参考图、美术资产包（2026-08-31）、附录 A 转写稿 v0。
> 尺度：目标分辨率 2560×1440；基准 PPU 100；正交相机 size 7.2 → 单屏世界视野 25.6 × 14.4 单位。
> 状态：v0.1（S1 纸面复原三轮校准后）。带 `_TUNE` 的对象=AI 粗排、用户终调。
> **v0.1 变更**：§三数值改为 PSD 源文件真值+参考图实测；出画原则；图标画布统一缩放；托盘固定锚点与线索板区块 8 锚点结构（R-05）；描边配置表；LayoutTools 适用范围修正。

---

## 一、层级定位判定表（C1-4）

| 元素类别 | 判定 | 渲染载体 |
|---|---|---|
| 食谱本全部件、封面、卡片、便签、按钮 | 场景内容 | SpriteRenderer |
| 冰箱猫、格架格件、名称标签、托盘、GO 狗、返回箭头 | 场景内容 | SpriteRenderer |
| 线索板结构与内容（卡、线、气泡、涂鸦） | 场景内容 | SpriteRenderer + LineRenderer/分段 sprite |
| 所有文字（菜名、标签、文案、数字、TIPS） | 场景内容文本 | 世界空间 TextMeshPro（裸挂或 TMP 被动容器） |
| ⑤步骤详情 modal、通用 modal、悬停小卡 | 场景内容（跟随所在空间） | SpriteRenderer + TMP |
| HUD | **空集**（demo P0-P1 无钉屏元素） | — |

Canvas 清单预期：0 个 Screen Space；World Space 仅在 TMP 需容器时出现，须逐个声明"TMP 被动容器"。

## 二、从属结构树（功能组一级 + 关键对象二级）

```
ShortCycle_P0P1（单根可选，demo 期不加）
├─ CameraAndStageMarkers
│   ├─ Main Camera（正交 size 7.2，PixelPerfect 可选）+ Directional Light
│   ├─ CamMarker_Phase1_Left / CamMarker_Phase0_Center / CamMarker_RightReserved
│   └─ ClueBoardAnchor_Phase0 / ClueBoardAnchor_Phase1
├─ Managers
│   ├─ SessionManager（显性 FSM：Phase0/Phase1/Phase2 + Phase0 子状态 Cover/Browse/Catalog/ClueBoard/StepDetail）
│   ├─ InventoryManager（聚合入口绑定）/ PlayerProfileManager / UnlockManager（桩）/ KitchenEquipmentManager（占位）
│   ├─ CameraPanController / InputLockController / ActionRouter
│   └─ DataProcessor（统一数据处理）/ SaveBoundary（占位）
├─ InteractionLayers
│   ├─ Layer_Phase0 / Layer_Phase1 / Layer_Modal（各含用途说明）
├─ Spaces
│   ├─ Phase0_RecipeBook（中屏）
│   │   ├─ Book_Base（ui_caipu_dibu）/ Book_Pages（ui_caipu_dibushangmian）
│   │   ├─ Cover_Group（默认 inactive）：CoverArt【缺】+ Bubble_01/02（气泡件【缺】+TMP）+ 点击翻开交互
│   │   ├─ Browse_Group（①页，默认 active）
│   │   │   ├─ LeftPage：Title（kuang1 底 + TMP）/ DishPhoto（zhaopian 框 + 变体 display_sprite）/ IngredientList（VerticalLayout 点位 → IngredientCard prefab：小卡底+图标+×N TMP）/ StickerNotes（GridLayout 点位 → Sticker prefab：tag 底+TMP 或 sticker_sprite）/ StarNotes_Deco（装饰）/ StartCooking_Button（kaishizuofan1 底 + kaishizuofan 字 + Button_MouseInteract）/ Favorite_Button【缺星标】/ OpenClueBoard_Button【缺】/ StepDetail_Button
│   │   │   └─ RightPage_Reserved（空，dibushangmian 右半承担）
│   │   ├─ Catalog_Group（③页，默认 inactive）：CatalogGrid_Left / CatalogGrid_Right（GridLayout 2×2 点位 ×2，镜像）→ CatalogCard prefab（pailide 框 + 成品图 + 菜名 TMP + 彩签点位×2（note_tags 前 2）+ Button_MouseInteract）；UnknownCard prefab【缺问号卡】；翻页接口预留（FlipAnchor_L/R，无实现）
│   │   ├─ CatalogTab_Button（目录页签【缺】）/ Escape_Button（ESC【缺】）
│   ├─ Phase1_Kitchen（左屏）
│   │   ├─ FridgeCat_Group
│   │   │   ├─ CatBody（zhutu，内建 3 层格架）/ EyeGlow（yanguang，眨眼调度接入）/ Deco_Lines（xian1~4）
│   │   │   ├─ ShelfSlots（每层 5 列点位，可视 2 层（第 3 层被托盘遮），GridLayout 生成或手工定点均可 → FridgeSlot prefab：格件结构 + icon_sprite（系数 0.62）+ 名称标签（biaoqian 底+TMP+自适应）+ 数量角标 TMP + 占位符态 + Drag/Hover 组件）※ 每层格数待 S1-01 裁决（4 或 5）
│   │   │   ├─ FilterBar_TUNE（筛选 tag 按钮阵列，HorizontalLayout）/ TidyButton_TUNE【缺】
│   │   │   └─ ScrollRegion（MouseScrollableObject；拆段资产到位前滚动=格架内容滚动，猫身不拉长）
│   │   ├─ Tray_Group
│   │   │   ├─ TrayBase（tuopan）/ TraySlots：**20 个手工定点锚点 TraySlot_01~20（5×4 非规则排布，相对托盘固定，不用 GridLayout，`_TUNE`）** → 各挂 TraySlot prefab / CapacityText_TUNE（TMP「已用/20」）
│   │   │   ├─ GoDog_Button_TUNE（kaishigou + Button_MouseInteract，三态视觉程序生成）
│   │   │   └─ TrayStateMachine（显性 FSM：Collapsed/Highlight/Detail，视觉待引擎内定）
│   │   ├─ ClueBoard_Group（随 Phase 平移变位，锚点见 CameraAndStageMarkers）
│   │   │   ├─ Board（ban）/ Clip（ban1）/ Paper（zhi）/ DarkBoard（ban2，便签板）
│   │   │   ├─ Content：SlotBlocks（按 T1.slots 序纵向排布 → **SlotBlock prefab**：Center 组[标准食材图标（系数 0.60）+ ActionIcon（standard_action 图标位，资产缺）+ Title TMP（T4.name_key）] + **SubSlot_01~08 固定锚点**（围绕中央非规则布局，按 T2.sub_01~08 顺序填 SubCard prefab：biaoqian3 底+图标（系数 0.19）+ 持有/需求 TMP + 未解锁剪影；不足留空）+ Node（空置节点）+ Link（每食材一段连线，随该食材满足红/绿））/ TipsBubble（固定文案 TMP）/ Deco（涂鸦装饰层）
│   │   │   └─ Collapse/Expand 状态容器
│   │   ├─ Return_Button（zhifanhui + Button_MouseInteract）/ EquipmentEntry_Button【缺】（→ 通用 modal「请期待正式版」）
│   └─ RightReserved（右屏，空组）
├─ Shared
│   ├─ StepDetailModal（遮罩 + 卡 + VerticalLayout 步骤行：TMP + 方/圆图标）/ GenericModal / HoverCard（TMP×3）
└─ DebugAndReferences（默认 inactive）
    ├─ Probe_ShortCycleAutomated（拆自 Presenter）/ Ref_Reference_P0 / Ref_Reference_P1 / EvidenceText
└─ EventSystem（唯一，仅为 TMP/新输入系统）
```

## 三、空间排布（数值来源：PSD 源文件位置表 + 参考图 10% 网格实测；单位为画面百分比，2K 下 1% W=25.6 px、1% H=14.4 px）

**排布原则**
1. **出画许可**：大型素材按参考实际尺寸放置，允许大幅超出画布被裁（猫身、托盘、夹板、纸均如此），不为"完整入画"缩小。
2. **缩放分类**：图标类（ui_shicai_/ui_caipin_/ui_tag_/ui_gongju_）按 512 画布统一系数缩放，不裁可见区，保留作者相对比例；结构件按可见区（alpha bbox）缩放（Sprite Mesh Tight、按 bounds 定位）。
3. 三段横向布局：Phase1_Kitchen 左屏（x=−25.6）、Phase0_RecipeBook 中屏（x=0）、RightReserved 右屏（x=+25.6）；镜头平移，空间原地不动。

**Phase 1 左屏（备菜界面-P1）**
| 元素 | 中心/锚定 | 尺寸 | 角度 | 备注 |
|---|---|---|---|---|
| 便签深色板 ban2 | (81%, 18%)，顶边贴顶 | 宽 37.5% | 0 | 最底层 |
| 冰箱猫 zhutu | 躯干中心 (42%, 50%)；头顶贴顶（−3% H） | 猫身填充宽 51% W（整体含臂爪约 85% W，高约 150% H，脚出画） | 0 | 可视两层格架 |
| 眼光 yanguang | 眼位 (35.5%, 12%) / (60%, 12%) 相对猫 bbox | 宽=猫宽 16% | — | Additive |
| 格架图标行 | y 41% / 67%；x 24.5 / 31.5 / 39.5 / 45.5 / 53% | 系数 0.62（512→317 px） | — | 每层格数待 S1-01 |
| 名称标签底 | y 55% / 79%，x 同上 +2% | 134×90 px | — | 长名走 TextFitter |
| 对白气泡 ×2 | (4.9%, 21.3%) / (14.4%, 23.6%) | 222×230 / 260×227 px | +8 / +6 | 资产缺 |
| 托盘 tuopan | **右缘 62.4% W、顶缘 70.9% H**，左/下出画 | 整宽约 80% W | 0 | 20 锚点相对托盘固定 |
| GO 狗 kaishigou | (58%, 85%) | 宽 17% W | 0 | 摆位 `_TUNE` |
| 夹板 ban | (81%, 64.7%) | 高 104% H（宽约 36% W） | +5 | 底部出画 |
| 纸 zhi | 左对齐板内框、顶 15.5% H | 高 88% H（横版按高铺、右溢出画外） | +5 | S1-18 待确认 |
| 夹子 ban1 | (79%, 14.5%) | 宽 18% W | +5 | 在纸之上 |
| 区块 SlotBlock ×2 | 中心 (80%, 42%) / (80%, 75%) | 标准食材系数 0.60；SubSlot 锚点相对中心 (−14,+7)(−8,+4)(−12.5,+16)(−7,+15)(+6,+12)(+10.5,+10)(+9,0)(+13,+18)（%W,%H） | 卡 −3 | 做法图标位 (+12.5, −8) |
| 之字连线/节点 | 节点 (82%,45%) (66%,55%) (82%,73%)；端点 (96%,27%) (96%,62%) | 线宽 9 px | — | 程序件 |
| TIPS 底 | (88.5%, 55%) | 21% W × 10% H | 0 | 固定文案 |
| 返回箭头 / 筛选栏 / 一键整理 / 厨具入口 | 参考图未出现 | — | — | 位置人工定 `_TUNE` |

**Phase 0 中屏 ①页（P0-P1 参考左半）**
| 元素 | 中心 | 尺寸 | 角度 |
|---|---|---|---|
| 书底 dibu / 双页 dibushangmian | (52.5%, 48.5%) / (53%, 49%) | 宽 87% / 84% W | 0 |
| 目录页签（缺） | (8%, 18%) | 10% × 12% | −4 |
| 当前菜谱小签（缺） | (9%, 32.5%) | 8% × 7% | 0 |
| 标题底 kuang1 + 标题 TMP | (42.5%, 12.5%) | 宽 19% W | 0 |
| 便签 tag + TMP | (23%, 15%) | 宽 14% W | +8 |
| 成品照 zhaopian + 变体图 | (30.5%, 34.5%) | 框宽 27% W；菜品照系数由框内宽 80% 决定 | +5 |
| 透明胶 ×3 | (22%,45%) / (40%,17%) / (43.5%,24%) | 高 10~11% H | −35 / +55 / +80 |
| 星注装饰 | (48%,35%) (49.5%,44%) (48%,53%) (44.5%,58%) | — | −6~−10 |
| 清单底 kuang2 + 图标 2×2 | (24%, 61.5%)；图标 (17%/26.5%, 58.5%/66%) | 底宽 19% W；图标系数 0.27 | 0 |
| 开始做饭 kaishizuofan1 + 字 | (43%, 77.5%) / (41.5%, 77.5%) | 宽 18% / 8.5% W | −3 |
| 右页 | 留空（dibushangmian 右半） | — | — |
| 星标 / 打开冰箱 / ESC（缺） | (47%,12%) / (20%,83%) / (5%,92%) | 小件 | — |

**Phase 0 中屏 ③页（P0-P1 参考右半，双页镜像）**
| 元素 | 数值 |
|---|---|
| 目录卡 pailide ×8 | 宽 15% W；中心 x 22.5 / 39.5 / 64.5 / 81.5%，y 29 / 67.5% |
| 卡内菜品照 | 卡宽 70%，顶距卡高 9% |
| 菜名底 kuang3 + TMP | 卡中心 +11.5% H，宽=卡宽 72% |
| 彩签 ×2 | 卡右缘外 (+6.6% W, −4% H) / (+6.6%, +2%)，读 note_tags 前 2 |
| 透明胶 | 卡左上 (−5.5%, −12.5%) +60°；右下 (+5%, +13%) −50° |
| 封面态 ⓪ | 整书覆盖同区域；封面图+两气泡缺 |

**图标缩放系数汇总（512 画布）**：格架 0.62｜托盘 0.62｜清单 0.27｜线索板中央 0.60｜线索板替代卡内 0.19｜目录卡菜品照 ≈0.65（随卡）｜⑤页方/圆图标 ≈0.25。

## 四、人工段预留（`_TUNE` 清单）

GoDog_Button / CapacityText / FilterBar / TidyButton / **TraySlot_01~20 锚点** / **SubSlot_01~08 锚点** / 便签点位 / 成品照倾角 / 格件缩放与行距 / 返回箭头位 / 厨具入口位 / 三段机位精确 x 与平移曲线 / 目录卡彩签数量上限 / **全部描边 Group 的 thickness 与颜色终值**。

## 五、排布工具

- 阵列点位：`Tools/LayoutTools` 仅用于**规则阵列**——GridLayout（目录 8 卡、格架列）、VerticalLayout（食材清单、步骤行、线索板区块纵向序）、HorizontalLayout（筛选栏）。**托盘 20 锚点与区块 8 替代锚点为手工定点，不用工具生成。**
- **描边配置（SpriteOutline2D，按位置分 SpriteOutlineGroup2D；颜色默认 #0F0C0B；thickness=目标屏幕px÷显示缩放，起始值 `_TUNE`）**：

| Group | 元素 | 显示缩放 | 目标屏幕 px | thickness 起始值 |
|---|---|---|---|---|
| FridgeSlots | 格架/托盘食材图标 | 0.62 | 8 | 13 |
| ClueCenter | 线索板中央标准食材 | 0.60 | 6 | 10 |
| ClueCards | 替代卡内小图标 | 0.19 | 2 | 11 |
| IngredientList | ①页清单小图标 | 0.27 | 3 | 11 |
| DishPhoto | ①页成品照 | ≈1.2 | 14 | 12 |
| CatalogCards | 目录卡框 pailide + 卡内菜品照 | 卡 ≈0.35 / 照 ≈0.65 | 8 / 8 | 23 / 12 |
| TrayBase | 托盘 | 按可见区 ≈0.82 | 10 | 12 |
| GoButton | GO 狗 | ≈0.30 | 12 | 32（触上限→建议 256 版或屏幕像素模式） |
| ClueBoardBase | 夹板底 | ≈1.3 | 10 | 8 |
| HoverHighlight | 悬停态 | — | 基础 +4 px，色 #F2C14E | Group 切换 |
> 不描边：便签、透明胶、拍立得内透明胶、猫身/眼睛/帽（已内嵌）、文字（TMP 自带 Outline，标题白色 halo）。若引擎内仍不还原，改为交付"需描边元素清单"由用户手调。
- 文本：TMP 世界空间；名称标签接 FridgeIngredientLabelTextFitter。
- 交互：Button_MouseInteract（+ColorSprite/ScaleCurve 视觉件）、MouseDraggableObject/DropZone（+DropTag）、MouseScrollableObject/HoverTrigger；事件经 MouseActionBinding→ActionRouter。
- 过渡：Transition 家族（封面翻开、modal 出入场）。

## 六、资产依赖与占位规则

- 全部资产名以 CK01-J 基线（重跑后）为准；本书标【缺】的资产在到位前用统一占位图 + `AIGC 临时替代` 或纯色块占位，不阻塞排布。
- 冰箱猫拆段资产到位前：可视 2 层（第 3 层被托盘遮），容量 20 需滚动；到位后接拉长机制。每层格数待 S1-01 裁决。
- 导入：图标 Mesh Type Tight；结构件因导出含 17% 透明外边距（S1-17），排布按 bounds 而非 rect；内嵌旋转素材（S1-16 表）先用 `_straight` 转正版。

## 七、复原验收口径（S1）

- C-T5 完成后产出三张实机截图：`P0_Browse`（①页，含右页留空）、`P0_Catalog`（③页 8 卡）、`P1_Kitchen`，分别与 P0-P1 参考图左半/右半、备菜界面-P1 对照。
- 验收项：构图与 §三数值一致（误差 ≤2% W/H）；各元素归属与从属树一致；描边 Group 齐全；缺资产处占位可辨识；`_TUNE` 清单对象齐全可检索；差异清单只记纸面不可验项（排序/描边终值/字体自适应/平移随动/交互命中），作为 S2 v0.1 与指导书 v1 输入。
