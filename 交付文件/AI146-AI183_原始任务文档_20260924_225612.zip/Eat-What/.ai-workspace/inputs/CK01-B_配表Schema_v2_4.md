# CK01-B 配表 Schema v2.4

版本：v2.4  
日期：2026-09-10  
适用任务：AI-000077 / B-T9

## 1. 继承与边界

本版继承 Schema v2.3 的全部既有列、ID 域、列表分隔符和导入约定，仅增加本文件列出的字段与跨表规则。`DataTables/` 仍是唯一权威源；生成的 ScriptableObject、场景槽位和 Unity 内运行结果不属于本 CODE 段验收范围。

## 2. T1 Recipes：工序白名单

- 新增必填列 `whitelist_proc_ids`。
- 类型为 T12 `ProcessingRecords.record_id` 的列表引用，分隔符为 `;`，至少一项，不允许空元素或重复项。
- 三道 demo 菜谱的权威白名单：
  - `rcp_qingtang_noodle`：`proc_noodle_boiled;proc_noodle_boiled_alt;proc_qingtang_final`
  - `rcp_tomato_egg`：`proc_egg_liquid;proc_egg_liquid_giant;proc_tomato_cut;proc_scrambled_egg;proc_tomato_egg_final;proc_tomato_egg_soup`
  - `rcp_kaishui_cabbage`：`proc_cabbage_washed;proc_clear_broth;proc_kaishui_final`
- 白名单只形成只读数据契约；本版不实现 P2 的候选命中或裁决行为。

## 3. T8/T4/T9：不明物体与 demo 容量

- T8 `CookingGameConfig` 必须包含：
  - `unknown_product_item=prd_unknown`
  - `demo_fridge_capacity_level=fcap_lv2`
- T4 `Items` 必须包含 `prd_unknown`，并引用名称/描述本地化键。
- T9 `Localization` 必须包含这两个键，文件保持 UTF-8 无 BOM、CRLF。
- T10 `FridgeCapacityLevels` 中 `fcap_lv2.capacity=30`；运行时容量只能通过 catalog 配置与容量档解析，不允许用库存记录数代替容量。

## 4. T14 KitchenAreas：动作与承载约束

- 新增必填列 `allowed_actions` 与 `allowed_carriers`。
- 两列均用 `|` 分隔，不允许空元素或重复项。
- `allowed_actions` 引用 T11 动作；`allowed_carriers` 只允许 carrier/facility ID，并必须包含该区域 `core_facility`。
- demo 权威值：
  - Prep：`act_whisk|act_cut|act_wash`；`tool_board_station|tool_board|tool_bowl`
  - Stove：`act_boil|act_whisk|act_stirfry|act_wash|act_stew`；`tool_stove|tool_pot|tool_pan`
  - Oven、Salad、Freezer：`act_wash`；各自仅包含本区 core facility。

## 5. V-01～V-12

| 规则 | 断言 |
|---|---|
| V-01 | 菜谱白名单字段存在、列表非空、ID 唯一且均引用 T12 |
| V-02 | 每个 T3 `trigger_items` / `permanent_trigger_items` 项均被至少一条白名单 T12 记录的 `output_item` 覆盖；允许 T12 被多菜复用 |
| V-03 | 每道菜的终局加工记录必须被白名单覆盖 |
| V-04 | 同一菜谱/区域/输入能由多个承载物命中时报告 warning |
| V-05 | `unknown_product_item` 存在且解析到 T4 |
| V-06 | 不明物体名称与描述本地化键存在 |
| V-07 | demo 容量配置存在、档位可解析且容量为正 |
| V-08 | T14 允许动作均可解析，列表无空项/重复项 |
| V-09 | T14 允许承载物均合法且包含 core facility |
| V-10 | 从菜谱声明原料/主料出发做正向可达检查，未进入触发链则 warning |
| V-11 | 从终局记录反向追溯时，触发输入无声明来源则 warning |
| V-12 | 在正向可达报告中逐条并列记录 V-10 全局可达与白名单限定可达结果；仅作报告对照，不生成独立 warning/error |

V-02 与 V-03 是本阶段强制为零的覆盖/终局遗漏哨兵。V-12 是报告字段而非 warning 计数规则；其余 warning 必须写入报告并说明，不能静默丢弃。

## 6. 额外审计报告

校验器除既有报告外固定生成：

- `CK01-B_recipe-whitelist-coverage-report.json`
- `CK01-B_multi-candidate-carrier-report.json`
- `CK01-B_forward-reachability-report.json`
- `CK01-B_reverse-reachability-report.json`

## 7. 运行时只读面

`CK01GeneratedDataCatalog` 对外提供以下只读面：

- `TryGetRecipeWhitelist`、`TryGetAreaConstraint`、`TryGetUnknownProductResolver`、`TryGetDemoFridgeCapacity` 保持兼容的 `bool + out + diagnostic` 契约；前三项仅为后续 P2 接线预留。
- `public string UnknownProductItemId { get; }` 复用 `TryGetUnknownProductResolver`，正常权威配置返回 `prd_unknown`。
- `public int DemoFridgeCapacityLevel { get; }` 复用 `TryGetDemoFridgeCapacity`，正常权威配置返回 `30`。
- 两个属性均不设置硬编码兜底；配置缺失、引用无效或容量不合法时抛出带原 `diagnostic` 的 `InvalidOperationException`，以显式暴露配置失败。

返回模型为只读视图，不得由调用方反写导入资产，也不得另建配置缓存或第二数据源。

## 8. Q-01b 容量与层级契约

- Bind/rebind 层数为 `ceil(capacity / 5)`；容量 30 对应 6 层。
- `ApplyFilterView` 层数为 `max(1, ceil(visibleCount / 5))`，当前生产代码无调用方。
- 库存记录数量不得作为容量；数量小于等于 0 的记录不占槽。
- 过滤、缩层和重绑后，选中层与槽位必须恢复到合法范围。
- 编辑器外边界覆盖 0/1/5/6/30、上界、缩层与恢复。

## 9. Unity 后续边界

AI-000078 负责 Unity 导入、生成资产核验、冰箱场景槽池从 15 扩到 30、六层接线、只读布局审计、Play Mode、Console 与人工确认。本任务不修改 `.unity`、`.prefab`、`.asset`、`.meta`，也不进入 Unity/MCP。

## 10. 变更记录

- v2.4：增加菜谱工序白名单、厨房区域动作/承载约束、不明物体配置、demo 容量绑定、V-01～V-12、四类审计报告和 Q-01b 只读运行时契约。
- v2.4 API 收口（AI-000082）：补齐 `UnknownProductItemId` / `DemoFridgeCapacityLevel` 只读属性，明确 V-02 的 T3→白名单 T12 产出覆盖语义与 V-12 的报告对照属性。
