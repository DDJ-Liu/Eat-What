# USER_WORK_STATUS · 人工工作项状态（权威源）

> 位置：`.ai-workspace/inputs/USER_WORK_STATUS.md`（常驻输入，不随阶段归档；随内容分支入库）。
> 状态词：TODO / DOING / DONE / BLOCKED。你可直接编辑本文件，或在派发 chat 发 `USER-Ux <状态> <日期>` 由控制台写入；两者落到同一文件。
> 日报心跳每日 00:00 读取；AI 支撑任务领取前预检 dependsOn 的 USER 项，未 DONE 则等待（不熔断）。

| 编号 | 人工工作 | 覆盖条目（追踪表 v1.2.1） | 状态 | 完成日期 | 备注 |
|---|---|---|---|---|---|
| USER-U1 | 正式配表内容配置（14 表 demo 口径，§3 范围） | 人工前置=配表/配表+排布 全部 | TODO | | 最急；每轮导出后触发 A1 |
| USER-U2 | 排布·P0 食谱本（封面/目录卡/①页/小签/ESC/页签） | M2-B1-R2/R3、M3-B1-R1、M4-B1-R2/R3、M4-B2-R3 | TODO | | 前置 A2a，后置 A2b |
| USER-U3 | 排布·P1 托盘与格架（托盘/20 锚点/三态/GO 狗/容量/格件/整猫/_ScaleComp） | M7-B1-R1/R3、M7-B3-R1、M6-B1-R5/R6 | TODO | | |
| USER-U4 | 排布·线索板与镜头（④ 展开态/SubSlot 回写/TIPS/机位/平移） | M5-B1-R3、M1-B5-R2、M8-B1-R1 | TODO | | 前置 F2-a ④ 补图（H-04） |
| USER-U5 | 白名单与分区约束复核（whitelist 3/6/3、T14；补 G2-ref） | M9-B2-R1/R2 | TODO | | 依赖 U1 |
| USER-U6 | 文案定稿（4 条待对齐 + prd_unknown.flavor） | M1-B4-R5 | TODO | | 可选 |
