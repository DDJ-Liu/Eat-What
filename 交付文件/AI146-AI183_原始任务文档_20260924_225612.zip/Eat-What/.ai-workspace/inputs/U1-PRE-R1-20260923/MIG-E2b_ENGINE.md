# MIG-E2b [ENGINE_MCP] 长期验证资产保GUID更名与收尾复验

接力补充：AI171同时修正ShortCycleLayoutAudit中AI169后过时的P0Left=-12.8预期（AI169实际=-9.6）。完成编译后以真实Editor只读核对marker数值和`fixT5FourMarkers=True`，其它布局/字体审计独立保留。不要为迁就旧断言回滚AI169布局；若真实布局变化与移交不符，留证按CODE/ENGINE职责修正。此复验不触发额外场景保存或重复PRE1 Build。
共同执行约束：领取 CORE.md、当前任务卡及对应 worker；按 SUPERVISED.md 使用同一 PowerShell 7 宿主和真实 TaskId/DispatchToken，生产写入批次前 SupervisionCheckpoint。目标 D:/GameProject/Eat-What、codex/unity6-followup、Unity 6000.3.24f1。读 inputs/U1-PRE_人工反馈与字体批准_20260923.md；最新用户授权优先于旧待批准文本。保留所有已有修改、错误/恢复史，不 Reset 成功任务，不提交/推送，不手改 Unity YAML/meta。输出 outputs/U1-PRE-R1/<TaskId>/，六要素报告、真实工具计量，不估算 provider token；Complete/Fail 后回传 supervisorHandoff 并结束，由控制台派下一棒。人工审查后置但不代签。
依赖MIG-E2a。执行已审定的F05功能更名，不删除验证能力。读E2a精确移交/当前MIG63临时项、G26与清理协议。
允许Assets改动表：通过AssetDatabase.MoveAsset将 Assets/Editor/MIG63Validation/ 四脚本及其meta保GUID移动为 Assets/Editor/ProjectValidation/ 下 E2a已实现对应功能名；将 Assets/Scripts/Spine_Package/Avatars/Tomato/Tomato_MIG63.controller 移为同目录 Tomato_Reference.controller（若有冲突/独有引用先核对）。只做批准资产更名和Editor生成目录/meta，保持对象身份、动画状态/参数/曲线、引用语义。旧空Editor目录仅确认已空且无引用后由AssetDatabase删除目录meta，未知项保留。不得文字修改YAML或手工改GUID。
写前备份目标+meta与入引用资源指纹；先只读GUID/引用/内存与保存状态。执行后编译，EditorAPI复核两保存Spine场景引用同GUID、菜单/四探针入口工作，滚轮/Modal、Tomato双路径、两保存场景（含重复进退）相关探针各一次，保护正式scene/字体StaticSHA、Dynamic清空、Console/引用/退出Editclean；不重新要求用户手感验收、不重做本轮已完成PRE1 Build，除非这次验证发现实际问题。相关截图只存档。
E2a源码若有缺陷交CODE修复，不直接扩大运行时脚本或业务范围；没有改业务功能的前提以机器复验结算。本卡不删D:/GameProject/Eat-What-U6、不碰Hub/共享服务/EditorPrefs/字体guard或Git。输出保GUID/引用前后表、实际工具菜单与使用文档、归档增量证据清单，回传控制台执行E2最终持久化/安全清理条件核对。只有实际最终条件全部满足，控制台才可关E2；本卡SUCCEEDED不等于迁移生命周期已全部结束。
