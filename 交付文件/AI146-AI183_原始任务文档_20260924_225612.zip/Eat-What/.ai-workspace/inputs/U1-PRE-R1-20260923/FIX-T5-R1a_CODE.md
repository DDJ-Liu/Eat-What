# FIX-T5-R1a [CODE] 镜头锚定与线索板持续显示
共同执行约束：领取 CORE.md、当前任务卡及对应 worker；按 SUPERVISED.md 使用同一 PowerShell 7 宿主和真实 TaskId/DispatchToken，生产写入批次前 SupervisionCheckpoint。目标 D:/GameProject/Eat-What、codex/unity6-followup、Unity 6000.3.24f1。读 inputs/U1-PRE_人工反馈与字体批准_20260923.md；最新用户授权优先于旧待批准文本。保留所有已有修改、错误/恢复史，不 Reset 成功任务，不提交/推送，不手改 Unity YAML/meta。输出 outputs/U1-PRE-R1/<TaskId>/，六要素报告、真实工具计量，不估算 provider token；Complete/Fail 后回传 supervisorHandoff 并结束，由控制台派下一棒。人工审查后置但不代签。
一个目标：修复空间切换后固定控件和共享结构的表现归属；几何重配由R1b执行。

代码改动清单：
| 文件 | 处置 | 改动/归属/工具层三问 |
|---|---|---|
| Assets/Scripts/Tools/Layout/CameraViewportAnchor.cs（若目录契约要求可放Tools，报告实际路径） | 新建 | 通用Tools；TK-MOT-04只跟虚拟机中心不合需求，TK-DBG-01已有ViewportToWorldPoint；显式camera/viewport/深度或平面/内边距，最小无业务依赖工具 |
| Assets/Scripts/Cooking/ShortCycle/Presentation/ShortCycleSpace.cs、ShortCyclePresentationSet.cs及Runtime/ShortCyclePresentationDirector.cs | 最小修改 | TK-MOT-06+TK-DBG-05；显式持续共享结构视觉，与focus/互动分离；默认行为兼容，不让所有Shared/Modal常亮 |
| DevTools/ShortCycle/ShortCycleCoreTests.cs、UnityStubs.cs、Test-CK01CShortCycle.ps1及必要锚点测试 | 扩充 | TK-DBG-04；真实相机/父变换几何与切换时序断言；不弱化现有测试 |
| Assets/Editor/ShortCycle/ShortCycleLayoutAudit.cs | 必要扩充 | TK-DBG-03；只读实测布局/viewport/启用集合，不能与写入共用target当actual |
| 组件说明文档/镜头视口锚定_配置与复用说明.md及索引、两项目入口相关节、toolkit | 新建/更新 | 说明camera/viewport/深度/时序/启停、按钮状态门控、配置点和限制；登记新工具空闲编号 |

读C1/C2/C4/C6、G26/G68/G69及TK-INT-01/02/03/17/18，TK-MOT-04/06，TK-LAY-02/08。先检查真实类/调用点；禁止推翻架构、改MouseManager已验收Modal/滚轮方向、改FridgeCatRig、硬编码本轮世界X。
锚定视觉+Collider所在对象同移；在CameraPan更新后保持camera-relative，无一帧拖尾，支持初次enable/再进入、aspect和ortho变化、父transform非原点。不在每帧Find/相机查找；保持Z/scale与按钮状态可见规则。bounds缓存/IsInView不得被跟相机按钮污染造成书或整个厨房的缩放偏移；必要排除锚定控件bounds，解释依据。
持续线索板：核实WantsActive/LeaveSpace/MergeVisibility/Traveler/ApplyVisibility的实际因果；只明确指定物理板结构，不放开无焦点业务交互；中途/取消/反向/重复跨P0-P1不得出现Deactivate->Activate。后台交互仍受层栈、焦点、Modal及过渡锁拦截。保护AI165④保留书页压暗和板外返回。
测试：移动/zoom/aspect/父变换锚点位置、重复enable、跨空间过渡逐阶段可见与focusfalse、Modal不穿透。ShortCycle profile必要回归；CODE不改scene/Prefab/meta或调用Unity。交付R1b明确Inspector字段和建议锚点（参考既有左下角安全距离，不把故障位置当目标）。

