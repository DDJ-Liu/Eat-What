# PRE-1c-MATERIAL-RESOLUTION-R1 [CODE] TMP加载材质解析与批准磁盘引用的一致性修复

目标：修复AI170 attempt5中TMP自动材质归一化与批准前态核验的冲突，仍拒绝真正的范围/字段/资源漂移。本任务只修改原字体迁移工具与回归，不迁移、不改批准CSV，不在Editor执行任何业务。

## 入口与实际证据

读CORE、SUPERVISED、workers/CODE、TK-LOC-03、P-036/P-047/P-048、两份项目文档页首/Fonts模块，inputs/U1-PRE_人工反馈与字体批准_20260923.md和U1-PRE_Lab60_增量批准与接力_20260924.md，AI179源码与报告。不重跑成功前置。

AI170 attempt5真实schema6/v3预览，两种合法加载状态结果一致：raw231/rows191/unique161，executeAllowed=false，40条SOURCE_DRIFT/MATERIAL_GLOBAL_ID及1条覆盖不足；未进入诊断/Begin、事务、备份或生产写入。40项为ShortCycle_P0P1的TraySlot_01_TUNE～20_TUNE各NameLabel/BadgeLabel。批准期望SourceHan材质GlobalObjectId_V1-3-53ffd732c8bc2034f93d5a714c25eda2-12569091968840867831-0；运行Editor读到WithFallback默认材质GlobalObjectId_V1-3-75909fc3d0fa2c94baa5706654d37655-9052723641695353799-0。磁盘原引用和两CSV不变。

证据：
- outputs/U1-PRE-R1/AI-000170/attempt-5-prefab-reference-r1/：两个真实预览及阻断报告。
- outputs/control/U1-PRE-R1-20260923/ai170-attempt5-controller-material-probe.json：控制台重发现精确MCP实例、路径/Unity6000.3.24f1后只读当前loaded场景，40项全部是上述默认材质。4样例的font GUID=75909...，expectedMaterial可解析但其_MainTex与font atlas不同；actualMaterial恰等于font.material，property.prefabOverride=false、所读覆盖列表没有这两个目标字段。没有保存/刷新/加载/赋值调用。
- ai170-attempt5-owner-probe.json：TraySlot01两TMP为真实Prefab实例，owner targetPrefabId=1485991313，source存在。不能因GetPropertyModifications结果空而认为非Prefab。
- ai170-attempt5-baseline-check.json：14源码/批准/生产/meta哈希一致，三目标材质和备份不存在。
- 实际安装包 Library/PackageCache/com.unity.ugui@b996e7548785/Runtime/TMP/TextMeshPro.cs 的LoadFontAsset约980～986行：当材质_MainTex与font.atlasTexture不匹配时改m_sharedMaterial=font.material；Awake/OnValidate等调用链需核实。只读该包，不修改PackageCache/Library或TMP生命周期。此为实证方向，不能直接把所有差异标可接受。

TraySlot.prefab磁盘两TMP原font为75909...、material为SourceHan(fileID -5877652104868683785，对应无符号GlobalObjectId 12569091968840867831)；场景/Prefab/批准三者实际逐项身份须复核。signed本地fileID与GlobalObjectId unsigned表达不能截断或用long失败后置空。

## 允许修改

Assets/Editor/Fonts/ShortCycleFontSwapTool.cs、DevTools/Fonts/FontSwapDryRunHarness.cs、Test-FontSwap.ps1及必要既有夹具；对应Fonts README、TK-LOC-03及两份项目文档。仍用现工具/公开API，不新迁移器。CODE不操作Unity/MCP，不写scene/prefab/asset/material/meta、CSV/批准旁证、生产备份/manifest；不改runtime/队列实现、不Git。

## 必要实现与停止条件

1. 明确区分批准CSV前态、真实磁盘序列化引用/继承或override、Editor加载后的有效引用，不能拿CSV值直接充当观察值，也不能直接把当前effective材质填入批准原件。用现有真实资产身份、保存源/实例关系、字段与文件SHA建立逐行证据，覆盖全231行/7资源，检查相同对象/组件槽位。若需读取Unity YAML只能严格只读解析并绑定准确文档fileID/引用/GUID/父Prefab与override，禁止正则模糊匹配同名对象、禁止写YAML；优先可靠Editor API公开证据。没有可靠来源时明确拒绝，不能猜。
2. 只有磁盘前态精确匹配原批准、font前态匹配、期望材质存在且其atlas确与font不匹配、effective恰为该font默认材质，并且源/实例/显式override结构、保存SHA均一致时，才可记录受限TMP加载归一化。不得接受任意material mismatch、未知覆盖、真实磁盘变化、错误font、第三方材质、缺失资产或范围外对象；必要可限定到实际证明的精确40条，并在后继诊断逐条实证。未证明条件必须失败关闭，不为了计数231忽略理由。
3. 授权目标和材质风格仍取原批准映射及真实已审旧材质，不得因effective为WithFallback而把FromSourceHan替换成FromLegacy/Heavy风格或新建第4份。配对写font+material后两者atlas应一致，不能靠暂禁TMP生命周期/重写缓存/隐藏对象规避检查。
4. 同一前态双视图须贯穿Preview、Begin的二次现场核验、固定事务、批前/批后行覆盖、去重与源传播、非目标指纹以及完整/幂等回退。实际materialOverride与显式保存override须分清，不因加载后值不同虚构原override。回退必须恢复精确保存引用/继承与override、非目标及7资源/meta/SHA；加载后TMP合法解析状态单独解释，不能保存归一化结果覆盖已批准磁盘基线。现有样例/全量备份manifest保全及失败现场保持。分析现有所有调用点，不能只修改Preview让Begin或回退再次无条件失败。
5. 如果可靠还原或证明原磁盘/内存关系做不到，交可审阅精确差异与已排除方案并Fail/TASK；不得降低SOURCE_DRIFT/全行覆盖/原批准守卫或自行扩大批准。此任务不授权改变非目标样式、字体atlas、Renderer、布局、140wrap等。
6. 回归使用生产共用核心：批准raw与effective不同但全部约束成立时可解释；真实raw/文件SHA漂移、错误默认材质/atlas条件、显式override变化、其它对象/缺失/无符号ID等拒绝。样例回退、分批继承传播与全量失败恢复须覆盖受归一化行的前后状态；保留原171、Lab60/231/7资源、内部Prefab引用v3稳定身份、原普通字段/引用漂移等有效断言。版本/旧计划失效策略明确，不能续跑attempt1～5旧计划。
7. 正常PS7窄测后一次Fonts Final，额外Final说明理由；Unity6/TMP真实DLL编译。离线不能模拟真实TMP生命周期需明确告知，不以夹具代签Editor。公开诊断应输出全231批准行的raw/effective/normalizationReason和归属证据，供后继真实Editor读回；不能只报告总数。
8. 后继仍现主Editor/MCP，不起主工程batch、不停共享Editor、不保存未知dirty。恢复后新attempt-6-material-resolution-r1，新schema实际预览→两轮全231行/7资源真实重载诊断→样例完整回退→公开分批。原5视图/CoverTitle/Lab滚轮/Static SHA/Dynamic清空/Console/Edit clean/Play-Build与manifest PENDING_REVIEW、不Git保持。若新增真实范围变化，停止提交精确差异，不修改两个CSV规避。

## 编排与产物

依赖179/177/169成功项，不反依赖失败170。资源unity-project/font-assets/workflow-devtools。AI170保留PAUSED_CIRCUIT、5错误/6issue/4恢复，当前稳定ProblemKey=pre1_unity6_tmp_material_resolution_drift，尚无本key恢复；此根因有独立材质解析实证，不是给原指纹key换名。原指纹家族两次恢复（含EXECUTION）照旧计数，全任务总4/上限6继续累计。CODE完成后控制台核源/测试/公开移交才决定Recover原170，不能自行恢复或另建迁移任务。

固定D:/GameProject/Eat-What，exec_command显式shell=C:/Users/DDJ/.cache/codex-runtimes/codex-primary-runtime/dependencies/native/powershell/pwsh.exe；直接queue.ps1，不Windows5/降低ExecutionPolicy。按检查点/租约执行。输出outputs/U1-PRE-R1/<TaskID>/，六要素报告、源码SHA、真实runner及公开移交，provider token/model不可得null+原因。Complete/Fail的handoff原样回控制台并结束。
