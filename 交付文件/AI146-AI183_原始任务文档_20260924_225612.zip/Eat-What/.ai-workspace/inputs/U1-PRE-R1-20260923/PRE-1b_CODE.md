# PRE-1b [CODE] 字体配对迁移工具扩充
共同执行约束：领取 CORE.md、当前任务卡及对应 worker；按 SUPERVISED.md 使用同一 PowerShell 7 宿主和真实 TaskId/DispatchToken，生产写入批次前 SupervisionCheckpoint。目标 D:/GameProject/Eat-What、codex/unity6-followup、Unity 6000.3.24f1。读 inputs/U1-PRE_人工反馈与字体批准_20260923.md；最新用户授权优先于旧待批准文本。保留所有已有修改、错误/恢复史，不 Reset 成功任务，不提交/推送，不手改 Unity YAML/meta。输出 outputs/U1-PRE-R1/<TaskId>/，六要素报告、真实工具计量，不估算 provider token；Complete/Fail 后回传 supervisorHandoff 并结束，由控制台派下一棒。人工审查后置但不代签。
串行位：已成功FIX-T5a/原PRE1工具之后；本卡只实现工具与干跑，不进行正式场景或Prefab迁移、不控制Editor。

代码改动清单（三问依据TK-LOC-03，复用已有工具而非另建字体体系）：
| 文件 | 处置 | 改动/归属/复用判断 |
|---|---|---|
| Assets/Editor/Fonts/ShortCycleFontSwapTool.cs | 扩充 | Editor层；读取批准CSV及授权旁证，真实身份去重，3材质副本、全量预检、配对写入、事务/回退及非目标指纹；复用现Preview/Execute兼容审计 |
| DevTools/Fonts/Test-FontSwap.ps1 | 新建 | 编辑器外runner；复用Fonts编译入口与fixture，不启动Unity，检查171去重/漂移、材质参数与回退幂等 |
| DevTools/Fonts/内最小测试夹具及必要Fonts runner/Verify-All配置 | 扩充 | 仅本任务测试接入；复用TK-DBG-04/TK-LOC-03，不镜像实现断言 |
| CODEBASE_MAP.md/项目基线、toolkit/LOC.md及INDEX | 更新相关节 | 新API/安全边界文档；保留完整复核日期 |

读TK-LOC-03、G70、P-001/P-036/P-038及Fonts相关坑，现Preview/Execute真实源码和调用点、批准草案/171CSV。受批准字段/备份路径逐条以共同输入为准。清单按asset+真实对象+组件序号锁定，重复行/不存在/源不匹配/不兼容必须先输出，不用宽搜索扩scope。CoverTitle源字体例外仅批准该对象。
先全量预检font/material/atlas匹配再任何业务引用写入；executeAllowed只能从真实全量结果计算，不信任外部布尔。复制三旧material全部风格，仅换四atlas项；不修改旧材质/字体。处理Prefab传播、实例override重叠及回滚顺序，不能将同一对象重写后误判源漂移。执行/回退幂等，未知非目标差异停写，事务记录批次、身份、 before/after及新增资产归属；失败不得只丢日志返回成功。
验收：Test-FontSwap.ps1 exit0，171原始条目和真实去重计数；漂移列逐项原因；材质风格保留/四atlas参数、预检拒绝零写入、部分失败回退/重复回退、非目标指纹验证。真实DLL编译，Fonts profile一次Final。交付可由ENGINE运行的只读Editor API复核入口/表，真实Editor复核在PRE-1c的正式写入之前，CODE报告不得伪记Editor通过。生产迁移0条。SOURCE有问题按真实Fail，不用静态测试冒充171真实对象校验。

