# MIG-E2a [CODE] 迁移证据归档与长期工具改名准备

## AI169接力补充：长期布局审计的过时基线

本轮源码审查发现`Assets/Editor/ShortCycle/ShortCycleLayoutAudit.cs`的`fourMarkerPositionsValid`仍硬编码P0Left=-12.8，故最新布局误报False。将此明确的验证工具维护并入本卡：读取AI169报告/geometry.csv与当前实际场景，核实P0Left=-9.6，更新这一过时预期及解释，保留P1=-25.6/Center=0/Right=25.6和其余有效断言；不得取消整项检查或将任意当前位置作为期望值。若正式布局在此之前有新的获准变化，按真实新证据解释，不盲写-9.6。仅C#和说明维护，不移动业务对象/修改YAML；使用受影响的现有编译/验证入口，AI172以真实Editor只读审计核对。将这项加入源码改动清单及Editor移交，修复前后的假阳性证据保留。
共同执行约束：领取 CORE.md、当前任务卡及对应 worker；按 SUPERVISED.md 使用同一 PowerShell 7 宿主和真实 TaskId/DispatchToken，生产写入批次前 SupervisionCheckpoint。目标 D:/GameProject/Eat-What、codex/unity6-followup、Unity 6000.3.24f1。读 inputs/U1-PRE_人工反馈与字体批准_20260923.md；最新用户授权优先于旧待批准文本。保留所有已有修改、错误/恢复史，不 Reset 成功任务，不提交/推送，不手改 Unity YAML/meta。输出 outputs/U1-PRE-R1/<TaskId>/，六要素报告、真实工具计量，不估算 provider token；Complete/Fail 后回传 supervisorHandoff 并结束，由控制台派下一棒。人工审查后置但不代签。
前置：本轮两类修复的机器执行完成，避免备份活动文件竞争。F-α已按真实用户结论关闭，FIX-T5和PRE1仍有独立人审，不伪称E2完成。

代码改动清单：
| 文件 | 处置 | 归属与复用三问 |
|---|---|---|
| Assets/Editor/MIG63Validation/MIG63ValidationSession.cs | 功能名调整准备 | Editor通用回归；复用现会话/恢复/字体保护，拟ProjectValidationSession；本卡不移动Assets文件或meta |
| 同目录MIG63WheelProbe.cs/MIG63TomatoProbe.cs/MIG63SpineSceneProbe.cs | 类/菜单及引用功能名调整准备 | 复用TK-DBG-09/TK-DBG-08既有滚轮/双Spine/保存场景回归，不减断言；拟WheelInputRegressionProbe/TomatoAnimationRegressionProbe/SpineSavedSceneRegressionProbe |
| DevTools/MIG63/README.md及查实引用它的脚本/文档 | 功能目录迁移 | 拟DevTools/ProjectValidation；使用原工具，不另建平行验证器；记录旧路径恢复映射 |
| DevTools/Workflow/Archive-Stage.ps1（仅确有需要）及MIG63归档脚本/manifest | 扩充/新建 | 复用TK-WF归档机制，SHA/原路径/版本/restore验证，不清空活动队列或输入 |
| MIG63台账/临时项/E1H接力、AGENTS、两项目文档、toolkit | 当前结论维护 | 旧事实进archive，保留全部失败史和验收真实性 |

必读MIG63/迁移基线.md§8/E2、执行台账页首、临时项登记各项、E1H后续F01–10及H后分支接力、Archive-Stage既有归档实现；只读检查独立副本D:/GameProject/Eat-What-U6及异盘备份，不写副本/系统配置。
交付1：原工程和独立迁移侧M0–M4/C/E1/H/F输入输出、批准/错误/恢复记录完整清单，形成 .ai-workspace/archive/MIG63_<实际日期>/ 可恢复包与manifest(SHA256/原路径/当前替代路径)，实际读回解包抽验或全量核验。复用已有包避免复制巨大缓存；列明未持久化和活跃排除项。原始唯一副本/未推送证据保持；活跃U1 inputs/runtime/INSTRUCTIONS/队列历史、字体新任务backup与独立ART基线不删除，不把“归档成功”写成已推送。
交付2：F05长期工具功能命名的源码/菜单/调用方准备与精准Editor移交表。四Editor脚本目标目录 Assets/Editor/ProjectValidation/；类名上述对应，若非static且Unity绑定敏感先保护映射/解释。Tomato_MIG63.controller目标同目录Tomato_Reference.controller，保GUID。本卡只修改C#文本/DevTools文档，不移动或修改Assets序列化/meta；下一ENGINE用AssetDatabase移动。保留所有功能/历史证据引用可追溯，源码预先引用新目标时必须明确待ENGINE恢复验证，不引入编译中断。
交付3：逐项临时项解除/保留原因及最终清理候选：MIG专属进程/Hub条目/clone/本地phase保护（字体guard长期保留）、包与远端持久化情况。主Editor/MCP/Claude共享配置/许可/2022安装不操作。Spine Examples/Tomato/Lab/探针/backup分支及tags保留；历史SourceHan/TMP备份不冒删。最终删除副本须归档已获准推送并远端可验证、无未知或独有成果；本任务无Git授权，只交具体待执行清单与验证，不强行达到“目录已删除”。
完成Code编译/受影响runner、归档恢复检查及diff，回报现阶段E2尚余ENGINE资产迁移与最终持久化/安全清理边界。不新建空任务占号，不创建用户提醒日程，不提前清除保护钩子。后续无关Mac/产品命名/客户端/MCP评估以具名延期项接管，不阻断已通过F、不谎称已实现。
