# PRE-1c-LAB60 [CODE] 批准补充映射与双场景迁移事务

目标：扩充现有TK-LOC-03，使原171行及用户新增批准的Lab60行在同一受控迁移事务内完整覆盖，公开API可供AI170执行预检、单样例/回退和分批迁移。本任务仅源码、离线干跑；生产资源迁移0。

## 必要入口

先读 `.ai-workspace/CORE.md`、`.ai-workspace/workers/CODE.md`、`.ai-workspace/SUPERVISED.md`、`.ai-workspace/inputs/U1-PRE_Lab60_增量批准与接力_20260924.md`；原批准见 `.ai-workspace/inputs/U1-PRE_人工反馈与字体批准_20260923.md`。项目文档页首及Fonts模块、`.ai-workspace/toolkit/LOC.md` TK-LOC-03、`.ai-workspace/pitfalls/CODE.md` P-036/P-047、`.ai-workspace/ENGINEERING_CONVENTIONS.md` C1～C4相关边界按需读取。已成功AI176报告为 `.ai-workspace/outputs/U1-PRE-R1/AI-000176/AI-000176_PRE-1c-PREFAB-R1_修复报告.md`。新阻断真实计划在 `.ai-workspace/outputs/U1-PRE-R1/AI-000170/attempt-2-prefab-r1/approved-plan.json`；精确草案、CSV及只读资产交叉核对在 `.ai-workspace/outputs/control/U1-PRE-R1-20260923/` 的 PRE1_Lab60_增量迁移审批草案.md、PRE1_Lab60_增量迁移草案.csv、ai170-lab-scope-inspection.json。

## 代码改动清单

| 文件 | 处置 | 改动要点/归属层 | 工具层三问结论 |
| --- | --- | --- | --- |
| Assets/Editor/Fonts/ShortCycleFontSwapTool.cs | 扩充 | Editor字体工具；独立补充映射及批准绑定，231行/7资源事务、备份、预检、传播守卫、公开执行/恢复 | TK-LOC-03已有；在原入口扩充；不新增平行迁移器 |
| DevTools/Fonts/FontSwapDryRunHarness.cs、DevTools/Fonts/Test-FontSwap.ps1及必要既有Fonts夹具 | 扩充 | 离线回归；双场景、原/补输入哈希和覆盖、回退、未批准传播拒绝 | 复用现有runner及真实Unity6/TMP DLL，不新建测试框架 |
| DevTools/Fonts/README.md、.ai-workspace/toolkit/LOC.md、CODEBASE_MAP.md、项目整体阅读理解与推进基线_2026-08-14.md | 修改相关段 | 接口、覆盖计数、恢复调用及尚待Editor验证 | 维护现有入口，不改完整复核日期 |

## 实施与验收

1. 原CSV SHA EB0CED01C1BBB0050DCF30BAA3D5354E9F2C7326C3DF97375DE87467D8FE347B、补充CSV SHA E8AA50B24E3ACA11E55D21F752EB92CD801B83960F443DF12E199DBC1B33A579 原样绑定。补表列与原表不同，按实际列解析、核身份和before/after；历史PENDING_USER由真实批准旁证覆盖，不写回CSV。若内部需要归一化，必须从两个不可变输入生成且逐行可溯源，不复制成可任意编辑的第三批准源。
2. 允许范围精确为原6资源+Assets/Scenes/ToolTests/FridgeScrollLab.unity的60项。总raw/row coverage=231，unique由真实对象决定；不能仅删除171常量或关闭未批准传播检查。原171模式若保留，不得默认吸收Lab；不带增量授权/哈希不符/多一行/缺一行/未知路径/源对象或before引用不符均拒绝。新材质仍仅原3份。
3. 固定事务覆盖全部批准行/来源/源关系/override结构及两场景和5Prefab的文件与非目标指纹，备份7资源及meta。保留AI176身份等价合并、实例先于源、逆序回退、逐批未完成/已完成状态检查。两场景暂开与恢复的Editor生命周期安全需真实源码支持；不得保存或覆盖其它已脏场景。单样例只写1个真实FromSourceHan TMP，源传播不可扩散样例。
4. 原60项fontInherited=true、materialOverridden=true、材质SourceHan GUID53ffd732c8bc2034f93d5a714c25eda2/fileID -5877652104868683785。回退恢复继承和对应material override，不仅写回相同数值。保留不属于本事务的新资产/改动，回退幂等且失败留证，旧事务版本明确兼容或安全拒绝，不复用AI170旧事务。
5. 有意义回归：231覆盖与去重追溯；增量缺授权/哈希及路径漂移拒绝；批准60之外传播仍拒绝；两场景+源传播的实例优先/分批恢复；样例1对象且完全回退；第二场景写入中失败后全事务回退、重复回退、非目标/外部漂移拒绝；原171输入未变；7资产+meta进入备份且恢复完整。不降低已有断言，不以只搜源码代替事务核心验证。
6. 正常PowerShell7运行窄回归后一次Fonts Final；必要第二次说明新原因。编译使用真实6000.3.24f1/TMP DLL。报告真实runner exit、覆盖和材质参数断言；交付ENGINE可直接调用的公开API/参数、计划计数解释、两个场景备份/重入/回退与旧事务处置，禁止反射private、伪造executeAllowed或手改事务。

固定工程D:/GameProject/Eat-What；exec_command显式shell为 C:/Users/DDJ/.cache/codex-runtimes/codex-primary-runtime/dependencies/native/powershell/pwsh.exe，直接调用queue，不嵌套Windows5、不降低ExecutionPolicy。依赖AI176/AI169（均已成功），不得反依赖失败AI170。持有unity-project/font-assets/workflow-devtools，领取真实票据后每批写入前checkpoint、长任务续租。CODE不调用Unity Editor、不写scene/prefab/asset/material/meta、字体manifest、CSV或生产备份，不执行正式迁移/配表。已有修改全部保留，不Git。

产物 `.ai-workspace/outputs/U1-PRE-R1/<TaskID>/`，源码SHA/测试/交接与真实可观测用量落盘，provider不可得写null原因。报告六要素，说明纯工具通过不等于Editor/画面通过；无需新增人工门。Complete/Fail返回supervisorHandoff原样发回控制台并结束。AI170只在控制台审核本任务后正式Recover，既有失败与恢复历史保留。
