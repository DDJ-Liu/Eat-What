# PRE-1b-R1 [CODE] 补齐样例与逐批迁移的受控入口
2026-09-23控制端接力审查。AI167的离线测试及零生产写入事实保留，不重跑整个成功任务、不Reset；本卡是用户已批准PRE-1b/c范围内必要的接续修正。控制端实读ExecuteApprovedMigration(string taskId,...transactionPath)：每次重预览全部171项，直接ApplyLiveEntries(plan.entries,false)全量执行，未提供样例/批次选择与恢复入口；PRE-1c要求“任选1条FromSourceHan→回退基线→全量分批、每批检查点”，因此必须先补API，不让ENGINE用反射调用private、修改已批准CSV/伪造executeAllowed/复制另一套裸写实现绕过工具。
同轮发现DevTools/Verify-All.ps1调用runner强制-ExecutionPolicy Bypass，与SUPERVISED完整协议“使用既有正常执行权限、不降低ExecutionPolicy”不符。既有测试结果不伪写失败，不抹除原命令/报告；本卡把本次迁移验证入口恢复常规PS7执行，真实权限拒绝走正式审批，不能换通道绕过。

必读CORE、CODE worker、SUPERVISED完整协议、inputs/U1-PRE_人工反馈与字体批准_20260923.md、原PRE-1b/1c任务卡、AI167报告及Fonts真实源码/调用点。TK-LOC-03、G70、P-001/P-036/P-038及对应字体/序列化坑。生产写入前SupervisionCheckpoint，普通PS7固定路径，输出outputs/U1-PRE-R1/<TaskID>/。不操作Editor、不写Unity序列化资源/meta、不提交推送；保留所有旧输出/错误。

代码改动清单与工具层三问：
| 文件 | 处置 | 归属/依据/改动 |
|---|---|---|
| Assets/Editor/Fonts/ShortCycleFontSwapTool.cs | 扩充 | 复用TK-LOC-03/AI167事务，不另建架构；全量真实预检后，对批准身份显式选择样例/批次，返回后可做下一批监管检查；累计事务与恢复、全量收尾校验 |
| DevTools/Fonts/FontSwapDryRunHarness.cs、Test-FontSwap.ps1及必要Fonts测试入口 | 扩充 | 同一生产核心有意义验证样例/分批/回退/漂移拒绝，不能只测外观字符串 |
| DevTools/Verify-All.ps1 | 最小修改 | TK-WF统一验证器：只移除强制-ExecutionPolicy Bypass，保留PS7选取、exitcode传播、计量、最多两次Final规则；不改系统/用户策略 |
| DevTools/Fonts/README.md、项目导航/基线/LOC工具登记必要段 | 更新 | 写出ENGINE调用顺序与返回状态；不覆盖历史实际命令，不改完整复核日期 |

验收约束：
1. 批准CSV固定原SHA/171条、6资源/3材质/CoverTitle限定不变。外部选择项只允许来自当次真实完整预检与真实唯一身份；空集、超范围、伪造身份、重复、未知before/after或非目标漂移均拒绝零写入。executeAllowed仍由完整真实状态推导。
2. 单样例选一个FromSourceHan真实TMP；若源Prefab传播会涉及多个真实组件，必须揭示并选不扩散的独立实例，不能把一源多实例改写称单条。业务引用只1项，完整171审计其余未变化；样例事务回退至原基线并验证，允许重复回退。新材质归属/引用回退和未知资产保护沿用原事务安全规则。
3. 完整迁移前建立经全量预检/备份的固定计划。逐批API可由ENGINE在两调用间执行scope/停止/备份检查。先后批次识别此前本事务已完成的批准after状态，不把已完成批次误报源漂移；也不能把外部漂移当已完成。断点重入、失败恢复/回退以真实事务证据为准，不覆盖样例或旧批日志。
4. 每批重新核对剩余/已完成/非目标指纹以及输入快照，日志明确planned/applied/rolledback/completed；只在所有批准行最终覆盖且验证通过时标全量完成。禁止部分迁移宣称成功；跨批风险需全范围回退或保全并准确失败。
5. Test-FontSwap覆盖：单样例只1→回退，至少两批→全量，已应用批恢复不重复，非法/重复选择零写入，批间未触碰项或既成项漂移拦截，批失败后回退幂等。真实Unity6/TMP DLL编译；常规PS7执行Fonts profile最终验证一次（必要第二次有新原因），runner exit0和准确生产Writes=0。失败保留原史。实际Editor复核仍由AI170执行，不冒充Unity验证。
6. 交付ENGINE无需反射/私有API/改CSV的精确公共API用法和checkpoint顺序，说明样例、回退、分批、复验各自的证据路径与停止状态。

Complete/Fail回传原supervisorHandoff，禁止自行派发下一任务。
