# PRE-1c-TRANSACTION-CONTRACT-R1 [CODE] 诊断证据与事务阶段校验收口

本任务只修原 AI170 迁移工具的两个明确契约缺陷，不是新迁移任务，不消耗或重置 AI170 恢复预算，不执行生产迁移。完成后由控制台核实，再决定原 AI170 最后一次恢复；不能以继续拆任务规避 3/6 上限。

## 必读和边界
CORE、SUPERVISED、workers/CODE、TK-LOC-03、P-036/P-047/P-048、项目两文档页首/Fonts模块；原 PRE-1c-SAVED-STATE-R1_CODE.md 及两份用户批准 inputs/U1-PRE_人工反馈与字体批准_20260923.md、U1-PRE_Lab60_增量批准与接力_20260924.md。批准保持原231行/7资产及meta/3材质/5具名Prefab/Static GUID/CoverTitle/140wrap；原两CSV SHA、目标与风格来源不变。四Prefab的8源目标仍FromLegacy、40场景行仍FromSourceHan。保留全部已有效身份、继承、传播、非目标和未知漂移守卫。无Git、无Unity/MCP调用、无生产资源/CSV/runtime修改。

仅允许改 Assets/Editor/Fonts/ShortCycleFontSwapTool.cs、DevTools/Fonts/FontSwapDryRunHarness.cs、Test-FontSwap.ps1、必要长期Fixtures、Fonts README/TK-LOC-03和项目文档对应模块。不得手改YAML、改批准CSV、造executeAllowed或事务。完整旧证据保留，不重新跑已成功前置任务。

## 已有实证（先读）
控制台证据目录 outputs/control/U1-PRE-R1-20260923/：
- ai181-controller-fonts-final.log、runtime/verify-all/verify-all-AI-000181.jsonl：控制台补齐首次Fonts Final，2/2 exit0；不重跑AI181 Final。
- ai181-readonly-editor/approved-plan.json：真实schema8/v3、raw231/rows231/unique201、7资产、executeAllowed=true/reasons0。
- 同目录 fingerprint-diagnostic.json：两轮各231，success/stableAcrossReloads/referencesValid=true、unstable0。聚合成功不代表逐项契约正确。
- ai181-controller-contract-findings.json：8源对象在每轮 materialNormalizationReason 与计划不一致，共16项。计划为APPROVED_LOAD_OBSERVATION_TMP_DEFAULT_MATERIAL，诊断为空。实际approved/raw/effective引用均已存证。
- ai181-readonly-editor-result.json含实际公开调用；ai181-after-readonly-baseline-check.json确认14资源/meta全一致、无backup/transaction/三材质，最终单ShortCycle Edit clean、Console0。
本轮没有Begin/样例写入或真实回退失败。下述SHA问题为源码调用链推导，必须明确区别于已执行故障。

## 两个必须收口的缺陷
1. CaptureFingerprintDiagnosticPass 构造材质证据时把 row.beforeMaterialGlobalId（savedRaw）作为 approvedMaterialGlobalId；真实原批准观察应来自 approvedObservation 字段。不能仅改输出标签或回填计划结果。Preview、诊断、Begin和批间检查应使用同一正确三态证据构造/分类核心。诊断既比较两轮，还必须逐行与计划契约一致；故意把approved替换raw、改解释类别或改变已存owner/raw/effective等必须失败。保留8源受限解释，不泛化其余对象。

2. 固定批准基线SHA与已授权事务阶段SHA混用：
ReadSavedTmpReferences/ApprovedBaselineMatches 返回原始整文件SHA匹配；IsLiveRowBefore 对待办行还要求原 row.savedReferenceAssetSha256/sourceSHA。ApplyApprovedBatch写入单样例并Save后、更新expectedFiles前，会ValidateLiveTransactionState所有行。同ShortCycle中其余160待办行虽字段未变，整文件SHA已因本任务样例改变而被误拒绝。catch进RollbackTransactionContents又先ValidateLiveRowsAnyState，仍用相同原SHA门，可能在RestoreApprovedBaselineBackup前再次拒绝。
必须由源码和共用核心回归证实/修正这一链，不声明已发生生产回退失败。
清晰分开不可变批准/备份原态与经核验的事务当前阶段状态；每次修改必须有前态检查、精确允许写入/已完成集和受控后态验证，然后才推进阶段。不能简单去掉SHA、把当前hash直接当可信基线、先更新expectedFiles以吞掉未知写入，或允许任意before/after混合后覆盖未知成果。源传播造成同文件/跨文件预期变化也须纳入真实阶段身份检查，非目标字段与未批准override继续保护。
公开回退必须能处理“已归属的合法部分写入+同文件待办行”并到达已验证byte-exact备份恢复，再核原14资源/meta/保存override/非目标/SHA、三材质归属及幂等性；遇未知外部写入、缺失/被篡改备份、无法证明归属的中间态则保留现场拒绝。不得无条件copy覆盖用户修改，不弱化平台边界。保持已批准byte-exact恢复路径，无手工YAML编辑。

## 回归与交付
回归必须调用生产共用证据/阶段/恢复决策核心，不能仅另写模拟器或测试文本包含：
- 三态诊断对照计划：40场景受限解释、8源受限解释、其余行正常；两个pass相同但都与计划错时也拒绝。
- 同文件至少两个真实身份，单项允许写入导致文件SHA改变而另一待办行字段不变可通过；样例完整回退后原文件字节/SHA一致。
- 多批、源传播、部分失败/保存失败及幂等回退；未知非目标字段/新增override/元数据/外部文件内容或阶段快照改动拒绝，不允许借更新预期覆盖。
- 14文件备份清单/原SHA与事务阶段分离、备份篡改/越界拒绝，恢复后original verified；保留原171/Lab60/7资源及所有有效旧回归。
使用隔离长期夹具与真实Unity6/TMP DLL编译，源码生产资产写入0。窄测后一次普通PS7 Fonts Final（确有新增改动后重测需原因），报告实际覆盖和无法离线证明的Editor保存细节。不要复跑AI181或其它成功任务的Final。
按接口变化更新版本并拒绝不兼容旧计划/事务，交公开API调用/精确主Editor场景关闭恢复顺序，不给主工程batch/反射private示例。

## 接力与预算
依赖AI181/179/177/169，资源unity-project/font-assets/workflow-devtools。AI170仍PAUSED_CIRCUIT，attempts6、6错误/6issue/5恢复不变。当前正式key VERIFICATION来自attempt6漏传；只有该次归入材质pre1_unity6_tmp_material_resolution_drift家族（1恢复），原canonical同名记录不混同；指纹家族含EXECUTION仍2恢复。下一恢复为材质家族2/任务总6，最后一次。不得自行Recover/Reset/新建迁移任务或清历史。
完成后控制台核源码/唯一Final/冻结生产SHA/可靠回退方案，再在CODE释放共享资源后做新版公开Preview/两轮诊断并逐行对照计划。真实231行/7资产/三态/稳定身份和0契约异常全部成立才考虑原170正式Recover；新计划版本以实际交付为准，新attempt仍7，旧attempt1～6及本次控制台schema8证据不覆盖。若明确契约仍失败，交实证进入停止判断，不循环补丁代替恢复上限。
Complete/Fail原样handoff回控制台并停止；六要素报告落outputs/U1-PRE-R1/<TaskID>/，明确Editor迁移尚未执行。固定D:/GameProject/Eat-What，exec_command显式shell=C:/Users/DDJ/.cache/codex-runtimes/codex-primary-runtime/dependencies/native/powershell/pwsh.exe，直接queue.ps1、不Windows5、不降低ExecutionPolicy。token/model不可得null加原因。
