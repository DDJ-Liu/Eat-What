# PRE-1c-PREFAB-REFERENCE-R1 [CODE] 内部 Prefab 引用的稳定指纹兼容修复

目标：修复 AI170 attempt4 在真实 Unity 6000.3.24f1 读取 m_PrefabInstance 时的 UNRESOLVED_OBJECT_REFERENCE，保留全部真实非目标字段及引用漂移检查。仅现有工具源码、测试与说明；不执行生产迁移，也不重跑成功前置。

## 必读与事实

读取 CORE.md、workers/CODE.md、SUPERVISED.md、toolkit/LOC.md TK-LOC-03、pitfalls/CODE.md P-036/P-047/P-048，两份项目文档页首及 Fonts 模块。原171与Lab60批准仍有效，精确范围见 inputs/U1-PRE_人工反馈与字体批准_20260923.md 和 inputs/U1-PRE_Lab60_增量批准与接力_20260924.md。先核实际 Git 与源码，不覆盖并行/用户改动。

AI178已SUCCEEDED/VERIFIED（CODE范围），schema5/nonTargetFingerprintVersion2。真实AI170 attempt4在 Preview / ReadApprovedBindings / ComputeNonTargetFingerprint / DescribeObjectReference 处报：
UNRESOLVED_OBJECT_REFERENCE|unsupported_nonpersistent_type|m_PrefabInstance|UnityEngine.Object
已加载目标场景及按任务卡暂关两目标场景两种状态都在计划、备份和事务创建前拒绝；ENGINE恢复单独ShortCycle_P0P1活动场景、Edit clean、Console0。控制台复核12源码/输入/生产哈希及两场景meta全一致，三材质和备份均不存在，生产写入0。

证据目录 outputs/control/U1-PRE-R1-20260923：
- ai170-attempt4-execution-evidence.json：真实执行工具与原失败，attempt4未产出独立报告，不能用旧attempt1的verification-summary冒充。
- ai170-attempt4-controller-probe.json：控制台发现/核实MCP路径版本和现有clean场景后，只读枚举对象引用，不加载/关闭/保存场景、不改字段。
- ai170-attempt4-baseline-check.json：本轮磁盘与Git状态。

只读探针在当前整场景232个TMP中发现191个该内部引用（不是新增批准范围）：EditorUtility.IsPersistent(value)=false，但 GlobalObjectId.GetGlobalObjectIdSlow(value) 可返回有效保存身份，例如 reference=GlobalObjectId_V1-2-7a0c3d3c3003f5449819f0e57a50a528-1661337093-0；对应owner末尾targetPrefabId为1661337093。另两实例内部引用targetObjectId分别1935786674、1306828876。此证据证明当前一轮可读，不证明跨重载稳定。不得把232/191作为迁移计数，仍231批准行/7资源。

当前代码只在IsPersistent分支取GlobalObjectId；非persistent仅接受GameObject或Component，从而拒绝Unity内部PrefabInstance对象。检查整个描述/归一化/所有调用链，不仅消除一条异常。

## 改动与验收

允许改现有 Assets/Editor/Fonts/ShortCycleFontSwapTool.cs、DevTools/Fonts/FontSwapDryRunHarness.cs、Test-FontSwap.ps1及必要既有夹具；同步 DevTools/Fonts/README.md、toolkit/LOC.md、两份项目文档相关说明。不得修改批准CSV、生产scene/prefab/asset/material/meta、生产备份或manifest、队列实现/runtime。不新增平行迁移器。

1. 为合法内部Prefab引用提供可解释稳定身份。可对非persistent但具有真实已保存GlobalObjectId的对象先做严格有效性及归属核验，再保留现有层级/组件结构fallback；具体设计以完整源码核实为准。仅TryParse成功不等于有效，必须拒绝零/缺失GUID、无有效类型/目标、与拥有资产或Prefab实例关系不符等身份。不能使用瞬态instanceID、非persistent一律空串、全局忽略FileID或直接跳过m_PrefabInstance。
2. 核对m_PrefabInstance、m_CorrespondingSourceObject、m_PrefabAsset及普通对象引用的边界。无支持证据的未知Unity内部类型、无可靠身份的引用应明确失败关闭，不能吞异常变null。不同保存资源、同源不同实例、同名兄弟、多个同类型组件和真实Prefab归属变更仍须不同指纹。不要无依据放宽所有UnityEngine.Object。
3. 回归调用生产共用身份/指纹核心，包含当前真实内部引用形态：同一有效保存身份临时ID不同一致；不同Prefab实例/源关系/资产GUID不同；零/伪有效ID及归属不符拒绝；null/缺失/未知类型保护。保留原对象原子遍历、普通m_FileID整数/文本/颜色/字号/数组/嵌套变化拒绝、两目标字段精确排除、171与Lab60/231/7资源/源传播/完整及幂等回退的有效断言。增加公共诊断可观测字段须限于真实引用身份与归属，不关闭检查。
4. 身份契约变化时明确计划/事务版本及旧计划失效策略；不得继续旧schema计划或手改事务。离线不能模拟真实SerializedProperty时如实交接，不用夹具代签Editor。正常PS7窄测后一次Fonts Final，额外Final需理由；实际Unity6/TMP DLL编译；生产写入0。
5. ENGINE移交必须使用现主Editor/MCP公开API，禁止在已打开的主工程再启动batch、不停止共享Editor/MCP、不自动保存用户工作。后继先核现有加载/活动/dirty/恢复点，仅clean目标场景可按归属暂关，必要时任务所有的空场景，try/finally恢复原布局；未知用户dirty不得保存/丢弃。双映射真实231行预览后，通过公开DiagnoseApprovedNonTargetFingerprints真实两次重载，每轮覆盖231行/7资源，逐行指纹一致、引用有效非空且0不稳定，再Begin/单FromSourceHan完整回退/全量分批。unique数由Editor实测，不硬填201。
6. 新ENGINE输出 attempt-5-prefab-reference-r1，独立样例/全量事务，旧失败目录不覆盖；7资源/meta精确备份保全、样例后备份manifest归档及原Play/Build/Static SHA/Dynamic清空/五视图/CoverTitle/Lab滚轮/clean/Console条款不变。新增工具不能绕过反射private、executeAllowed、CSV、批准边界或平台许可。

## 编排与恢复预算

依赖AI178/177/176/169（均成功），不得依赖失败AI170。独占unity-project/font-assets/workflow-devtools。正式领取后按检查点/续租执行，Complete/Fail的supervisorHandoff原样回控制台，不自行恢复170。

AI170本轮Fail漏传ProblemKey，正式记录为EXECUTION；原pre1_non_target_fingerprint_transient_fileid及其它全部错误/恢复记录原样保留。控制台将本次内部Prefab引用兼容缺口与已有指纹稳定身份修复保守合并计数：该根因家族已有1次控制台恢复，总恢复3次；待本任务实际成功审核后方可考虑第2次家族恢复/总第4次。保留当前队列原key，禁止以改key/Reset/新建迁移任务清预算。后继若同类失败须显式稳定ProblemKey并由控制台连同EXECUTION别名合并核账，家族3次/总6次上限不变。本任务不改队列API来重写错误。

固定工作区D:/GameProject/Eat-What；exec_command显式shell=C:/Users/DDJ/.cache/codex-runtimes/codex-primary-runtime/dependencies/native/powershell/pwsh.exe，直接queue.ps1，不嵌套Windows5/降低ExecutionPolicy。CODE不操作Unity Editor，不提交推送；保留140wrap、空间布局、所有非目标字段和原231行批准范围。报告六要素、源码SHA、实际runner和公开移交落 outputs/U1-PRE-R1/<TaskID>/；实际工具/返回体及阶段计量，provider token/model不可得null+原因。
