# PRE-1c-SAVED-STATE-R1 [CODE] 批准观察态、磁盘前态与加载状态的统一修复

本任务是原AI170的必要工具修复，不是替代迁移任务，不执行生产迁移。先修正整条保存状态契约，再由控制台决定是否消耗原170最后一次恢复机会。

## 必读与授权
CORE、SUPERVISED、workers/CODE、TK-LOC-03、P-036/P-047/P-048；项目两文档页首/Fonts模块。读 inputs/U1-PRE_人工反馈与字体批准_20260923.md、U1-PRE_Lab60_增量批准与接力_20260924.md，原171 CSV及Lab60 CSV均不改，231对象/7资产/3材质/Static/CoverTitle/140wrap/非目标字段/不Git边界全部保持。用户批准按对象路径+组件槽位锁定，原8源对象的目标仍FromLegacyShortCycle，40场景行目标仍FromSourceHan；本修复不改变目标、风格源或用户批准。

## 实证（不是推测）
证据目录 outputs/control/U1-PRE-R1-20260923/，读 ai170-attempt6-*：
- attempt6/schema7/v3真实Preview raw231/rows183/unique153、49理由、executeAllowed=false。40场景Tray行仍MATERIAL_GLOBAL_ID，另8源行MATERIAL_GLOBAL_ID/UNEXPLAINED_EFFECTIVE_MATERIAL。未诊断/Begin/事务/备份/材质创建/生产写入。原输出 outputs/U1-PRE-R1/AI-000170/attempt-6-material-resolution-r1/ 全保留。
- ai170-attempt6-saved-instance-proof.json：精确ShortCycle PrefabInstance fileID1485991313，m_SourcePrefab=TraySlot GUID3bca90a9adec5774e8a40f3e9a564670，58项保存modifications中font/material项为0。对应NameLabel源fileID1155197156528484897、BadgeLabel8566512764583673367。
- ai170-attempt6-controller-material-probe.json：同一loaded实例的SerializedProperty.prefabOverride=true且GetPropertyModifications返回默认75909...材质，而磁盘仍无此override、scene clean。因此内存GetPropertyModifications不能作为“已保存raw”，有效值不同也不能推定显式保存override。之前attempt5无内存override与此不矛盾，须分清生命周期状态。
- ai170-attempt6-original-eight-rows.json来自AI162原font-swap-preview：四Prefab CatalogCard/IngredientCard/Sticker/TraySlot各NameLabel/BadgeLabel，原CSV观察的before材质为WithFallback内嵌默认75909fc3d0fa2c94baa5706654d37655/9052723641695353799。
- 同期只读AssetDatabase.LoadAssetAtPath四Prefab：磁盘及persistent TMP为SourceHan（前三类中Catalog/Ingredient/Tray共6项，GUID53ffd732c8bc2034f93d5a714c25eda2/unsigned12569091968840867831，signed -5877652104868683785）；Sticker2项为Heavy ce30f77e3b8c0ad45b7b7ae26b956bb6/unsigned18028800558602920526，signed -417943515106631090。font全WithFallback75909...。
- ai170-attempt6-prefab-load-probe.json：控制台分别LoadPrefabContents这四源，8项全部自动读成上述WithFallback默认材质，与AI162原预览和CSV完全一致；try/finally全部Unload且未Save。说明原CSV记录加载观察态，不是可直接强等的原始磁盘引用。无需新增对象/目标批准；不得借此接受其它未经证明差异。
- ai170-attempt6-baseline-check.json：14源码/原输入/生产/meta SHA均一致、3目标mat和DevTools/Fonts/backup/AI-000170不存在；无未知生产漂移。真实TMP LoadFontAsset atlas不匹配回落default的既有源码只读，不修改TMP/PackageCache/Library。

## 允许修改
仅 Assets/Editor/Fonts/ShortCycleFontSwapTool.cs、DevTools/Fonts/FontSwapDryRunHarness.cs、Test-FontSwap.ps1及必要长期Fixtures、现有Fonts README/TK-LOC-03及项目两文档对应模块。保留原工具和公开API体系。不调用Unity/MCP，不写生产scene/prefab/asset/material/meta，不改CSV/批准原件/runtime，不造生产备份/事务/manifest，不Git。可复制精确只读生产片段为长期回归夹具，注明来源/文件SHA/精确fileID；不得依赖会归档的输出作长期测试资源。

## 必须一次覆盖的契约
1. 三态独立：approvedObservation（CSV原观察）、savedRaw（精确保存序列化与继承/覆盖）、loadedEffective。分别存证，不能互相回填，原CSV保持SHA。保存raw来自精确资产GUID+组件fileID+实例PrefabInstance对应源及磁盘modification/stripped关系；字段继承递归、signed/unsigned ID无损处理。内存GetPropertyModifications只可作loaded证据，不能证明已保存override或raw。不能使用路径同名模糊匹配；未知/nested未支持/重复或无法证明关系明确拒绝。
2. 独立保存SHA基线必须真正绑定读取时的内容，不能两次hash当前文件就声称与批准基线相同。计划/事务存7资产及meta指纹、精确raw font/material/保存override及归属，Begin及各写入阶段使用受控预期状态检查并防TOCTOU；样例回退核原基线。其他字段、引用与身份保护保留。
3. 已证两种受限解释：40指定Tray场景行的CSV=raw SourceHan，effective可为证明过的font.default；8指定源行的CSV=原LoadPrefabContents观察default、raw是精确SourceHan/Heavy，effective在相同合法加载上下文应复现default。两类须有精确对象/槽位/font/raw/原预览/资产SHA/atlas不符/default身份/保存继承或override关系全证据；原8目标仍FromLegacy，风格源按批准默认材质，不能改成raw风格。40目标仍FromSourceHan。其余任何差异拒绝，不泛化到全项目或全部材质。未映射非目标材质字段、非目标override保持。
4. 精确保存override、加载派生override和迁移必要override分开记录。先实例后源、全231行固定覆盖、去重/传播分析需按真实写入和目标等价处理；一个观察态解释不能把不同目标重新合并或漏写。
5. 从Preview→公开诊断→Begin重验→批前后→固定事务→完整/部分失败/幂等Rollback全部调用同一证据核心，不能只放行Preview。回退须还原原磁盘font/material与继承/显式override结构、7资产/meta/SHA及非目标，不能仅把内存有效默认材质保存后标成功。分析SavePrefab/SaveScene/TMP生命周期可能再次归一化的风险，给明确可执行恢复方案和API顺序；无法证明可靠回退则Fail/TASK交具体证据，不谎称已经解决。禁止手改YAML、关闭TMP生命周期/guard、MarkSceneClean掩盖或覆盖未知用户修改。
6. 更新计划/诊断/事务版本及旧版本失效规则。逐231行输出approved/raw/effective、解释类别、精确保存owner/source/override及SHA；拒绝的行也留下实际证据和原因，不因拒绝只留下行数。保留v3非目标内部Prefab身份/缺失引用/真实字段漂移守卫。
7. 回归真正调用生产共用解析/分类/事务核心：精确磁盘无override但内存有派生override；8源观察default/raw不同；Lab真实60override；多实例不同target；source传播/样例/分批/回退；wrongGUID/fileID/SHA/font/default/atlas、未知对象、真实新增override、缺失/歧义引用、signed ID等拒绝。保留171+60/7资源与所有有效旧断言，不改期望值迎合错误。真实Unity6/TMP DLL编译，普通PS7一次Fonts Final（额外需原因），离线无法复现真实Editor保存过程的部分如实标未证。
8. CODE完成后控制台先核源码、测试、冻结生产SHA、恢复方案，并在CODE结束/共享资源空闲时只读验证新版公开Preview及两轮诊断；此处不得Begin/创建材质/迁移，不由CODE越线操作。只有真实231覆盖/7资产、稳定有效身份/三态/0异常及可靠回退方案都核实，才考虑对原170最后一次Recover。只读预检仍失败则交实证决定停止，不循环新建迁移任务/无限修补规避恢复上限。

## 预算与后继
AI170仍PAUSED_CIRCUIT：attempt6、6错误/6issue/总5恢复。最新Fail漏传ProblemKey而落VERIFICATION；仅这次attempt6与pre1_unity6_tmp_material_resolution_drift按材质根因家族合并（已1恢复），原attempt1同字符串VERIFICATION属于canonical问题，不覆盖/改写。指纹家族含EXECUTION仍2次。后继候选为材质家族第2/任务总第6（最后一次）；不Reset，不换key清预算，不新建替代迁移任务。本CODE任务不得自行Recover170。
依赖180/179/177/169；资源unity-project/font-assets/workflow-devtools。完整handoff回控制台并停止。输出outputs/U1-PRE-R1/<TaskID>/，六要素、源码SHA、唯一Final与恢复风险/公开只读检查说明。当前无需重复用户批准，无平台拒绝。
固定D:/GameProject/Eat-What，所有exec_command显式shell=C:/Users/DDJ/.cache/codex-runtimes/codex-primary-runtime/dependencies/native/powershell/pwsh.exe；直接queue.ps1，不Windows5、不降低ExecutionPolicy。实际token/model不可得记null原因。

