# PRE-1c [ENGINE_MCP] 231行批准字体材质迁移执行

2026-09-24 17:30 用户改为手动诊断：已正式 ExitSupervision，当前 MANUAL / PAUSED_MODE，stopRequested、exitRequested=true，原 ai 保持 PAUSED。仅诊断，不修复/回退/重试/派发。已用不保存的材质副本复现 FromHeavy 的 TMP ScaleRatioA/B/C 重算导致指纹失效；回退在复制备份前被同一材质守卫拦住。40 条 kern 非目标 override 来源已定位为旧字段加载转换及保存结构保护缺口，另有 ROLLBACK_FAILED 重入条件的源码推导，未执行重入。失败现场24文件及字体/CSV10文件本轮SHA不变，部分保存状态尚未恢复；原错误/恢复史和人工结论不改。详细报告：`.ai-workspace/outputs/control/U1-PRE-R1-20260923/manual-diagnosis-20260924/AI170失败原因定位报告.md`。下方较早接力均为历史，不构成新的执行授权；本条专项核验不提升完整复核日期。

> **2026-09-24 17:16 已停止。** attempt7的单FromSourceHan样例写入/回退通过，但全量第一批FromHeavy OWNED_MATERIAL_DRIFT且公开回退失败；full事务ROLLBACK_FAILED，两个场景已有保存变化、三新材质保留。任务NEEDS_USER，session CIRCUIT/stopRequested，原ai已PAUSED，自动恢复总6次用尽。禁止依据下方历史准入说明重新Poll/Begin/Apply/Rollback、追加修复或Reset绕限。失败现场24文件已保全，14基线备份与样例快照完好；须用户明确新的现场诊断/安全恢复授权。报告：outputs/control/U1-PRE-R1-20260923/AI170第七轮失败现场与全队列未关闭清单.md。

## 当前接力：AI183修复及控制台真实只读核验已通过
AI183已SUCCEEDED/VERIFIED，schema10 / nonTargetFingerprintVersion3，诊断schema4、备份manifest8。唯一Fonts Final两runner exit0，真实Unity6/TMP DLL208896字节。控制台源码/CSV/14生产资源meta共19SHA全匹配，三材质/Materials目录/原170备份不存在。
现主Editor正常编译后，公开BuildApplyingBatchRecord/EvaluateApplyingStageSnapshot纯内存策略反例正确拒绝既有场景/Prefab meta修改删除、日志篡改、后继材质meta变化，同名已有创建拒绝、合法初次创建策略通过。真实Preview raw/rows231、unique201、7资产、executeAllowed=true/reasons0；两轮各231、稳定有效引用、0异常、计划0不符。控制台额外独立比对每行20字段，两轮0差异，归一化40/8/183。此为只读核验，不是生产回退/迁移已通过。
证据outputs/control/U1-PRE-R1-20260923/ai183-controller-readonly-evidence.json、ai183-controller-contract-check.json、ai183-controller-baseline-check.json。现主Editor恢复单ShortCycle Edit clean/Console0；CODE及ENGINE经应用实证idle。本卡与AI183完成报告共同移交，不依赖不存在的ENGINE-handoff文件。
只有控制台正式Recover并取得新票据后才能Poll；不得沿用旧票据、旧计划或控制台诊断计划。仍为原AI170最后一次恢复，保留全错误/issue/恢复史与原批准；同类材质问题显式ProblemKey=pre1_unity6_tmp_material_resolution_drift，不遗漏key。若新根因按真实稳定key留证，总第6上限不变。不得再Reset/换任务规避。
## 恢复预算和版本
2026-09-24 17:04:21已正式恢复并真实领取attempt7，6错误/6issue保留，现总6次恢复。最新Fail遗漏ProblemKey保存VERIFICATION，只把attempt6该次与pre1_unity6_tmp_material_resolution_drift合并为材质根因家族；本次为材质家族第2/任务总第6（最后一次）。原attempt1的VERIFICATION仍保留其canonical含义，指纹家族含EXECUTION仍2次。不得Reset/改历史/换key或另建迁移任务清预算。后继Fail明确稳定key并停止判断；同类材质根因不得再次遗漏。详见ai170-meta-guard-recovery.json与ai170-meta-guard-claim-confirmed.json。
若获正式恢复和新票据CLAIMED，使用attempt-7-saved-state-r1、新sample/full事务。以AI183的schema10/指纹v3生成全新计划，旧schema1～9/attempt1～6不续用；版本、unique、reasons不得预填。

## 后继必须实证
原171映射/旁证和Lab60映射/旁证同时传入；全231行/7资产，approvedObservation/savedRaw/loadedEffective逐行独立证据与0理由。保存raw/override必须精确磁盘身份和继承，不能用加载派生覆盖代替。原8源观察态=CSV、raw=已冻结SourceHan/Heavy；40场景CSV=raw SourceHan而effective可为经证明default。未知或非目标漂移仍拒绝。
公开双轮重载诊断必须逐行对照计划的三态/归一化类别/保存身份/指纹一致，不能只比较两轮互相稳定；必须真实稳定、引用身份有效非空、231覆盖/0异常，7资源/meta基线独立核验；拒绝行亦需实际观测，不可隐藏。CODE离线通过和控制台预检均不替代执行时检查点/Begin重验。
通过后单FromSourceHan真实TMP→公开完整回退（恢复磁盘引用、继承/显式override、7资源/meta SHA及非目标）→独立全量事务公开分批。不能仅恢复内存默认材质并保存作为成功回退。无法可靠恢复即停止，保留现场，不手改YAML/关TMP生命周期/造executeAllowed/手写事务。
继续复用主Editor、按clean/任务归属/保存恢复点关闭重载且try/finally恢复布局，不保存或丢弃未知用户工作，不主工程batch、不停共享Editor。全部原验收保持，manifest PENDING_REVIEW、不Git。详细原失败与旧接力见相应attempt及控制台报告，不重跑成功前置。

## 必读、宿主与边界

先读 .ai-workspace/CORE.md、workers/ENGINE_MCP.md、SUPERVISED.md、UNITY_SCENE_CLEANUP.md、toolkit/LOC.md TK-LOC-03及字体/Editor坑；ENGINEERING_CONVENTIONS.md C1～C4。读两份项目文档页首及Fonts/空间模块。本卡与outputs/U1-PRE-R1/AI-000183/AI-000183_PRE-1c-META-GUARD-R1_完成报告.md共同使用，冲突以本卡的主Editor/场景保护及用户授权为准。

工作区D:/GameProject/Eat-What，codex/unity6-followup，6000.3.24f1。每次MCP使用前发现/选择实例并核Application.dataPath/version、Edit/Play/Compile、各loaded场景dirty和Console。exec_command显式shell=C:/Users/DDJ/.cache/codex-runtimes/codex-primary-runtime/dependencies/native/powershell/pwsh.exe；其内直接 & ./.ai-workspace/queue.ps1，不嵌套Windows5或降低ExecutionPolicy。先正常Refresh/Compile确认AI183实际程序集，不把旧DLL缺成员重报为本根因。

## 真实批准与范围

原批准旁证 .ai-workspace/inputs/U1-PRE_人工反馈与字体批准_20260923.md，映射 .ai-workspace/outputs/control/U1-PRE-20260923/PRE1_字体材质迁移逐项草案.csv，SHA EB0CED01C1BBB0050DCF30BAA3D5354E9F2C7326C3DF97375DE87467D8FE347B。
Lab60旁证 .ai-workspace/inputs/U1-PRE_Lab60_增量批准与接力_20260924.md，映射 .ai-workspace/outputs/control/U1-PRE-R1-20260923/PRE1_Lab60_增量迁移草案.csv，SHA E8AA50B24E3ACA11E55D21F752EB92CD801B83960F443DF12E199DBC1B33A579。
两CSV保持原样，历史PROPOSED_ONLY/PENDING_USER不是缺批准；批准不代表平台回执或最终人审。

- Assets/Scenes/Cooking/ShortCycle_P0P1.unity：原CSV路径+组件序号锁定161 TMP。
- Assets/Prefabs/Cooking/ShortCycle/GridPieces/下 CatalogCard.prefab、FridgeSlot.prefab、IngredientCard.prefab、Sticker.prefab、TraySlot.prefab：各2 TMP。
- Assets/Scenes/ToolTests/FridgeScrollLab.unity：Spaces/FridgeScrollModule/FridgeCat_Group/SlotPool/FridgeSlot_01～30各BadgeLabel/NameLabel组件0，共60 TMP。font原继承、material原override，回退必须还原结构。
- 总raw/逐行coverage231，7资源及meta备份；只改m_fontAsset与配对m_sharedMaterial及必要override。Static GUID9b07c6c50dde09d4b8719754c27ddc96；CoverTitle唯一源字体例外继续有效，单列字形/宽度/换行对比。
- 新资产仅 Assets/Font/Heavy/Materials/ShortCycle_Static_FromSourceHan.mat、ShortCycle_Static_FromLegacyShortCycle.mat、ShortCycle_Static_FromHeavy.mat及meta；Materials目录由AssetDatabase创建。复制原Shader/颜色/描边/Underlay风格，仅_MainTex/_TextureWidth/_TextureHeight/_GradientScale取Static。Lab复用FromSourceHan，不加第4份；同名未知资产不覆盖。
- 保留140wrap，旧30材质override仅映射内可变；其它Prefab/字段/文本/字号/颜色/Transform/布局/Renderer/sorting/交互/Build列表/全局fallback不变。批准范围外传播停止，不扩大工程迁移。

## 真实执行顺序

1. 记录加载场景、活动场景、dirty、保存恢复点、scene/meta及目标字体/材质SHA，保留CoverTitle迁移前同镜头证据。使用公开双映射重载 PreviewApprovedMigration(baseMapping, baseEvidence, supplementalMapping, supplementalEvidence, planPath) 生成AI183实际交付schema的全新计划（旧schema1～9及attempt1～6计划/事务不得续用）。真实检查231覆盖/7资源、身份/源传播/三材质/非目标指纹/理由和executeAllowed。
2. 公开 DiagnoseApprovedNonTargetFingerprints(planPath, diagnosticPath) 要求两个批准场景均未loaded。先核所有要关闭的精确场景为clean且无用户未保存成果，再用Editor API暂开本任务拥有的空场景（需要时），仅关闭这两个目标场景，保留其它加载场景。记录原加载布局，try/finally恢复原活动场景和加载状态，清理仅属于本任务的临时空场景。不能SaveScene未知dirty或用MarkSceneClean掩盖。
3. 调用上述公开诊断：五Prefab两次独立加载/卸载、两场景打开关闭两轮；success/stableAcrossReloads/referencesValid=true，rowCount231、approvedAssetCount7、unstableRowCount0，两轮逐行指纹与引用身份一致。引用身份必须有效且非空，不得把不同实例都归空串；核NULL/PERSISTENT/LOCAL_GAME_OBJECT/LOCAL_COMPONENT/UNITY_INTERNAL_PREFAB_INSTANCE与真实对象/保存资产/实例归属对应；内部Prefab reference/owner皆type2、同保存资产GUID，reference.targetObjectId=owner.targetPrefabId且reference.targetPrefabId=0，不得空身份或忽略关系。对照本轮新计划逐行指纹；若不同解释并停止，不手改计划或删断言。核CSV/7资源/meta/SHA未变、Console无新增Error/Exception，并恢复主Editor原布局。恢复后Begin仍会再核现场。
4. 只读诊断通过后，检查点CONTINUE才用公开 BeginApprovedMigration(taskId, baseMapping, baseEvidence, supplementalMapping, supplementalEvidence, planPath, transactionPath)。单FromSourceHan样例明确只改1个真实TMP（approvedRowIdentities.Length==1，不靠Prefab源扩散）。核字体/material/atlas、旧风格及非目标字段；公开RollbackApprovedMigration完整回退，并实核7资源/meta/原引用/继承和override结构、新增资产归属回到保存基线。
5. CreateBackup按taskId复用DevTools/Fonts/backup/AI-000170；原资源仅同SHA复用，不提供任意backupRoot。全量Begin前将样例的7资源/meta、backup-manifest及字体材质指纹/新资产清单按精确清单保全到独立样例快照，记录SHA和事务对应关系，再更新当前manifest；不得无留档覆盖旧manifest/旧资源、递归复制父目录到自身子目录、反射private换路径。回退后不一致停止。
6. 独立全量事务用公开Begin/ApplyApprovedBatch/FinalizeApprovedMigration。实例先于Prefab源，每批checkpoint、scope/备份/停止检查，批后全231行待办/已完成/非目标/外部漂移检查。失败留现场与日志，只有公开API可靠回退；不得伪造executeAllowed、改CSV、手写事务或手改YAML。范围/引用真实变化仍必须拦截。

## 机器验收与保持

完成231行实际引用/atlas配对重审、去重解释、非目标与override一致性。原ShortCycle五视图中文/标题截图、CoverTitle同镜头前后字形/宽度/换行对照，Lab文字可见/双向滚轮/上下界真实验证。Play与Build前后Static SHA不变，DynamicFallback清空，字体manifest始终PENDING_REVIEW，不改Build列表。旧warning与本轮新错误分开记录；最终单目标正常场景Edit clean、Console无新增Error/Exception。所有临时资源/场景恢复按清理规范，不覆盖未知用户修改。

保护AI169布局：P0Left=-9.6，Escape/Return viewport(.06,.08)，唯一ClueBoard持续视觉及P1构图；AI169报告/verification-summary/geometry.csv为保存结果。迁移前ShortCycle SHA233113A72258444BD69C6FD014424435C4D15DD4D1EA9C01A8CF61F13E71BECB、Lab SHA4086672BB61AB57B8D32913922A80BD4708E56A1FF96C8D7CD644EB2857CC02D，实际执行重读；漂移不盲还原。LayoutAudit旧-12.8断言误报已交AI171修源码/172复验，不回滚布局或误报整个审计全绿。

实际平台拒绝保留原文和已有批准，不反复索要同一批准、不换通道绕过。源码问题交控制端CODE，不在ENGINE临时改工具。六要素报告、真实可观测工具/返回体/阶段用量落本attempt；provider不可得null原因。成功SUCCEEDED+PENDING_USER，不代签字体/构图，不放行font guard哈希，不Git提交/推送/合并，不清迁移副本或处理配表。Complete/Fail原样handoff回控制台并结束，后继171/172由控制台派发。
