# PRE-1c-FINGERPRINT-R1 [CODE] 非目标字段指纹跨加载稳定性修复

目标：修复 TK-LOC-03 非目标指纹将 Unity 瞬态引用子 FileID 纳入比较的问题，同时继续拒绝真正的非目标字段或对象引用漂移。此任务是已批准字体迁移的必要源码修复，仅工具与离线验证；不执行生产迁移。

## 入口与已证事实

先读 CORE.md、workers/CODE.md、SUPERVISED.md、toolkit/LOC.md 的 TK-LOC-03、pitfalls/CODE.md P-036/P-047/P-048，项目两份文档页首及 Fonts 模块。批准边界见 inputs/U1-PRE_人工反馈与字体批准_20260923.md 和 inputs/U1-PRE_Lab60_增量批准与接力_20260924.md。AI177 完成报告及当前实际源码为接口事实，不重跑成功前置。

AI170 attempt3 真实 Editor 预检 schema4：raw/rows=231、unique=201、批准资产7、executeAllowed=true、reasons=0，3材质计划 ready。公开 Begin 在创建备份/事务前报 NON_TARGET_FINGERPRINT_DRIFT。连续两计划的70个指纹变化集中于五Prefab各2标签和Lab60；引用没变。只读最小复现：连续两次 LoadPrefabContents，162项中变化只有 m_GameObject.m_FileID 和 m_renderer.m_FileID。完整证据在 `.ai-workspace/outputs/U1-PRE-R1/AI-000170/attempt-3-lab60/` 的 fingerprint-drift-evidence.json、两个计划、verification-summary.json 和阻断报告。

控制台已读源码：ComputeNonTargetFingerprint 使用 iterator.Next(true) 递归所有节点；ObjectReference 本体经 StablePropertyValue/GlobalIdFor，但仍继续纳入瞬态子属性。GlobalIdFor 对非 persistent 对象返回空串，简单取消子节点后可能让不同场景/Prefab内容对象引用都变成空串，必须一起核查并保留引用身份保护，不能仅消掉误报。

## 改动清单与实施要求

| 文件 | 动作与边界 |
| --- | --- |
| Assets/Editor/Fonts/ShortCycleFontSwapTool.cs | 在现有指纹核心修复对象引用的稳定表达及遍历策略；复用既有工具，不新建平行迁移器 |
| DevTools/Fonts/FontSwapDryRunHarness.cs、Test-FontSwap.ps1及必要既有夹具 | 通过生产共用的指纹归一化核心验证稳定性及真实漂移拒绝，真实Unity6/TMP DLL编译 |
| DevTools/Fonts/README.md、toolkit/LOC.md、CODEBASE_MAP.md、项目整体阅读理解与推进基线_2026-08-14.md | 同步指纹契约、诊断/公开验收入口及仍待Editor验证的状态；不改完整复核日期 |

1. 对象引用作为原子值比较，不再递归记录其瞬态子 FileID。保留全部非目标字段、数组/嵌套数据；不可全局忽略名称含 FileID 的真实整数、整组 renderer 或所有对象引用。
2. 持久化资源引用保留 GUID/稳定 localFileID 或有效 GlobalObjectId。场景对象、加载的 Prefab 内容引用必须有可解释且跨卸载/重载稳定的身份，区分同源Prefab不同实例、同名兄弟、同类型多个组件及引用变换；不能把非persistent一律空串。可优先有效 GlobalObjectId 并核真正稳定性，必要时使用明确归属的保存资产及结构身份；不能靠瞬态 instanceID。无法可靠解析或缺失引用应明确拒绝并说明，不能吞异常退为空值冒充通过。
3. 只排除已批准 m_fontAsset/m_sharedMaterial 两字段及其表达，已有 override、全231行固定覆盖、源传播、文件SHA、批准输入校验仍保留。避免更改原字体/材质身份 helper 对其它调用的语义造成回归；检查全部使用处再改。旧计划不能直接复用为新算法指纹，交付明确的重预览/旧事务策略，不篡改旧证据。
4. 回归必须验证：同一语义引用临时ID不同仍同指纹；不同资源/场景实例/组件引用产生不同指纹并拦截；null与有效/无法解析引用的处置；普通 m_FileID 整数、文本、颜色、字号、数组或嵌套非目标值变化仍拒绝；两个目标引用变化被准确排除。测试调用生产共用计算核心，不只赋值字符串或搜源码。保留原171模式、Lab60增量231/7资产、部分失败回退及幂等回退相关回归，不删有效断言。
5. 正常PS7窄回归后一次Fonts Final，额外最终验证需记录原因；真实6000.3.24f1/TMP DLL编译。若离线无法真实模拟SerializedProperty，明确差距并交ENGINE公开只读诊断入口/精确操作，覆盖连续两次Prefab加载和暂开Lab后关闭/重开；禁止以离线夹具声称真实Editor已通过。
6. 交接要求后续ENGINE先真实只读重复231行预览，逐行指纹一致且真实引用身份非空/有效；再 Begin、单 FromSourceHan TMP 写入/完整回退、全量分批及既有验收。不得通过反射private、修改计划/事务、伪造executeAllowed、关检查恢复。新输出 attempt-4-fingerprint-r1，旧attempt3保留。可以在原工具增加范围受限的公开只读诊断以便上述验收，不新增生产写入路径。

## 执行与结算

依赖AI177/AI176/AI169（均成功），不反依赖失败AI170。持有unity-project/font-assets/workflow-devtools；正式领取后按检查点/租约执行。AI170保持PAUSED_CIRCUIT，当前稳定ProblemKey=pre1_non_target_fingerprint_transient_fileid，三条错误/五条issue/总两次恢复保留，CODE任务成功后由控制台审核再正式Recover；不Reset、不改问题键清额度。

固定 D:/GameProject/Eat-What；exec_command显式shell=C:/Users/DDJ/.cache/codex-runtimes/codex-primary-runtime/dependencies/native/powershell/pwsh.exe，直接调用queue.ps1，不嵌套Windows5或降低ExecutionPolicy。CODE不操作Unity Editor、不写scene/prefab/asset/material/meta、CSV、批准旁证、生产备份或manifest，不做Git提交推送。保留原140wrap/已批材质和空间布局，不扩大231行批准范围。

产物 `.ai-workspace/outputs/U1-PRE-R1/<TaskID>/`，实际源码SHA/runner记录/公开移交、工具返回体和阶段用量落盘；provider token/model不可得null+原因。报告六要素，Complete/Fail返回的supervisorHandoff原样回控制台并结束，不自行恢复AI170。
