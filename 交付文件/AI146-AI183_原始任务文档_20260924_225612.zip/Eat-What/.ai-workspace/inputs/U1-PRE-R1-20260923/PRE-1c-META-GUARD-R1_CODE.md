# PRE-1c-META-GUARD-R1 [CODE] 生产元数据变更范围与回退归属修复

用户明确继续：`inputs/U1-PRE_META保护修复与恢复监管_20260924.md`。这是原 AI170 的工具补丁，不是替代迁移任务，不重置或消耗其恢复预算。只在固定任务和票据 CLAIMED 后执行；每批写入前检查点，保持 unity-project/font-assets/workflow-devtools 互斥。

## 必要阅读与改动清单

CORE、SUPERVISED、workers/CODE、TK-LOC-03、P-036/P-047/P-048；两项目文档页首和 Fonts 模块；前卡 PRE-1c-TRANSACTION-CONTRACT-R1_CODE.md；原字体与 Lab60 批准及本轮继续文件。源码为最终事实，不沿用旧行号猜测。

只允许修改：`Assets/Editor/Fonts/ShortCycleFontSwapTool.cs`、`DevTools/Fonts/FontSwapDryRunHarness.cs`、必要 `Test-FontSwap.ps1`/长期 Fixtures、Fonts README/TK-LOC-03 和项目文档对应模块，及本任务输出。先报告实际代码改动清单。禁止 Unity/MCP/生产迁移，禁止修改 .unity/.prefab/.asset/.meta/CSV，禁止手改 runtime，禁止 Git 提交推送。原231行/7资产/3材质/5Prefab/Static GUID/CoverTitle/140wrap范围不变。

## 已确认问题与证据

读 `outputs/control/U1-PRE-R1-20260923/AI182控制审查停止与全队列未关闭清单.md`、`ai182-controller-contract-check.json`、`ai182-controller-readonly-evidence.json`、`ai182-controller-baseline-check.json`。实际schema9 Preview231行/unique201/7资产及双轮与计划逐行0异常已经通过，不重跑 AI182 Final，不重新解决已修的16项类别或旧SHA门问题。

GetBatchAllowedFilePaths 对选中既有 writeAssetPath 使用 addWithMeta，使原场景/Prefab meta 进入允许变化白名单；EvaluateStageSnapshotTransition 在此生产输入下接受未知 meta 改动。批后阶段推进和 APPLYING 回退归属复用该策略。现有 harness 的 metaTamper 测试手工只传资产路径，未覆盖生产白名单生成。公开反例仅内存快照，没有真实 meta 改动、Begin 或生产回退失败。

## 必须收口的生产契约

1. 提取或公开纯校验/策略核心，生产 GetBatchAllowedFilePaths、批后验证、APPLYING 部分失败回退和测试实际调用同一实现；测试不得重新拼装一份更窄白名单，不以静态字符串哨兵代替行为验证。不暴露可绕过批准/事务的写入后门。
2. 既有7资产及其已存在 meta 区分处理：映射内选中资产仅允许批准字段变化；已有 meta 的内容、存在性和GUID必须保持原阶段/备份基线，不因资产被选中、save/import或rollback而放行任意 meta SHA。共享引用材质/字体和非目标文件也不借此放宽。
3. 原批准3份新材质及 meta 只允许在基线不存在且本任务当前创建操作、精确路径和独立归属证据成立时出现。不可覆盖同名已有资产；创建完成后 meta 不得继续被首次创建白名单无限放行，后续批次的未知内容/删除/替换必须拒绝。Materials 目录如已存在保持；如确需按原批准由 AssetDatabase 新建目录，其 meta 必须单独记录创建前态/归属并在回退按精确范围处理，不能扩为任意父目录写入。
4. 不能只修 Preview 或输出标签。Begin、正常批次、部分失败、公开回退、幂等回退均适用。先验证阶段/行状态/真实写入归属再推进 expectedFiles；未知内容不可先记为预期。可信备份/manifest/事务日志完整性检查必须发生于复制恢复之前；未知用户改动不无条件覆盖，不通过简单去掉SHA/过滤meta来放行。
5. 保留231行三态、40场景与8源窄解释、身份/保存override/源传播/非目标字段保护；合法单样例改变整文件SHA但同文件待办行未变仍可继续。若现有实现还无法证明同文件未知修改归属，须如实失败，不能把唯一路径白名单当成完整授权证明。

## 有意义回归与交付

新增测试使用生产真实策略构造器及实际校验核心，证明旧缺陷输入失败，并覆盖：既有场景和Prefab meta任意SHA变化/删除/替换，即使资产也合法变化仍拒绝；未选中资产、meta和外部CSV拒绝；仅获准新材质+meta从不存在到存在在真实创建上下文允许，同名已有拒绝、后续批次修改meta拒绝；APPLYING部分失败与回退前meta/日志/备份/未知非目标篡改拒绝；合法单写/多批/源传播保留、精确恢复14资源及保存override、重复回退幂等。使用生产共用核心，不另写平行事务模拟器宣称真实回退通过。

中途只做必要增量检查，最终一次 `DevTools/Verify-All.ps1 -TaskId <实际ID> -Profile Fonts -Mode Final`，普通PS7调用；真实Unity6/TMP DLL编译证据、runner exit、唯一Final历史、源码SHA、基线SHA、修改清单和明确限制一并交付。需要因新失败再Final写理由，不重跑成功前置。

公开只读移交需给出实际API/schema、生产策略内存反例的调用与预期、Preview/诊断参数、事务阶段和回退证明；新版本有必要时拒绝不兼容旧计划/日志。CODE离线通过不代表Editor或迁移通过。Complete/Fail的 supervisorHandoff 原样回控制台并结束。

## 控制台接力停止线

补丁成功后先核源/真实Final/DLL、14生产资源meta/批准输入不变和可靠回退方案。共享资源释放后，复用现主Editor，发现核路径/版本，再做新公开核心元数据反例及真实双映射 Preview/双轮诊断逐行对计划；0契约异常后才正式 Recover 原AI170（总第6/最后一次，旧别名计数保留）。随后新attempt-7-saved-state-r1、新sample/full事务，旧schema1～9及控制台计划不续用。测试或真实安全契约仍失败则留证停止，不扩大授权、不循环修补或重置预算。
