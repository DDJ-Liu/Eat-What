# FIX-T5-R1b [ENGINE_MCP] 连续空间构图与P1恢复
共同执行约束：领取 CORE.md、当前任务卡及对应 worker；按 SUPERVISED.md 使用同一 PowerShell 7 宿主和真实 TaskId/DispatchToken，生产写入批次前 SupervisionCheckpoint。目标 D:/GameProject/Eat-What、codex/unity6-followup、Unity 6000.3.24f1。读 inputs/U1-PRE_人工反馈与字体批准_20260923.md；最新用户授权优先于旧待批准文本。保留所有已有修改、错误/恢复史，不 Reset 成功任务，不提交/推送，不手改 Unity YAML/meta。输出 outputs/U1-PRE-R1/<TaskId>/，六要素报告、真实工具计量，不估算 provider token；Complete/Fail 后回传 supervisorHandoff 并结束，由控制台派下一棒。人工审查后置但不代签。
目标场景仅 Assets/Scenes/Cooking/ShortCycle_P0P1.unity；依赖R1a。修复用户四项反馈，用EditorAPI配置真实组件/Transform/marker/Traveler/Set引用，禁止手改YAML、整场覆盖旧备份、Prefab源或新平行视觉层。
读稳定 inputs/排布指导书_ShortCycle_P0P1.md 与最新人工反馈增量；指导书v0.3未出不阻断。C1/C2/C4/C6、G26/G68/G69；TK-MOT-06、TK-INT-17/18、TK-LAY-02/08、TK-DBG-03/05/06。
写前核对主MCP实例dataPath/version、Git/scene dirty基线，备份scene+meta至DevTools/Scenes/backup/<TaskID>/。只读比较 DevTools/Scenes/backup/FIX-T5b_ShortCycle_P0P1.unity、AI154保留备份和AI156四区报告，提取旧P1相机相对位置/比例；不能重放旧scene而丢Modal/AI165/数据/字体工具等后续成果。
修复范围：
- Escape_Button_TUNE与Phase1_Kitchen/Return_Button_TUNE配置R1a通用视口锚定，保留Sprite/Collider/MouseInteract/Keyboard/ActionBinding/StateGate。跨Cover/Catalog/Browse/ClueBoardShell/P1确认该出现时固定镜头左下角、该隐藏时不可命中；pan中仍随相机，不能只在arrival设置一次。允许必要Anchor宿主但禁止更名171CSV对象路径和组件序号。
- 物理冰箱—板—书紧密连续；按tight sprite.vertices可见区和Renderer世界实测缩小板书间隙。调整worldplacement与marker，使Browse左页全部+右页30–40%（全书约65–70%，用户约70%），主页面较居中。证据明确比例测量基准、world/viewport bounds、场景对照，不能靠sprite.rect代替可见边缘、挤压拉伸美术或凭一个截图目测凑数。
- ClueBoard物理视觉常在，focus/交互按状态独立；从P0进入/退出P1逐帧记录activeInHierarchy/Renderer.enabled与相机视窗交叠，不能过渡消失后闪回。场景外正常裁切不算关闭。保留④压暗/板外返回。
- P1依旧完整猫视觉跟同一滚动根，恢复猫手/泡泡、板、GO、托盘和返回按钮到重构前相机相对构图；查父级位移重复叠加、world/local、Traveler/marker/滚动根/布局运行驱动竞争，不只改Edit坐标。必要调整阶段目的地，避免启动脚本再覆写。滚轮方向/手感/上下边界/Modal已通过，必须回归保护。
保持font映射171路径/组件序号、全局字体/材质、140wrap及获准30材质基线、所有非目标业务/Prefab/正式Build列表、Lab/探针。发现未知Userdirty或范围外必需修改先留证报告，不清空用户变更。
固定排布验收六项齐全：启用Renderer/TMP归属具名容器、tight vertices度量、写入审计独立、Scene点选/旧物清理/Console/Missing/dirty/冻结hash/Git独立证据、数据驱动数目与catalog一致、截图留人工不能代签。给五视图和过渡采样、宽高比原16:9与另一代表比例、重复进退、整猫边界滚动、Modal开关/焦点回归。
最终Edit/clean、Console无新增错，交实际world/viewport/marker表供设计重算v0.3；SUCCEEDED+PENDING_USER。AI156保留原拒绝并关联本修复，AI165不擅自代签。新探针有G26归属，不做全项目_TUNE审查。

## AI168完成后的必读接力（2026-09-23）

AI168已SUCCEEDED/VERIFIED，ShortCycle唯一Final 3/3 runner通过；不是正式场景视觉验收。执行前读取 `.ai-workspace/outputs/U1-PRE-R1/AI-000168/AI-000168_R1b_接线移交.md`、同目录 `AI-000168_FIX-T5-R1a_完成报告.md`、`verification-summary.json`，以及 `组件说明文档/镜头视口锚定_配置与复用说明.md`；按实际源码复核，不凭报告写入。

- 新类为 `EatWhat.Tools.Layout.CameraViewportAnchor`，路径 `Assets/Scripts/Tools/Layout/CameraViewportAnchor.cs`。两个现有按钮显式配置Target Camera和Anchored Root；viewport=(0,0)、inset=(0.04,0.06)仅为调参起点，依据tight bounds与安全区/宽高比实测。保留Z/scale/门控，视觉和Collider同移。
- 只给真实Shared/ClueBoard_Group的PresentationSet开启 `keepVisualActiveAcrossSpaces`。保持WantsLogicalActive焦点/StateGate原语义，不给Modal或全部Shared开启；过渡输入锁、AI165压暗与板外返回回归仍必须验证。
- 审计应读得fixT5ViewportAnchors=2、fixT5ViewportAnchorInvalid=0、fixT5CluePersistentVisual=True；这些是检查目标，不能填入结果代替实测。真实世界与视口几何表仍独立测量。
- AI168新增脚本与Layout目录若缺meta，可由Unity正常导入生成必需meta并记录GUID；禁止手写meta、更改既有GUID或因此扩大业务资产范围。备份/字体171路径与组件序号/140wrap及30材质保持项不变。
