# PRE-1c-PREFAB-R1 [CODE] 批准映射的Prefab源/实例身份与事务修正

本卡是用户已批准PRE-1b/c范围内的必要修复，不扩大171行、3材质、5Prefab、CoverTitle或Git授权。AI170真实Editor预检失败，尚无生产写入；原任务保留失败，待本卡成功后由控制台Recover。不要依赖失败AI170或重跑已成功AI167/173。

先读CORE、CODE worker、SUPERVISED、用户`inputs/U1-PRE_人工反馈与字体批准_20260923.md`、PRE-1c任务卡、AI167/173报告与公开API、TK-LOC-03/G70及字体/序列化相关坑。失败证据为`outputs/U1-PRE-R1/AI-000170/AI-000170_PRE-1c_预检失败报告.md`、`approved-plan-before.json`、`verification-summary.json`。按真实源码和当前CSV/scene/Prefab只读核实，不能凭旧离线夹具判生产通过。

已核事实：raw=171、有效计划entries=63、executeAllowed=false，CatalogCard/IngredientCard/Sticker/TraySlot各BadgeLabel/NameLabel共8组CANONICAL_CONFLICT；源行FromLegacyShortCycle、场景行FromSourceHan/FromHeavy，before材质也不同。`GetCanonicalIdentity`当前仅依赖`GetPropertyModifications(text)`的字体/材质override判断后映射源身份，没有用完整批准目标语义排除错误折叠。63不是已批准将171业务对象删减为63。

## 改动清单与工具选择

| 文件 | 处置及原因 |
| --- | --- |
| Assets/Editor/Fonts/ShortCycleFontSwapTool.cs | 扩充TK-LOC-03现有预检/身份分类/真实Prefab override检测、固定事务/批次验证与恢复；复用原框架，不新建迁移器 |
| DevTools/Fonts/FontSwapDryRunHarness.cs、Test-FontSwap.ps1及必要既有Fonts测试 | 增加源与实例不同材质、继承传播/身份稳定/样例回退的回归；真实Unity6/TMP DLL编译 |
| DevTools/Fonts/README.md、LOC登记、项目文档相关节 | 写明新分类/计数/调用约束与尚待Editor复验边界，不更新完整复核日期 |

## 必须满足

1. 不改批准CSV内容/哈希（EB0CED01C1BBB0050DCF30BAA3D5354E9F2C7326C3DF97375DE87467D8FE347B）或批准旁证，不将171各行目标统一成源的材质，不删CANONICAL_CONFLICT、不伪置executeAllowed。区分真实写入对象/继承关系与相同字体值；只有before、批准after、继承/override和传播范围均等价时才可合并；不同目标的获准场景实例必须保留其独立写入身份和原风格。
2. 源/实例共享关系在font/material配对写入后可能变化。固定事务计划的身份不能因新增override、源传播或已完成批次而漂移。明确每条原始批准行由哪个写入项覆盖、顺序及源传播影响；全171行before/after审计不可仅检查选中的canonical代表。源或实例写入影响未批准对象时停止并列精确差异，不扩大权限。
3. 保留单FromSourceHan样例只改一个真实TMP→回退完整基线；样例不得通过修改Prefab源顺带改变多实例。分批、重复恢复零重复写、批间剩余/已完成项校验、非目标指纹、外部漂移拒绝、失败回退与新资产归属安全均保持。可选择实例先于源等有证据的顺序；不把未知继承变化当作本事务完成，不强迫ENGINE使用反射/private或手写事务。
4. 回退须恢复原字体/材质及其继承/override结构，重复回退幂等；不遗留获准字段以外的override，不碰布局、140wrap、未在映射内材质/Renderer/全局fallback等。若现API无法精确恢复继承，修正并增加有意义验证后才交付。
5. 测试至少覆盖：同源但不同before/after的实例不折叠；真正等价继承可去重或明确选择保守独立计划；真实同一写入位置互斥目标仍拒绝；单样例不扩散及幂等回退；多批源/实例传播、断点恢复、未知before/after和非目标漂移拒绝；所有171批准行无遗漏的覆盖计数。测试调用生产分类/事务核心，不只看源码字符串；旧功能回归不能减断言。

固定工作区D:/GameProject/Eat-What，所有queue/runner用exec_command显式shell=C:/Users/DDJ/.cache/codex-runtimes/codex-primary-runtime/dependencies/native/powershell/pwsh.exe，禁止嵌套powershell.exe或ExecutionPolicy Bypass。只在票据CLAIMED后执行；每批写入前SupervisionCheckpoint，必要时续租。CODE不调用Unity Editor、不修改任何生产scene/prefab/font/material/meta，不执行正式迁移或配表；C#引起自动导入须持有unity-project，不能去锁抢并行。

先窄回归，再一次Fonts Final（必要第二次写明新原因）。交付真实源码/DLL编译和夹具结果、每行身份与预期计数变化解释、ENGINE公开API移交及新预检要求，生产写入0。实际Editor全量预检/样例/分批/Play/Build仍留给AI170，离线通过不冒充迁移成功。输出outputs/U1-PRE-R1/<TaskID>/；Complete/Fail原样回传控制台，不自行派发后继，不Git。
