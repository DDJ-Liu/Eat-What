# 场景排布指导书 · ShortCycle_P0P1 · v0.2

> 定位：单场景"施工图"，供后续段任务作为 inputs 引用；服从手册附录 A 通则与 TOOLKIT_REGISTRY；实例问题以本书为准。
> 依据：基准 v1.7（G1~G44）、Schema v2.4、B1 v2.1.1、F2-a v0.6.1、CODEBASE_MAP（2026-09-17 复核）、组件说明文档（区域滚动 / 冰箱猫整体滚动 / 描边与阴影 / 泡泡）、AI-000067~145 结算。
> 尺度：2560×1440；PPU 100；正交 size 7.2 → 单屏 25.6 × 14.4 世界单位；三机位 x = −25.6 / 0 / +25.6。
> **v0.2 变更**：§二 从属树按 CK01-K 接管后现场重写（Director/Space/Set/Traveler、CatRig 骨架、Shared 线索板、CurrentRecipeTab、探针一步激活）；§三 ⓪ 封面态改为封面美术图承载、纸改竖版、kuang 通用底、猫身以骨架计；§四 `_TUNE` 表补镜头/锚点/滚动/字体；§五 描边改为 Defaults 资产 + 单一 CatRig 合并组，滚动改整猫随动；§六 待产清单按 ART 日报；§七 验收口径改为"开发末尾统一人工段"。v0.1 中【缺】项已到位者移除标记。

---

## 一、层级定位判定表（不变）

| 元素类别 | 判定 | 渲染载体 |
|---|---|---|
| 食谱本全部件、封面、卡片、便签、按钮 | 场景内容 | SpriteRenderer |
| 冰箱猫骨架、格件、名称/数量标签、托盘、GO 狗、返回箭头 | 场景内容 | SpriteRenderer |
| 线索板结构与内容 | 场景内容 | SpriteRenderer + 程序连线 |
| 所有文字 | 场景内容文本 | 世界空间 TextMeshPro（唯一字体 `ShortCycle_Heavy_WithFallback`，动态图集） |
| ⑤步骤详情 / 通用 modal / 悬停小卡 | Shared 模态集合 | SpriteRenderer + TMP |
| HUD | 空集 | — |
| 合并描边/阴影宿主、泡泡后景捕获 | 场景内容（程序生成宿主，普通排序） | MeshRenderer（RT） |

Canvas=0；UGUI=0（LayoutAudit 断言）。

## 二、从属结构树（2026-09-17 现场；★=本轮新增/改动）

```
ShortCycle_P0P1
├─ CameraAndStageMarkers
│   ├─ Main Camera（正交 7.2）★ 三 CamMarker 各挂 CameraFrameGizmo（Scene 视图参照框，菜单 Tools/CK01/Scene View 对齐）
│   ├─ CamMarker_Phase1_Left_TUNE / CamMarker_Phase0_Center_TUNE / CamMarker_RightReserved_TUNE
│   └─ ClueBoardAnchor_Phase0_TUNE ★(5.5, −2.1168, −0.3 中屏右页区) / ClueBoardAnchor_Phase1 (−17.664, −2.1168, −0.3)
├─ Managers
│   ├─ SessionManager ★（ShortCycleSessionManager：唯一入口；BeginSession 五步：Catalog→FridgeBind→ClueBoardBind(无菜跳过)→LocRefresh→FsmEnter；日志 [CK01-C-SESSION]）
│   ├─ PresentationDirector ★（唯一 IShortCyclePresentationHost；spaces/shared/travelers/camera/layerStack/trayPresentation；世代号）
│   ├─ InventoryManager（IShortCycleInventoryQuery；容量读 T8.demo_fridge_capacity_level=30）/ PlayerProfileManager / UnlockManager / KitchenEquipmentManager
│   ├─ CameraPanController_TUNE ★（0.45s，2-key Linear；空曲线回退线性；中途返向从当前位置发起）/ InputLockController / ActionRouter（23 动作）/ InteractionLayerStackController
│   └─ DataProcessor / SaveBoundary（占位）
├─ InteractionLayers：Layer_Phase0 / Layer_Phase1 / Layer_Modal
├─ Spaces
│   ├─ Phase0_RecipeBook ★[ShortCycleSpace：structureSets=Phase0 structure；viewTable=Cover/Catalog/Browse/ClueBoardShell]
│   │   ├─ Book_Base（dibu）/ Book_Pages（dibushangmian）★ 归"展开书结构 Set"，Cover 视图下隐藏（RendererHidden），Catalog/Browse 恢复
│   │   ├─ Cover_Group ★[Set: Cover]：CoverArt（ui_caipu_fengmian 主图；A 备用；B 装饰页角）/ CoverLabel_C_TUNE（缝线标签，本地描边 6px 深棕，ForceOff 样例）/ Bubble_01_AIGC(qipaoA)/Bubble_02_AIGC(qipaoB) + TMP / OpenCover 命中区 → open_cover
│   │   ├─ Catalog_Group [Set: Catalog，封面翻开后默认 active]：CatalogGrid_Left/Right 点位 → CatalogCard prefab ×8（pailide + 卡内照 + kuang3 菜名底 + TMP + 彩签 caipu_xiaoqian ×2 + Button）；CloseCatalog_Button_AIGC（requireSelectedRecipe=true）；FlipAnchor_L/R（左右页 4 件资产已入库，翻页未实装）
│   │   ├─ Browse_Group [Set: Browse，默认 inactive]
│   │   │   ├─ LeftPage：Title(kuang1+TMP) / DishPhoto_TUNE(zhaopian) / IngredientList(kuang2 + 图标点位) / StickerNotes(tag+TMP) / StarNotes_Deco(xingxing2) / StartCooking_Button(kaishizuofan1 底+kaishizuofan 字) / Favorite_Button(shicai_xingxing；favorite_star 候选未替换) / OpenClueBoard_Button(dakaibingxiang 气泡底候选) / StepDetail_Button(折箭头 zhifanhui 复用)
│   │   │   └─ RightPage_Reserved
│   │   ├─ CurrentRecipeTab ★[独立 Set，Browse-only，RendererHidden]（dibushangmian1）
│   │   ├─ CatalogTab_Button_TUNE（mulu_qian）★ 仅 Browse 视图显示与可点
│   │   └─ Escape_Button_TUNE ★（已配美术；语义按层：Cover=退出，其它=回退）
│   ├─ Phase1_Kitchen [ShortCycleSpace：structureSets=Phase1/Fridge/Tray + Shared ClueBoard Set]
│   │   ├─ FridgeCat_Group [Set: Fridge]
│   │   │   ├─ CatRig ★（FridgeCat_Rig.prefab 实例；唯一 SpriteOutlineGroup2D：profile Fridge，merge outline/shadow=true，后端 RT 上限 8192，18 成员，Ear_L outline ForceOff 样例）
│   │   │   │   ├─ VisualContent_TUNE ★（整猫视觉根：HeadAndTopTiers(shenti2) / Tiers(Tier_03~06，扩展层 prefab shenti) / Base_Feet(shenti3) / Ear_L(shenti5) / Ear_R(shenti4) / Arm_Raised(shenti7)→Bubble 锚点 / Tail(shenti6) / Eye_L / Eye_R(FridgeCatEye：Base/Pupil/Highlight/Glow) / _MergedShadow / _MergedOutline 宿主）— 运行时挂到 ContentArea_TUNE，**滚动=整猫位移**
│   │   │   │   ├─ ScrollController_TUNE（ScrollArea_Controller：Vertical / Discrete 整层步进 / AnchorAlignedAutoBounds）/ Viewport / TierAlignmentTarget
│   │   │   │   └─ ShelfSlots：ShelfRow_1~6 各 5 锚点 → FridgeSlot prefab ×30 ★（R01~R06；持有物从首格紧密填充，其余 inactive；BadgeLabel 数量标签）
│   │   │   ├─ ScrollRegion ★（MouseScrollableObject + ShortCycleScrollAdapter，invertPhysicalScrollDirection=true）/ FilterBar_TUNE / TidyButton_TUNE / Deco_Lines
│   │   ├─ Tray_Group [Set: Tray]：TrayBase(tuopan) / TraySlots TraySlot_01~20 / CapacityText_TUNE / GoDog_Button_TUNE→advance_to_phase2 / TrayPresentation ★（TransitionPreset ×3：Collapsed/Highlight/Detail）
│   │   ├─ Return_Button_TUNE(zhifanhui) / EquipmentEntry_Button_TUNE【缺美术】
│   ├─ RightReserved [ShortCycleSpace，空]
├─ Shared ★[ShortCycleSpace]
│   ├─ ClueBoard_Group ★[Set: ClueBoard，RendererHidden；TravelingElement 两锚点；P0 仅 ClueBoardShell 视图显示，P1 常显]
│   │   ├─ Board(ban 竖版) / Clip(ban1) / Paper(zhi 竖版) / DarkBoard(ban2)（4 件 overflowRenderers）
│   │   ├─ Content/SlotBlocks ×2~4（SlotBlock prefab：Center + ActionIcon + SubSlot_01~08_TUNE → SubCard；ClearSlot 幂等）/ TipsBubble(kuang 通用底+TMP `ui_p1_clueboard_tips.text`) / Deco（涂鸦 tuya1~3、铅笔、对勾、问号、xian1~6 手绘线）
│   ├─ StepDetailModal（纸张资产已配）/ GenericModal / HoverCard（shicai_xiaoka 底）[各 ModalSet，Layer_Modal]
└─ DebugAndReferences（根 inactive；★ 子对象 active，一步激活即可用）
    ├─ Probe_ManualVerificationDriver（13 键 + T/H；状态板跟随相机左上 3%）/ Probe_ShortCycleAutomated / Probe_FridgeScrollTrace（默认关）
    └─ ClueBoard_Sample_VerifyTemp / Ref_* / EvidenceText
```

G26 保护：DebugAndReferences 全部、LayoutAudit、两 Lab 场景（VisualEffectsLab / FridgeScrollLab）、DevTools 测试。

## 三、空间排布（数值：PSD 真值 + 参考图实测；单位画面百分比；2K 下 1% W=25.6 px、1% H=14.4 px）

**排布原则**
1. 出画许可（不变）：猫身、托盘、夹板、纸允许出画；越屏部分由所属 Set 的 `overflowRenderers`/`RendererHidden` 在镜头不在本空间时隐藏（G34 规则表）。
2. 缩放分类（不变）：图标类 512 画布统一系数；结构件按 Tight 可见区（P-026）；`sprite.bounds` 不作可见区。
3. 三段横向布局与镜头平移（不变）；平移曲线 0.45s 线性（D-C）。
4. ★ 猫身尺度以骨架 `HeadAndTopTiers` 可见宽对 51% W；拆分件除 shenti2 外为旧尺度，prefab 内 `_ScaleComp=1.386`（美术重导后归 1）。

**Phase 1 左屏**（与 v0.1 同，变更行标 ★）
| 元素 | 中心/锚定 | 尺寸 | 角度 | 备注 |
|---|---|---|---|---|
| 便签深色板 ban2 | (81%, 18%) | 宽 37.5% W | 0 | |
| ★ 冰箱猫骨架 | 躯干中心 (42%, 50%)；头顶 −3% H | 躯干 51% W；6 层可见 2~3 层，其余滚动 | 0 | 整猫随动，层高 `_TUNE` |
| 眼光 | 眼位相对猫 bbox (35.5%,12%)/(60%,12%) | 猫宽 16% | — | Eye prefab 内 |
| 格架图标行 | 每层 5 列 x 24.5/31.5/39.5/45.5/53%；行距 `_TUNE` | 系数 0.62 | — | 30 槽 |
| 名称/数量标签 | 图标 +2% 下方 | 134×90 | — | TextFitter；BadgeLabel |
| 对白气泡 ×2 ★ | (4.9%, 21.3%) / (14.4%, 23.6%) | 222×230 / 260×227 | +8/+6 | qipaoA/B 已配 |
| 托盘 | 右缘 62.4% W、顶缘 70.9% H | 80% W | 0 | 20 锚点固定 |
| GO 狗 | (58%, 85%) | 17% W | 0 | `_TUNE` |
| ★ 夹板 ban（竖版） | (81%, 64.7%) | 高 104% H、宽 36% W | +5 | 底出画 |
| ★ 纸 zhi（竖版） | 板内框左对齐、顶 15.5% H | 高 88% H | +5 | 不再右溢 |
| 夹子 ban1 | (79%, 14.5%) | 18% W | +5 | |
| 区块 SlotBlock | (80%,42%)/(80%,75%)；SubSlot 8 锚点偏移同 v0.1 | 中央 0.60 / 卡内 0.19 | −3 | 首行遮挡已修（REVIEW-T6a） |
| 之字连线/节点 | 同 v0.1 | 9px | — | 手绘线资产 xian1~6 可替代程序线 |
| ★ TIPS 底 | (88.5%, 55%) | 21% × 10% | 0 | kuang 通用底 + `ui_p1_clueboard_tips.text` |
| 返回箭头 / 筛选栏 / 一键整理 / 厨具入口 | `_TUNE` | | | 后两者美术缺 |

**Phase 0 中屏 ①页 / ③页**：数值同 v0.1；变更：
- ★ 标题底/清单底/菜名底均用同一张 `kuang` 通用底（三资产名保留），kuang3 按卡宽 72%。
- ★ 目录页签 mulu_qian (8%,18%)、当前菜谱小签 dibushangmian1 (9%,32.5%)、星标 shicai_xingxing (47%,12%)、打开冰箱 dakaibingxiang (20%,83%)、ESC (5%,92%) 均已配。
- ★ ⓪ 封面态：封面主图 `fengmian` 覆盖整书区域 (52.5%,48.5%) 宽 87% W；B 装饰右下页角；C 缝线标签 `_TUNE`；两气泡 (与 P1 气泡同资产) `_TUNE`；书底/双页隐藏。
- 线索板展开态 ④：锚点 (5.5, −2.1168) → 覆盖右页区，构图 `_TUNE`（H-04，F2-a 待补状态图）。

## 四、`_TUNE` 清单（人工终调对象；★ 新增）

GoDog_Button / CapacityText / FilterBar / TidyButton / TraySlot_01~20 / SubSlot_01~08 / 便签点位 / 成品照倾角 / 格件缩放与行距 / 返回箭头 / 厨具入口 / ★ CameraPanController（时长 0.45s、曲线 2-key Linear）/ ★ 三 CamMarker / ★ ClueBoardAnchor_Phase0 / ★ ScrollController（stepSize、AnchorAlignedAutoBounds、invert 方向）/ ★ Tray 三态 Preset（Highlight y+0.08 scale 1.025；Detail y+0.18 scale 1.05）/ ★ CoverLabel_C / ★ 封面气泡位 / ★ 描边：各单件本地值与 CatRig 组值（见 §五）/ ★ 字体图集（动态，当前 216 字形为基线）。
全工程 `_TUNE` 审查：用户明确本轮不安排（基线 §4）。

## 五、排布工具与配置

- 阵列点位：LayoutTools 仅规则阵列；托盘 20 锚点、SubSlot 8 锚点、ShelfRow 锚点为手工/prefab 定点。
- ★ **描边/阴影**（详见《描边与阴影_配置与使用说明》）：默认值来自 `Assets/Resources/SpriteOutlineDefaults.asset`（组件 Reset 时读一次，之后手工值）；**全场景唯一 Group = CatRig**（19 个旧 Group 已移除，单件转本地值）；单件字段：`OverrideGroup`（跟组）/ `MergeOutline`、`MergeShadow` 三态 / HDR 颜色含 Alpha；合并=逐组 alpha 遮罩 + 双宿主 RT，接缝不描内边；Hover 由 Binding 按当前值倍率并恢复。v0.1 §五描边表作废。
- ★ **滚动**（《区域滚动_配置与复用说明》《冰箱猫整体滚动》）：`ScrollArea_Controller` 通用；冰箱经 Adapter → Router → FridgeBinder → Rig；整层步进；6 层 30 槽；`ApplyFilterView` 留位未接。
- ★ **镜头**：`CameraPanController_TUNE` 0.45s 线性；跨空间才平移并持锁；同 P0 视图切换不平移。
- ★ **参照框**：`CameraFrameGizmo`（TK-DBG-06）三机位 25.6×14.4 框 + 10% 网格；菜单对齐 Scene 视图。
- 文本：TMP 世界空间；`LocalizedText` 绑 key（G33 UI 段 key `ui_<space>_<element>.text`）；缺 key 显示可见回退。
- 交互：Button_MouseInteract → MouseActionBinding → ActionRouter（23 动作：session 13 + close_cover + tray/fridge/inventory/equipment 桩 9 中 `fridge.scroll` 已实装）；StateGatedInteraction 由 Set 驱动。
- 过渡：Transition 家族（Position/Rotation/Preset 已落）；Traveler `SnapTo/MoveTo`。

## 六、资产依赖与待产（ART 日报 §4 为权威）

已入库并配置：封面 A/B/C/D、气泡 A/B、dakaibingxiang、mulu_qian、dibushangmian1、caipu_xiaoqian、shicai_xiaoka、xingxing/xingxing2、kuang 通用底、pailide、zhaopian、tag、toumingjiao、竖版 ban/zhi/ban1、拆分 14 件、涂鸦/线/铅笔/对勾/问号、清汤面菜品图、favorite_star（未替换）。
仍缺：`_straight`×5（C-T5b-X 挂起）、拆分 13 件 E6 重导（`_ScaleComp` 归 1 挂起）、`ui_tag_*`、`ui_gongju_*`（caidao 改名 512）、Tidy/EquipmentEntry 按钮、UnknownCard（未解锁素材归档待确认）、`ui_shicai_fanqie/xiaocong/judan`、`prd_unknown` 图标；`BingXiangMao/yanguang` 重复件待清理。
导入规则：先比对与最终路径命名审批，再正式导入；Tight；MaxSize 2 次幂封顶 4096（合并后端 RT 另计）。

## 七、验收口径（本轮起）

- 人工审查统一后置至开发末尾；机器门（LayoutAudit 全绿、Console 0、Missing 0、scene clean、冻结哈希、启用集合断言 ≥ 基线、G26 对象只增不减）通过即续段。
- 排布类任务：换图对照表、可见区审计三份 v2、度量与写入分离（模板 §7）。
- 人工段清单以《人工段流程 v2》为准；描边终值、`_TUNE`、字体现场以人工验收后的现场为新基线，不用历史备份覆盖。
- 三处实机截图（P0_Cover / P0_Catalog / P0_Browse / P1_Kitchen）与参考图对照，误差 ≤2% W/H。

*变更记录*：v0.1 2026-09-01｜v0.2 2026-09-18（本文）。
