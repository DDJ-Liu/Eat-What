# DATA-VIS-1 [CODE] 可见 DATA 正式路由与工作流接通
用户来源：.ai-workspace/inputs/DATA-VISIBLE_外显配表线授权与接力_20260923.md。新可见任务已创建，threadId=01a0ce9d-8e5a-7542-82b6-6d27609d99e0，host=local，工作区D:/GameProject/Eat-What。本卡只做队列/工作流代码；不跑配表，不启动Unity，不手改runtime、不操作应用创建/绑定。实际绑定和首次派发由控制台在本卡成功后完成。

## 代码改动清单与工具层判断
复用 .ai-workspace/toolkit/WF.md 的 TK-WF-02（同一队列/轮次/隔离导表）和 TK-WF-03（计量/验证），不新建平行调度器。现有能力足够支撑导表，缺口仅是正式绑定/查询及所有路由返回、协议一致性；在原模块扩充。
| 文件 | 处置 | 改动要点 / 归属 |
| --- | --- | --- |
| .ai-workspace/queue.ps1 | 扩充 | 正式控制绑定/状态查询API；Get-PipelineExecutionTarget、RegisterDataLane、ConsumeDataRound、各模式hand-off统一读取真实绑定；状态原子保存/审计，旧worker兼容 |
| .ai-workspace/supervised.ps1 | 必要修改 | 派发/预约/令牌/状态查询随绑定一致；不改变其它车道的停止/租约/恢复/资源语义 |
| .ai-workspace/tests/Test-DataLane.ps1 及既有模式/监管路由测试 | 扩充 | 临时工作区回归绑定、互斥、旧票据、停止、消费及生命周期；不得用生产runtime造夹具 |
| .ai-workspace/workers/DATA.md、CODE.md、ENGINE_MCP.md | 更新相关段 | 后续配表处理统一可见DATA；CODE保留工具/源码，ENGINE保留接线/验证，不代跑导表 |
| .ai-workspace/CONTROL_CHAT.md、SUPERVISED.md、WORKFLOW.md、protocol/对应FULL文档、templates/SUPERVISED_HEARTBEAT.md、PIPELINES.md | 更新受影响段 | 按真实executorKind/threadId投递/核查/回传，消除当前规则中强制内部子代理的冲突；历史明确保留 |
| DevTools/DataTables/DATA_PIPELINE.md、.ai-workspace/toolkit/WF.md、CODEBASE_MAP.md、项目整体阅读理解与推进基线_2026-08-14.md | 更新相关段 | 可见入口及部署绑定步骤、长期分工与当前完成边界；不改整体验证日期 |
| DevTools/Workflow/Invoke-TaskTool.ps1 | 必要最小修正 | 本卡拟使用的计量包装仍强制ExecutionPolicy Bypass，移除该参数并保留正常PS7/exitcode/返回体计量，相关既有回归复核；不改系统策略 |

## 入口、保持项
先读 .ai-workspace/CORE.md、.ai-workspace/workers/CODE.md、.ai-workspace/protocol/SUPERVISED_FULL.md、.ai-workspace/protocol/CONTROL_CHAT_FULL.md 的配表拆分/监管节、用户新授权、DATA worker与操作说明、项目文档页首/数据/工作流节、P-019/P-032/P-033/P-037/P-047、TK-WF-02/03。检查Git、真实队列源码/调用点与已有测试。
普通PowerShell7固定 C:/Users/DDJ/.cache/codex-runtimes/codex-primary-runtime/dependencies/native/powershell/pwsh.exe。每批修改前SupervisionCheckpoint；共用队列脚本的变更必须在完整候选脚本解析/窄验证后原子替换，避免其它执行器读取半写文件。不手工改任何生产runtime，不重置任务/已有绑定/历史，不改原模式或自动化。其它活跃任务的文档改动先重读再小段合并，不能覆盖他人内容。

## 必须实现
1. 新增明确的控制API（建议 BindDataPipeline -PipelineThreadId 与 DataLaneStatus，若名称不同报告精确用法）。复用已有PipelineThreadId参数与队列锁，绑定可查询、幂等、有前后值/时间/真实UserDecision/Verification记录。有效目标须非空合法线程ID，不得等于CODE/ENGINE/ART/控制台。不把format校验冒充应用可达；可达和真实闲置由控制台工具核实后提供证据。
2. 注册旧worker保持兼容，不丢lease/circuit/errorHistory。绑定只允许DATA idle、无RUNNING/activeTaskId/BUSY和未消费预约；冲突或不明确归属零状态写入。重复同绑定幂等；替换已有绑定必须明确新授权并在安全状态，旧票据不得跨路由消费。绑定后 route缺失/无效不得静默退回子代理/其它线，Fail closed并报告。
3. 消除当前3处以上硬编码：Get-PipelineExecutionTarget(DATA)、RegisterDataLane返回、ConsumeDataRound返回，以及全仓实际调用到的 MANUAL/AUTOMATIC/SUPERVISED 派发/回报/状态；只保留迁移前旧worker的明确兼容分支。正式绑定后所有DATA返回executorKind=THREAD、精确新threadId，已成功AI164记录不重写。
4. token/租约/停止/过期/资源/恢复上限不削弱；route改变导致票据不能误投/误领。DATA仍同一队列单并发，与CODE/ENGINE真正共享的data-batch/generated-assets/font-assets及物理发布锁保持。工作流源码扩充不绕过权限或让DATA获得其它pipeline执行资格。
5. 配表需求继续按用户内容轮次→DATA→必要ENGINE拆分。真实USER-U1 DONE/CSV哈希/幂等消费不变；所有新配表处理任务统一Pipeline DATA并投可见线，直接给DATA无票据的新需求回控制台编排。CODE只修工具/schema/业务源码，ENGINE只接线/验证；不得在本卡伪造DONE/发布/重跑AI164。
6. 不新增定时领取日程、不恢复旧四条、不改ART服务。生产绑定留给控制台，CODE只交API/回归/操作说明。

## 验证和交付
在临时fixture实跑：旧注册兼容；绑定/读回/重复；非法目标及BUSY/RUNNING/有效预约拒绝且状态不变；绑定前旧票据失效或拒绝绑定；绑定后SUPERVISED实际Poll→Checkpoint→Complete→正确supervisorHandoff；AUTOMATIC后继及MANUAL路由；Pause/Exit和令牌/租约保持；DONE消费精确DATA线程/幂等与非DONE/漂移拒绝；DATA单线与资源冲突阻止重复领取。覆盖应调用真实生产函数/队列接口，不只断言源码字符串。
只运行受影响DataLane/监管/模式/用量回归，最终一次汇总，必要第二次记录新原因；不为路由变更重跑Unitybatch。若现测试在活跃队列下把其它任务合法变化误判污染，使用夹具专属断言并说明，不锁死/回滚生产状态。
输出 .ai-workspace/outputs/DATA-VISIBLE/<TaskID>/，六要素报告写精确API、绑定前置、安全停止、测试结果、尚未真实绑定的边界、路由/文档变更。Complete后原样发supervisorHandoff到控制台，不向DATA直接派发，不自签真实可见线首次验收。无Git提交/推送。
