# DATA-VIS-2 [DATA] 外显配表线首次领取与回传验证

队列宿主必须显式指定：exec_command的shell=`C:/Users/DDJ/.cache/codex-runtimes/codex-primary-runtime/dependencies/native/powershell/pwsh.exe`，在此宿主直接`& ./.ai-workspace/queue.ps1 ...`。不得在外层PS7再嵌套`powershell.exe`；AI170已实证该旧宿主导致有效票据的指纹误拒绝。本卡仍仅一次有效票据Poll，不自行重领。
来源：.ai-workspace/inputs/DATA-VISIBLE_外显配表线授权与接力_20260923.md。固定可见执行任务 01a0ce9d-8e5a-7542-82b6-6d27609d99e0（AI流水线-配表DATA），工作区D:/GameProject/Eat-What。本卡是明确授权的路由只读验收，不是USER-U1内容轮次，不启动Unitybatch、不发布、不写DONE、不重跑AI164。

先读 .ai-workspace/CORE.md、.ai-workspace/workers/DATA.md、.ai-workspace/SUPERVISED.md、DevTools/DataTables/DATA_PIPELINE.md、新授权以及前置DATA-VIS-1报告的实际API。以控制台传来的本TaskId/DispatchToken用正常PS7 Poll一次，仅在CLAIMED后工作；activeTask权威，不重领。检查点/续租/停止/Complete/Fail均走队列，runtime不直接写。

验收目标：证明这一新可见任务从正式DATA路由取得真实票据并领取本任务，执行只读检查，返回控制台，且既有配表源/生成物/字体/用户轮次无本卡写入。
1. 正式绑定状态须THREAD且threadId精确匹配本任务，数据worker activeTaskId等于本卡，pipeline DATA、当前session正确。若还为CONTROL_SUBAGENT或目标不对，停止报告控制台，不能借内部代理完成。
2. SupervisionCheckpoint实际继续后只读核对DATA_PIPELINE的导表入口、锁、真实DONE前提与AI164结果可达，不运行导表、不新造fake生产轮次，不人为占/改许可。
3. 输出可见线程/任务号/session/领取及检查点回执，记录当前CSV/生成目录/字体/USER_WORK_STATUS与data-rounds前后哈希（只针对本轮稳定受保护范围，持有本卡声明资源）；核实本轮无生产改写。任何差异先核归属，不回滚别人改动，不把外部变化虚称自身零变化证明。
4. 六要素简报写 .ai-workspace/outputs/DATA-VISIBLE/<TaskID>/；记录实际工具返回体/阶段，provider token/model未知null+原因。Complete后把supervisorHandoff完整原样发送控制台 01a08798-8b2a-7d41-9aa8-ab44affd520a 并结束。控制台核实收到和队列SUCCEEDED后才认定路由接通完成。
5. 后续所有配表处理只在本可见线按票据执行，直接内容要求先转控制台编排，USER-U1内容审核仍由用户负责。没有任务时待命，不主动Poll或创建日程；本轮无人工视觉验收要求、无Git授权。
