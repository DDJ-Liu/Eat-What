# 外显 DATA 配表线：用户授权与接力

日期：2026-09-23。用户原话：“增加额外任务，建立一条外显的data流水线，保证后续所有的配表处理放在这条独立流水线上进行处理”。保持当前 SUPERVISED，不停止或重跑原任务链。

## 当前事实与新决定

- 现有 DATA 已注册，AI164 两个隔离验证用例已经 SUCCEEDED/VERIFIED；本轮不重跑，不发布数据，不改 USER-U1 DONE。
- 创建时的旧实现将DATA硬编码为CONTROL_SUBAGENT/null；AI174现已交付真实THREAD路由，控制台已正式绑定。2026-09-24首次真实领取/回报验收AI175已SUCCEEDED/VERIFIED，详见文末最新事实。
- 新建常驻可见任务“AI流水线-配表DATA”，固定使用用户指定的现有工作区 D:/GameProject/Eat-What。它与 CODE/ENGINE 使用同一队列、租约、票据和控制台；隔离导表继续使用既有 batch 副本，不能用第二个 Git worktree 替代正式配表源。
- 旧文档“DATA 必须为控制台子代理、不能有固定线程”的结论由本次用户决定覆盖；历史 AI164 归属和结果保留。正式绑定后后续配表处理都派到可见 DATA；不得静默回退 CODE/ENGINE/内部子代理。

## 实施安排

1. 控制台创建可见任务。其第一次消息仅接收职责、只读核对并返回待命回执，不自行 Poll，不运行导表，不修改生产文件。
2. CODE 扩充既有 TK-WF-02：正式路由绑定/查询 API，统一所有派发与接力返回，保留票据、停止、租约、锁和轮次门禁；临时夹具覆盖绑定、冲突、失效令牌、各模式路由与回报。
3. 控制台在 CODE 成功后核实 DATA 真实 idle、无 RUNNING/未消费 DATA 预约，通过正式 API 绑定新任务。读回 THREAD/精确 threadId，确认接通，再向其投递 DATA 验证卡。
4. 可见 DATA 用真实票据完成一次领取→检查点→只读路由/生产不变核对→Complete→控制台收到 supervisorHandoff。不重复 AI164 batch，不伪造用户内容轮次。仅 CODE 测试通过不能代替此验收。

## 长期职责与边界

后续配表内容校验、导表、生成物 diff/catalog、字形需求与报告统一归 DATA。控制台负责任务编排；用户仍负责实际内容审核与 USER-U1-Rn DONE；CODE 只负责 schema/导表工具或业务源码开发修复，ENGINE 只负责需要的引擎引用/运行验证，不能代执行配表处理。直接发给 DATA 的新需求如无有效任务票据，应报告控制台安排，不能绕过当前模式自行执行。

沿用 TK-WF-02 的隔离 batch、准确退出码/nonce、共享 data-publication.lock、源/目标哈希和事务回退；正常轮次只有真实 DONE 才可 ConsumeDataRound。字体仍单独保护，不自动提交或发布；Git 提交/推送、共享许可与旧定时服务配置均不在本轮范围。无需新增定时领取服务，继续由当前控制台监管派发。

生产 runtime 不手改。绑定事实、任务编号、应用创建回执与测试结果在 `.ai-workspace/outputs/control/DATA-VISIBLE-20260923/`；本轮任务卡由控制台另行保存。未完成正式绑定及真实 DATA 回报前，状态只能为“可见入口已创建，路由接通待验证”。

## 已落实编排

- 可见任务：AI流水线-配表DATA，threadId=`01a0ce9d-8e5a-7542-82b6-6d27609d99e0`，host=`local`，现有工程项目ID=`7a349a7f-7f58-49aa-944b-4b4eeb8aba30`。应用创建成功，首次只读入驻完成并返回idle，未Poll/写生产/启动Unity。
- AI-000174 / DATA-VIS-1 / CODE：正式路由改造与回归，依赖AI173、AI168；资源workflow-devtools/workflow-router，不触发Unity导入。卡见 `.ai-workspace/inputs/DATA-VISIBLE-20260923/DATA-VIS-1_CODE.md`。
- AI-000175 / DATA-VIS-2 / DATA：新线真实票据领取、只读验收、Complete回报，依赖AI174；控制台必须先完成正式绑定再派。卡见 `.ai-workspace/inputs/DATA-VISIBLE-20260923/DATA-VIS-2_DATA.md`。
- 已通过正式API Extend至原session `8c12e025cc374865a99cca4042cda1ac`，scope AI167–175。原AI173仍在CODE执行，新卡均QUEUED；原任务依赖和历史未修改。监管ai保持ACTIVE并加入绑定/接力要求，未新增定时服务。

## 控制台正式绑定事实（2026-09-23 23:24）

AI174已SUCCEEDED，Workflow第二次Final 6/6通过；首轮DocumentationIndex测试观察及PENDING_USER保留，不构成人工闸门。控制台核对报告、实际测试历史与源码SHA，未重跑已成功前置。

应用证据确认CODE和DATA真实idle/completed，ENGINE真实active/inProgress；DATA同工作区且无RUNNING、activeTaskId、lease或预约。经正式BindDataPipeline完成同一worker的原子绑定，并由DataLaneStatus读回THREAD / 01a0ce9d-8e5a-7542-82b6-6d27609d99e0 / routeRevision=1。证据见outputs/control/DATA-VISIBLE-20260923/ai174-bind-app-evidence.json、data-lane-bind.json及data-lane-after-bind.json。

本轮Reconcile仅传真实idle的CODE/DATA，无修复；Dispatch扫描全scope，AI175依赖满足但共享unity-project被AI169持有，未出票、未发送、未领取。继续原监管，等资源可用后按正式票据派发AI175；不缩锁、不交子代理。生产路由绑定完成不等于首次端到端验收完成，无USER-U1 DONE或数据发布。原ai日程已同步最新接力，保持ACTIVE。
## 23:56首次真实领取
AI170字体只读预检失败后共享资源释放。控制台按原序出票投递AI175；可见DATA已于2026-09-23 23:56:20真实CLAIMED/RUNNING，路由THREAD/revision1未变。证据outputs/control/DATA-VISIBLE-20260923/ai175-claim-check.json。AI175只读核验仍进行中，尚未Complete，不预签接通；新CODE修复AI176等待相同资源锁。

## 2026-09-24 端到端验收完成
AI175于00:01:21通过正式Complete结算SUCCEEDED/VERIFIED；本轮控制台读取真实应用完成回执、队列状态、handoff-delivery及六范围哈希对照，确认领取、三次检查点和原样回报均完成，452文件0差异、发布锁已释放。路由保持THREAD/原可见DATA任务/revision1，不再是待验证状态。未导表/发布/代写USER-U1 DONE，不重跑AI164；AI174原TEST_OBSERVATION/PENDING_USER继续保留。证据outputs/DATA-VISIBLE/AI-000175/及outputs/control/DATA-VISIBLE-20260923/ai175-complete-*.json。共享资源释放后全scope正式Dispatch已向CODE投递AI176，AI170保持原失败等待修复；未Reset或提前Recover。
