# AI 工作流协议 · 核心入口

先读 [CORE.md](CORE.md)。队列动作、状态机、问题分级、熔断、租约、恢复、完成门槛和测试移交的完整现行规则在 [protocol/WORKFLOW_FULL.md](protocol/WORKFLOW_FULL.md)。本文件是兼容入口，不替代完整协议。

## 执行最短路径

1. 按任务卡指定的模式、车道、TaskId、TriggerSource 与 DispatchToken 领取；非 `CLAIMED/CLAIMED_RETRY` 不执行。
2. 领取后只处理该任务；按任务卡和 worker 限制写入，长任务按协议续租。
3. 成功且完成相称验证后 `Complete`；真实阻断按分级 `Fail`；监管任务先执行 `SupervisionCheckpoint`。
4. `Complete/Fail/Yield` 返回 handoff 时，把原消息发送到指定线程，然后停止；不得自行改模式或派发未授权后继。

DATA 车道沿用同一队列/token/lease/停止门。旧注册态仅兼容 `executorKind=CONTROL_SUBAGENT`；控制台用 `DataLaneStatus` 核查闲置/预约，再以 `BindDataPipeline -PipelineThreadId <id> -UserDecision <授权> -Verification <应用可达与闲置证据>` 原子绑定可见线程。绑定后所有路由必须为 `THREAD` 与精确 `threadId`，缺失/损坏时拒绝回退；轮次与隔离发布入口见 [workers/DATA.md](workers/DATA.md) 和 [DATA_PIPELINE.md](../DevTools/DataTables/DATA_PIPELINE.md)。

详细节索引：运行模式 §0；不变量 §1；车道 §2；状态 §3；领取 §4；问题分级 §5；熔断 §6；维护 §7；完成门槛 §8。
