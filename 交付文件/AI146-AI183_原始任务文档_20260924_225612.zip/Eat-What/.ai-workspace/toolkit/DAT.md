# 工具库 · DAT

> 从 [INDEX.md](INDEX.md) 定位；状态与公开面沿用原登记。

<a id="tk-dat-01"></a>
<a id="tk-dat-02"></a>
<a id="tk-dat-03"></a>
<a id="tk-dat-04"></a>
<a id="tk-dat-05"></a>
<a id="tk-dat-06"></a>
<a id="tk-dat-07"></a>

## 5. DAT · 数据

| ID | 名称 / 路径 | 能力 | 公开面 | 状态 | 消费方 | 来源 | 备注 |
|---|---|---|---|---|---|---|---|
| TK-DAT-01 | `CK01GeneratedDataCatalog` + 导表器（Editor） | 十四表聚合入口、稳定 ID 与 v2.4 约束/容量只读解析；隔离 batch 入口及当前run完成凭据 | `TryGetRecipe` `TryGetInitialInventory` `TryGetRecipeWhitelist` `TryGetAreaConstraint` `TryGetUnknownProductResolver` `TryGetDemoFridgeCapacity` `UnknownProductItemId` `DemoFridgeCapacityLevel`；`DataTableImportService.ImportAllBatch()` | 沿用 | 全部 Binder；DATA 隔离导表；后续 P2 | C-T4B / B-T5 / AI-000077 / AI-000082 / AI-000163 / AI-000166 | **唯一**数据入口（G8）；batch 复用 `ImportAll`，失败 `[DATA]`+Exit(1)，再接 PRE-1 字体重建；AI166仅在两者成功后用项目CSV parser写唯一runId/nonce、238字形与字体manifest凭据，Runner核验后才记成功。AI164正常宿主两次真实Unity验证已通过（0/1差异、独立nonce、238字形、Static不重写），未发布；新增属性复用既有 Try 链，缺失/无效配置显式抛错且无硬编码兜底 |
| TK-DAT-02 | `SerializableDictionary<K,V>` `DataBase/` | 可序列化字典 | — | 沿用 | — | CK01-A | |
| TK-DAT-03 | `DataEncryptor` | 存档加密 | — | 沿用 | —（SaveBoundary） | CK01-A | |
| TK-DAT-04 | `DataBaseManager` / SpreadsheetData | 旧配表体系 | — | 弃用 | 旧场景 | CK01-A #16 | 禁止新增依赖 |
| TK-DAT-05 | **`TagFilter`（拟）** | 带 tag 集合的单/多选筛选输出可见集合（纯 C#） | 拟 | 规划中 | 格架筛选 / 目录筛选 / P2 分类 | T-03 | 可单测 |
| TK-DAT-06 | **`PlaceholderRule`（拟）** | 数据到位/缺失/AIGC 三态占位统一（纯 C#） | 拟 | 规划中 | 全游戏 | T-05 | B1 3.7 |
| TK-DAT-07 | `DevTools/DataTables/Authoring/` 配表往返工具 | 14 表 CSV↔Excel 双入口、共享校验、空表保护与 G53 新字形清单 | `New-AuthoringWorkbook.ps1` `Export-AuthoringToCsv.ps1` `Import-CsvToAuthoring.ps1` `Invoke-DataTableAuthoring.ps1`；`Validate-DataTables.ps1 -Quick` | 沿用·编辑器外回归通过 | USER-U1 配表；F4-ENGINE 导表前置 | AI-000150 / F3-CODE | 仅编辑器外数据源工具；UTF-8 无 BOM + CRLF；不导入 Unity、不改字体；Excel/CSV 两入口共用 V-01～V-12 与跨表审计 |
