# 监管模式（SUPERVISED）· 核心入口

2026-09-24 17:30 用户改为手动诊断：已正式 ExitSupervision，当前 MANUAL / PAUSED_MODE，stopRequested、exitRequested=true，原 ai 保持 PAUSED。仅诊断，不修复/回退/重试/派发。已用不保存的材质副本复现 FromHeavy 的 TMP ScaleRatioA/B/C 重算导致指纹失效；回退在复制备份前被同一材质守卫拦住。40 条 kern 非目标 override 来源已定位为旧字段加载转换及保存结构保护缺口，另有 ROLLBACK_FAILED 重入条件的源码推导，未执行重入。失败现场24文件及字体/CSV10文件本轮SHA不变，部分保存状态尚未恢复；原错误/恢复史和人工结论不改。详细报告：`.ai-workspace/outputs/control/U1-PRE-R1-20260923/manual-diagnosis-20260924/AI170失败原因定位报告.md`。下方较早接力均为历史，不构成新的执行授权；本条专项核验不提升完整复核日期。

2026-09-24 17:16 最新停止状态：AI170第7次执行真实失败，full事务ROLLBACK_FAILED、第一批APPLYING，原7错误/6issue/6恢复完整保留。单FromSourceHan样例1项已成功并回退，但全量第一批FromHeavy新材质出现OWNED_MATERIAL_DRIFT且公开回退同样失败；不能称零写入或已恢复。控制台只读核实两场景SHA已变、五Prefab与7个既有meta不变，三新材质保留，其中FromHeavy内容SHA与创建记录不同；主场景另有40条新增m_ActiveFontFeatures.Array.data[0] override待归属核验。正式备份和样例快照各14文件均匹配，失败现场另保全24文件。17:20主Editor单ShortCycle/Edit/clean/Console0仅表示无未保存脏场景，不代表磁盘已回基线。session CIRCUIT、stopRequested=true，原ai已PAUSED；CODE/ENGINE均idle，不Reconcile放行、不派发、不追加补丁/Reset/换key绕最后额度。原批准有效，需用户明确新的现场诊断与受控恢复范围，不能自动继续全量迁移。详细报告outputs/control/U1-PRE-R1-20260923/AI170第七轮失败现场与全队列未关闭清单.md；AI171/172等待，DATA已验保持，人审/Git/E2条件不变。

共同规则先读 [CORE.md](CORE.md)；监管模式的权限、人工闸门、并行、补漏、自愈、恢复、暂停与 heartbeat 契约完整保留在 [protocol/SUPERVISED_FULL.md](protocol/SUPERVISED_FULL.md)。

执行器必须使用任务卡给出的 `TaskId` 与 `DispatchToken`，在每个生产写入批次前执行 `SupervisionCheckpoint`。已有用户授权不等于平台权限已放行；平台拒绝时按完整协议记录并停止，不绕过。`Complete/Fail/Yield` 的 `supervisorHandoff` 必须原样回传控制线程，随后结束本轮。

控制端不得只依赖完成消息推进：事件回报为主、定时补漏为辅；漏触发按完整协议自愈，不能重复领取或跳过人工闸门。

DATA 可见线程路由 API 已由 AI174 实现：`DataLaneStatus` 查询，`BindDataPipeline` 绑定；预约记录携带 route key，旧票据不得跨路由消费。控制台于2026-09-23 23:24核实应用可达、同工程和真实idle后完成生产绑定，读回 `THREAD` / `01a0ce9d-8e5a-7542-82b6-6d27609d99e0` / routeRevision=1。AI169已SUCCEEDED/PENDING_USER；AI170首轮真实预检失败、零生产写入；AI176现已SUCCEEDED/VERIFIED，控制台核源码/测试/基线后正式Recover AI170并投递新票据，保留原失败与第1条恢复记录。2026-09-24控制台已核实AI175为SUCCEEDED/VERIFIED，真实领取、检查点、Complete及原样handoff均闭环，6范围452文件0差异、发布锁释放；可见DATA线端到端验收完成。后续继续按正式票据派发，不交旧子代理。token、lease、检查点、停止和 DATA/ENGINE 共享发布锁不降级。详见 [新增授权与接力](inputs/DATA-VISIBLE_外显配表线授权与接力_20260923.md)。
