# 控制任务约定 · 核心入口

2026-09-24 17:30 用户改为手动诊断：已正式 ExitSupervision，当前 MANUAL / PAUSED_MODE，stopRequested、exitRequested=true，原 ai 保持 PAUSED。仅诊断，不修复/回退/重试/派发。已用不保存的材质副本复现 FromHeavy 的 TMP ScaleRatioA/B/C 重算导致指纹失效；回退在复制备份前被同一材质守卫拦住。40 条 kern 非目标 override 来源已定位为旧字段加载转换及保存结构保护缺口，另有 ROLLBACK_FAILED 重入条件的源码推导，未执行重入。失败现场24文件及字体/CSV10文件本轮SHA不变，部分保存状态尚未恢复；原错误/恢复史和人工结论不改。详细报告：`.ai-workspace/outputs/control/U1-PRE-R1-20260923/manual-diagnosis-20260924/AI170失败原因定位报告.md`。下方较早接力均为历史，不构成新的执行授权；本条专项核验不提升完整复核日期。

2026-09-24 17:16 最新停止状态：AI170第7次执行真实失败，full事务ROLLBACK_FAILED、第一批APPLYING，原7错误/6issue/6恢复完整保留。单FromSourceHan样例1项已成功并回退，但全量第一批FromHeavy新材质出现OWNED_MATERIAL_DRIFT且公开回退同样失败；不能称零写入或已恢复。控制台只读核实两场景SHA已变、五Prefab与7个既有meta不变，三新材质保留，其中FromHeavy内容SHA与创建记录不同；主场景另有40条新增m_ActiveFontFeatures.Array.data[0] override待归属核验。正式备份和样例快照各14文件均匹配，失败现场另保全24文件。17:20主Editor单ShortCycle/Edit/clean/Console0仅表示无未保存脏场景，不代表磁盘已回基线。session CIRCUIT、stopRequested=true，原ai已PAUSED；CODE/ENGINE均idle，不Reconcile放行、不派发、不追加补丁/Reset/换key绕最后额度。原批准有效，需用户明确新的现场诊断与受控恢复范围，不能自动继续全量迁移。详细报告outputs/control/U1-PRE-R1-20260923/AI170第七轮失败现场与全队列未关闭清单.md；AI171/172等待，DATA已验保持，人审/Git/E2条件不变。

共同规则先读 [CORE.md](CORE.md)。模式切换、入队、依赖、G64 `[USER]` 伪车道、常驻输入、配表拆分、高风险试产、G26、人工恢复和定时巡检的完整现行规则在 [protocol/CONTROL_CHAT_FULL.md](protocol/CONTROL_CHAT_FULL.md)。

2026-09-23 用户新增外显 DATA 线：[授权与接力](inputs/DATA-VISIBLE_外显配表线授权与接力_20260923.md)。AI174已成功交付正式查询/绑定API，控制台23:24核实应用可达、同工程和真实idle后完成绑定：`THREAD` / `01a0ce9d-8e5a-7542-82b6-6d27609d99e0` / routeRevision=1。AI169已完成；AI170首轮预检失败且零生产写入；AI176已成功并经源码/测试/基线核实，控制台正式Recover AI170并投递新票据，保留全部失败史。2026-09-24已核实AI175 SUCCEEDED/VERIFIED、真实领取/检查点/Complete/handoff闭环及452文件0差异，外显DATA线端到端接通。共享锁已释放并按全scope派发AI176，后续仍遵循互斥。无需重新绑定或创建任务；DONE/租约/锁/权限要求不变。

## 控制端新任务最小检查

- 一个任务只有一个可验收目标；内部步骤写检查点，不机械拆成“每步一任务”（P-047）。
- 任务卡点名 CORE、对应 worker、必要的 P/TK/G 编号和项目模块段落，不再要求全量通读根文档。
- CODE/运行时 C# 任务先给代码改动清单；工具层三问从 [toolkit/INDEX.md](toolkit/INDEX.md) 定位。
- 人工项只更新 `inputs/USER_WORK_STATUS.md`，不占 AI 编号；DATA 配表车道按 G67 路由。
- 首次启用 DATA 先调用 `RegisterDataLane`；可见线程接通时先 `DataLaneStatus`，确认 DATA 为 IDLE、无 RUNNING/activeTaskId/lease/预约，再以真实授权和应用可达证据调用 `BindDataPipeline`。对未领取预留任务可 `ReclassifyTask -Pipeline DATA`；`USER-U1-Rn` 只有显式 `DONE` 后才能由 `ConsumeDataRound` 幂等生成 `DATA-Rn`。绑定后只向返回的精确 `THREAD/threadId` 投递，路由异常时停止，不回退子代理。
- 报告使用 [templates/TASK_COMPLETION_REPORT.md](templates/TASK_COMPLETION_REPORT.md)，只返回结论、证据路径、计数及最多 20 条异常。
