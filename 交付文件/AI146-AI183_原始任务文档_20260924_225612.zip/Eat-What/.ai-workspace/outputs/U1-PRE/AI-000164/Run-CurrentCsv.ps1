param([string]$Case = 'baseline', [string]$OverlayPath)
$ErrorActionPreference = 'Stop'
$repo = 'D:/GameProject/Eat-What'
$outRoot = Join-Path $repo '.ai-workspace/outputs/U1-PRE/AI-000164'
. (Join-Path $repo 'DevTools/Workflow/UsageMetrics.ps1')
$checkpoint = & (Join-Path $repo '.ai-workspace/queue.ps1') -Action SupervisionCheckpoint -Pipeline DATA -TaskId AI-000164 | ConvertFrom-Json
if ($checkpoint.action -ne 'CONTINUE') { throw ('Checkpoint refused: ' + $checkpoint.action) }
$argsForRunner = @{
 CurrentCsvValidation=$true; ValidationSource="AI-000164 authorized isolated $Case; never publish"
 TaskId='AI-000164'; UnityPath='C:/Program Files/Unity/Hub/Editor/6000.3.24f1/Editor/Unity.exe'
}
if ($OverlayPath) {
 $argsForRunner.ValidationCsvOverlayPath=$OverlayPath
 $argsForRunner.ValidationCsvRelativePath='Localization/Localization.csv'
}
$runnerLog = Join-Path $outRoot ($Case + '-runner.log')
$started = [DateTimeOffset]::Now
$exitCode = 0
try {
 & (Join-Path $repo 'DevTools/DataTables/Run-DataPipeline.ps1') @argsForRunner *>&1 | Tee-Object -FilePath $runnerLog
}
catch {
 $exitCode=1
 $_ | Out-String | Add-Content -LiteralPath $runnerLog -Encoding utf8
 Write-Output $_.Exception.Message
}
finally {
 $receipt = [ordered]@{case=$Case;taskId='AI-000164';startedAt=$started.ToString('o');finishedAt=[DateTimeOffset]::Now.ToString('o');runnerExitCode=$exitCode;log=$runnerLog;publishRequested=$false}
 $receipt | ConvertTo-Json | Set-Content -LiteralPath (Join-Path $outRoot ($Case + '-runner-receipt.json')) -Encoding utf8
 $bytes = if(Test-Path -LiteralPath $runnerLog){(Get-Item -LiteralPath $runnerLog).Length}else{0}
 Write-TaskUsageRecord -TaskId AI-000164 -Lane DATA -Phase execute -Event ('CURRENT_CSV_' + $Case.ToUpperInvariant()) -ToolCallCount 1 -ToolResultBytes $bytes -Source 'Run-CurrentCsv.ps1 actual Run-DataPipeline invocation and saved console stream' -Coverage 'One actual pipeline invocation; ToolResultBytes is saved UTF8 console file length, not provider wire bytes or Unity log volume. Tokens/model unavailable.' -Metadata @{runnerExitCode=$exitCode;publishRequested=$false;log=$runnerLog} | Out-Null
}
exit $exitCode
