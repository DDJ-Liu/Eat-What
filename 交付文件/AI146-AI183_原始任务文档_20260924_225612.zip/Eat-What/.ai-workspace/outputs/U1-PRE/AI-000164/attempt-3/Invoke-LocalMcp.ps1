$ErrorActionPreference = 'Stop'

function Invoke-AI164McpRequest {
    param([Parameter(Mandatory)][string]$Method, $Parameters, [string]$SessionId, [string]$EvidencePath)
    $headers = @{ Accept = 'application/json, text/event-stream' }
    if ($SessionId) { $headers['Mcp-Session-Id'] = $SessionId }
    $body = [ordered]@{ jsonrpc='2.0'; id=[Guid]::NewGuid().ToString('N'); method=$Method }
    if ($null -ne $Parameters) { $body.params=$Parameters }
    $response = Invoke-WebRequest -Uri 'http://127.0.0.1:8080/mcp' -Method Post -ContentType 'application/json' -Headers $headers -Body ($body | ConvertTo-Json -Depth 30 -Compress) -TimeoutSec 45
    $raw = [string]$response.Content
    $parsed = $null
    if ($raw.TrimStart().StartsWith('{')) { $parsed = $raw | ConvertFrom-Json -Depth 60 }
    else {
        foreach ($line in ($raw -split "`n")) {
            if ($line.StartsWith('data: ')) { $parsed=$line.Substring(6) | ConvertFrom-Json -Depth 60 }
        }
    }
    if ($EvidencePath) { [ordered]@{observedAt=(Get-Date).ToString('o');method=$Method;response=$parsed;raw=$raw} | ConvertTo-Json -Depth 70 | Set-Content -LiteralPath $EvidencePath -Encoding utf8 }
    if ($parsed.error) { throw ($parsed.error | ConvertTo-Json -Compress) }
    $returnedSession = @($response.Headers['Mcp-Session-Id'])[0]
    [pscustomobject]@{Result=$parsed.result;SessionId=if ($returnedSession) {$returnedSession} else {$SessionId}}
}

function New-AI164McpSession {
    param([string]$EvidencePath)
    Invoke-AI164McpRequest -Method 'initialize' -Parameters @{protocolVersion='2024-11-05';capabilities=@{};clientInfo=@{name='AI164-recovery';version='1.0'}} -EvidencePath $EvidencePath
}
