$ErrorActionPreference = 'Stop'
$repositoryRoot = 'D:/GameProject/Eat-What'
Set-Location -LiteralPath $repositoryRoot
$evidenceRoot = $PSScriptRoot
. (Join-Path $repositoryRoot 'DevTools/DataTables/DataPipeline.Common.ps1')
. (Join-Path $evidenceRoot 'Invoke-LocalMcp.ps1')
$lock = Enter-DataPublicationLock -LockPath (Join-Path $repositoryRoot '.ai-workspace/runtime/data-publication.lock') -TimeoutSeconds 0
try {
    $snapshot = Get-DataPipelineInputSnapshot -RepositoryRoot $repositoryRoot
    $snapshot | ConvertTo-Json -Depth 15 | Set-Content -LiteralPath (Join-Path $evidenceRoot 'production-before-editor-start.json') -Encoding utf8
    if (@(Get-Process -Name Unity -ErrorAction SilentlyContinue).Count -gt 0) { throw 'Unity appeared after preflight; stop rather than open an unverified second Editor.' }
    $serverExe = Join-Path $repositoryRoot '.ai-workspace/tooling/mcp-server-venv/Scripts/mcp-for-unity.exe'
    $server = Start-Process -FilePath $serverExe -ArgumentList @('--transport','http','--http-url','http://127.0.0.1:8080') -WorkingDirectory $repositoryRoot -WindowStyle Hidden -PassThru -RedirectStandardOutput (Join-Path $evidenceRoot 'mcp-server.stdout.log') -RedirectStandardError (Join-Path $evidenceRoot 'mcp-server.stderr.log')
    [ordered]@{at=(Get-Date).ToString('o');pid=$server.Id;startTime=$server.StartTime.ToString('o');exe=$serverExe;action='START_FIXED_MCP_SERVER';configurationChanged=$false} | ConvertTo-Json | Set-Content -LiteralPath (Join-Path $evidenceRoot 'mcp-server-start.json') -Encoding utf8
    $unityExe = 'C:/Program Files/Unity/Hub/Editor/6000.3.24f1/Editor/Unity.exe'
    $editor = Start-Process -FilePath $unityExe -ArgumentList @('-projectPath',$repositoryRoot,'-logFile', (Join-Path $evidenceRoot 'main-editor-start.log')) -WorkingDirectory $repositoryRoot -WindowStyle Hidden -PassThru
    [ordered]@{at=(Get-Date).ToString('o');pid=$editor.Id;startTime=$editor.StartTime.ToString('o');exe=$unityExe;projectPath=$repositoryRoot;action='START_APPROVED_MAIN_EDITOR';configurationChanged=$false} | ConvertTo-Json | Set-Content -LiteralPath (Join-Path $evidenceRoot 'main-editor-start.json') -Encoding utf8
    $lastError = $null
    for ($index=0; $index -lt 30; $index++) {
        Start-Sleep -Seconds 2
        try {
            $session = New-AI164McpSession
            $discovery = Invoke-AI164McpRequest -Method 'resources/read' -Parameters @{uri='mcpforunity://instances'} -SessionId $session.SessionId -EvidencePath (Join-Path $evidenceRoot 'mcp-instance-discovery.json')
            if (($discovery.Result | ConvertTo-Json -Depth 30 -Compress) -match 'Eat-What') { [ordered]@{action='EDITOR_DISCOVERED';serverPid=$server.Id;editorPid=$editor.Id;iterations=$index+1} | ConvertTo-Json; return }
        } catch { $lastError=$_.Exception.Message }
        if ($server.HasExited -or $editor.HasExited) { break }
    }
    [ordered]@{action='STARTED_NOT_YET_DISCOVERED';serverPid=$server.Id;serverExited=$server.HasExited;serverExitCode=if($server.HasExited){$server.ExitCode}else{$null};editorPid=$editor.Id;editorExited=$editor.HasExited;editorExitCode=if($editor.HasExited){$editor.ExitCode}else{$null};lastError=$lastError} | ConvertTo-Json
} finally { $lock.Dispose() }
