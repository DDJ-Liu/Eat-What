param([ValidateSet('baseline','overlay')][string]$Case='baseline')
$ErrorActionPreference='Stop'
$repositoryRoot='D:/GameProject/Eat-What'
Set-Location -LiteralPath $repositoryRoot
$pwsh='C:/Users/DDJ/.cache/codex-runtimes/codex-primary-runtime/dependencies/native/powershell/pwsh.exe'
$unity='C:/Program Files/Unity/Hub/Editor/6000.3.24f1/Editor/Unity.exe'
$taskId='AI-000164'
$dispatchToken='8443c965fb10405a96fd0f616f47d2b5'
# This output-side wrapper is restricted to the two authorized isolation-only cases.
# The existing reviewed pipeline enforces CurrentCsvValidation => Publish prohibited,
# acquires the physical publication lock through exit/nonce validation, and checks all five input roots.
# It never opens the live project in batch mode, accepts terms, or changes licensing/client settings.
$checkpoint=& (Join-Path $repositoryRoot '.ai-workspace/queue.ps1') -Action SupervisionCheckpoint -Pipeline DATA -TaskId $taskId -DispatchToken $dispatchToken
$checkpoint | Set-Content -LiteralPath (Join-Path $PSScriptRoot ($Case+'-checkpoint.json')) -Encoding utf8
$parsed=($checkpoint -join [Environment]::NewLine)|ConvertFrom-Json
if($parsed.action -ne 'CONTINUE'){throw ('Supervision did not authorize continuation: '+$parsed.action)}
$arguments=@('-NoProfile','-File',(Join-Path $repositoryRoot 'DevTools/DataTables/Run-DataPipeline.ps1'),'-CurrentCsvValidation','-ValidationSource',('AI-000164 approved host-context recovery 20260923 '+$Case),'-TaskId',$taskId,'-UnityPath',$unity,'-BatchTimeoutSeconds','1800')
if($Case -eq 'overlay'){
    $overlay=Join-Path $repositoryRoot '.ai-workspace/runtime/data-validation-inputs/AI-000164/host-context-recovery-20260923/Localization.csv'
    if(-not (Test-Path -LiteralPath $overlay -PathType Leaf)){throw 'The reviewed isolated CSV overlay is missing.'}
    $arguments+=@('-ValidationCsvOverlayPath',$overlay,'-ValidationCsvRelativePath','Localization/Localization.csv')
}
if($arguments -contains '-Publish'){throw 'Publishing is explicitly forbidden for this task.'}
$startedAt=(Get-Date).ToString('o')
& $pwsh @arguments *> (Join-Path $PSScriptRoot ($Case+'-runner.log'))
$runnerExitCode=$LASTEXITCODE
$receipt=[ordered]@{case=$Case;startedAt=$startedAt;finishedAt=(Get-Date).ToString('o');runnerExitCode=$runnerExitCode;configuredBatchTimeoutSeconds=1800;hostContext='normal host requested through exec_command require_escalated';outputPath=(Join-Path $PSScriptRoot ($Case+'-runner.log'));published=$false;runnerCodeIsNotUnityCode=$true}
$receipt | ConvertTo-Json | Set-Content -LiteralPath (Join-Path $PSScriptRoot ($Case+'-runner-receipt.json')) -Encoding utf8
$receipt | ConvertTo-Json
exit $runnerExitCode
