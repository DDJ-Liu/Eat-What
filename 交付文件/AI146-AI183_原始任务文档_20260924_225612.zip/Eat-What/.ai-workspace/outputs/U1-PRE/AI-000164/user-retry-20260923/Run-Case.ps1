param([ValidateSet('baseline','overlay')][string]$Case='baseline')
$ErrorActionPreference='Stop'
Set-Location -LiteralPath 'D:/GameProject/Eat-What'
$pwsh=Join-Path $PSHOME 'pwsh.exe'
$runner='D:/GameProject/Eat-What/DevTools/DataTables/Run-DataPipeline.ps1'
$argsList=@('-NoProfile','-File',$runner,'-CurrentCsvValidation','-ValidationSource',('AI-000164 explicit user retry 20260923 '+$Case),'-TaskId','AI-000164','-UnityPath','C:/Program Files/Unity/Hub/Editor/6000.3.24f1/Editor/Unity.exe')
if($Case -eq 'overlay'){$argsList+=@('-ValidationCsvOverlayPath','D:/GameProject/Eat-What/.ai-workspace/runtime/data-validation-inputs/AI-000164/user-retry-20260923/Localization.csv','-ValidationCsvRelativePath','Localization/Localization.csv')}
$startedAt=(Get-Date).ToString('o')
& $pwsh @argsList *> (Join-Path $PSScriptRoot ($Case+'-runner.log'))
$runnerExitCode=$LASTEXITCODE
$receipt=[ordered]@{case=$Case;startedAt=$startedAt;finishedAt=(Get-Date).ToString('o');runnerExitCode=$runnerExitCode;outputPath=(Join-Path $PSScriptRoot ($Case+'-runner.log'));published=$false;runnerCodeIsNotUnityCode=$true}
$receipt | ConvertTo-Json | Set-Content -LiteralPath (Join-Path $PSScriptRoot ($Case+'-runner-receipt.json')) -Encoding utf8
$receipt | ConvertTo-Json
exit $runnerExitCode
