# AI-000158 · PRE-4 DIAG-T3 托盘与封面气泡诊断

## 1. 做了什么

在 Unity 6000.3.24f1 的现有 `ShortCycle_P0P1` 场景上完成只读 Editor 审计与一次临时 Play。核对了托盘的 Director/Controller/Presentation/Transition/Preset 接线、实际 H 输入订阅、Phase1 三态根 Transform，以及两个 Cover 气泡的可见性、Sprite、Set 登记、TMP/LocalizedText 与 T9 数据。没有保存场景、资源或源码。

## 2. 产物

- 完整领取回执：`D:/GameProject/Eat-What/.ai-workspace/outputs/U1-PRE/AI-000158/claim-receipt.json`
- 结构化审计：`D:/GameProject/Eat-What/.ai-workspace/outputs/U1-PRE/AI-000158/editor-audit.json`
- 本报告：`D:/GameProject/Eat-What/.ai-workspace/outputs/U1-PRE/AI-000158/AI-000158_PRE-4_DIAG-T3_托盘与封面气泡诊断.md`

## 3. 实际验证

- 实例与工程：`Eat-What@d5759c75ae7cb5de`；`Application.dataPath=D:/GameProject/Eat-What/Assets`；Unity `6000.3.24f1`。
- Play 稳定性：两次样本间隔 ≥2 秒，`frameCount 3583→6689`、`unscaledTime 25.728→44.712`、`timeScale=1`、未暂停、未编译。
- 托盘接线：`PresentationDirector → ShortCycleTrayPresentation → TransitionController → Tray_Group Transform` 完整；三 Preset 为 Collapsed `(Y 0, Scale 1)`、Highlight `(Y 0.08, Scale 1.025)`、Detail `(Y 0.18, Scale 1.05)`，曲线 2-key、0.3 秒、unscaled。
- 三态 Play：在 Phase1 激活托盘后，三个状态分别精确落到上述 Transform；恢复 Collapsed 后位置/缩放回到基线。
- H 路径：源码仍有 `HandleKeyPressed(Key.H)`，但 Play 时 `Probe_ManualDriver` 不在 active hierarchy，`InputManager.OnKeyPressed` 仅有 Escape `KeyboardListener`；实际 H 广播 `consumed=false`，状态不变。
- 生命周期实证：在 Phase0 托盘 inactive 时请求 Highlight，逻辑状态变为 Highlight，但 Transform 不动，并出现 `TransitionController.cs:66 Coroutine couldn't be started ... Tray_Group is inactive`；随后进入 Phase1 不会自动重放该状态。该日志由本次诊断确定性触发，退出 Play 后场景未脏、哈希不变。
- 气泡：A/B 都 `activeSelf=true`、SpriteRenderer enabled、分别引用 `ui_caipu_qipaoA/B.png`，且属于 Cover View Set；两棵子树的 TMP 与 LocalizedText 数量均为 0，生成 T9 100 行中缺 `ui_p0_cover_bubble_a.text` / `ui_p0_cover_bubble_b.text`。
- 收尾：稳定 Edit Mode、未暂停、未编译、`scene.isDirty=false`。场景前后 SHA-256 均为 `AC46926BE35F27C05FEB6B5B4B0E2791E3F8B08BC55AD0D36B7AF0F19700F487`；字体与 meta SHA 也未变化。focused diff 仍显示场景已有未提交改动，但文件长度、mtime 与本轮基线一致，说明本轮没有落盘改变。

## 4. 待人工项

无本任务完成所需的人工验证。后续修复卡若调整托盘幅度，仍需设计/视觉确认主观可辨性；本轮没有代签该主观结论。

## 5. 文档影响

无项目入口文档更新。本轮只产生诊断证据，不改变代码入口、场景绑定、架构、完成度或验证契约；不伪改两份项目文档的完整核验日期。

## 6. 工具登记影响

无工具登记变更。复用 `TK-MOT-07` 的现有 Transition/Preset 能力与既有 G26 ManualDriver，仅做实际消费核对。

## 判定与修复建议

### 托盘：缺陷

组件并非未挂载，三 Preset 也能在激活的 Phase1 正常到位。实际存在两层问题：H 调试驱动器因父层 inactive 而没有订阅输入；更关键的是 inactive 托盘收到状态请求时逻辑状态先行、动画协程失败，后续激活不会重放，造成状态与画面不同步。0.08/0.18 世界单位的幅度又会降低肉眼辨识度。

建议后续卡先修复生命周期：为 inactive 目标缓存待应用 Preset，并在激活/Phase1 到达时按 `CurrentView` 重放；避免在 inactive GameObject 上启动协程。H 仅作为调试入口时，应放到 Play 期确实 active 的专用探针或明确激活策略，不把 inactive Debug 根误当可用输入。生命周期闭环后，再由设计端决定是否放大 0.08/0.18 与 2.5%/5% 的表现幅度。

### 封面气泡：未开发

气泡背景图与 Cover 集合配置已完成，但文案呈现层和数据层均不存在；这不是 Renderer/Set 开关错误。建议后续卡在每个气泡下增加世界空间 `TextMeshPro + LocalizedText`，新增两条 T9 key 与中文文案，保持 SpriteRenderer/世界空间范式，不引入 UGUI；随后在 Cover 机位验证字形可读、排序与遮挡。

## 影响块

- `M7-B1-R1`：托盘三态根因已定性为生命周期缺陷，附带 H 调试订阅缺失与幅度偏小证据。
- `M2-B1-R2`：封面气泡已定性为文案层未开发；Sprite/Set 已存在，缺 TMP/LocalizedText/T9 两键。

