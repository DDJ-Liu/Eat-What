# AI-000166 · PRE-2b-PROCESS-R1 修复报告

日期：2026-09-23。结论：**CODE 范围完成**。修复了 AI164 发现的 Windows GUI Unity 子进程未等待、默认0误报和锁提前释放问题；本任务未启动 Unity，真实 DATA 首跑仍由恢复后的 AI164 执行。

## 1. 完成内容

- `DataPipeline.Common.ps1` 改用本次创建的 `System.Diagnostics.Process` 句柄隐藏启动、等待真实退出并读取该句柄 `ExitCode`；不再预设或读取 Unity 的 `$LASTEXITCODE`。
- 进程超时/等待异常只通过所持句柄终止本次进程树，异常记录 PID、StartTime、exe、projectPath 与日志路径；不枚举或操作用户 Editor、License Client 或其它进程。
- `Run-DataPipeline.ps1` 将真实可空 `batchProcessExitCode` 与 `runnerExitCode` 分开；只有真实退出0且当前run完成凭据通过后，才登记 `ImportAllBatch` 与字体Builder为已执行。
- `ImportAllBatch` 在 `ImportAll` 和 `ShortCycleFontAtlasBuilder.BuildAll` 都成功后，才以 `FileMode.CreateNew` 在隔离工程内写 runId、随机nonce、新鲜时间、导表计数、项目CSV parser字形清单和字体manifest结果。
- 字形清单复用 `DataTableCsvParser` 的 `zh_cn` 语义，当前合同为238；不再用 PowerShell `Import-Csv` 对带引号多行字段得到的239作为Builder事实。
- 输入快照对齐实际隔离复制范围：`Assets`、`Packages`、`LocalPackages`、`ProjectSettings`、`DataTables` 五根；不复制活动 Library/Temp/Logs/obj/.git。
- `CurrentCsvValidation` 的禁止Publish/不写USER-U1 DONE边界保持不变。

## 2. 变更产物

- `Assets/Editor/DataTables/DataTableImportService.cs`
- `DevTools/DataTables/DataPipeline.Common.ps1`
- `DevTools/DataTables/Run-DataPipeline.ps1`
- `DevTools/DataTables/Test-BatchImport.ps1`
- `DevTools/DataTables/StaticCompile/UnityStubs.cs`
- `DevTools/DataTables/DATA_PIPELINE.md`
- `CODEBASE_MAP.md`
- `项目整体阅读理解与推进基线_2026-08-14.md`
- `.ai-workspace/toolkit/WF.md`
- `.ai-workspace/toolkit/DAT.md`

未修改 `.unity`、`.prefab`、`.asset`、`.meta`，未提交或推送。

## 3. 验证证据

最终运行：

```powershell
pwsh -NoProfile -File DevTools/Verify-All.ps1 -TaskId AI-000166 -Profile DataTables -Mode Final
```

结果 `VERIFY_ALL_PASSED`，6/6 runner：

| Runner | 结果 |
| --- | --- |
| `Test-Validate-DataTables.ps1` | PASS，合法源/quoted UTF-8/非法夹具/v2.4报告 |
| `Test-CK01BSchemas.ps1` | PASS，14表及27个隔离负例 |
| `Test-CK01BImportContracts.ps1` | PASS，21个源码单元静态编译与导入合同 |
| `Test-Authoring.ps1` | PASS，14 sheet、往返稳定、共享Validator、生产CSV不变 |
| `Test-BatchImport.ps1` | PASS，65项 |
| `.ai-workspace/tests/Test-DataLane.ps1` | PASS，36项，生产队列/worker/mode/INSTRUCTIONS哈希不变 |

65项批处理回归使用真实编译为 Windows GUI 子系统的延迟可执行夹具，证明：延迟非零23保真且调用方未提前返回；超时保持真实进程码为空并在返回前清理本次PID进程树；退出0+新鲜凭据通过；退出0但缺凭据失败；旧时间凭据失败；子进程运行期间发布锁不可再次独占，退出后释放。夹具及故障注入仅位于系统临时目录。

`git diff --check` 通过。`ShortCycle_P0P1.unity` SHA-256 仍为 `97CD7D39481029D4DCDA566EC800398524B88D2651AEED6040F866E901C453B2`，与 AI165 接力基线一致。批处理回归再次确认生产 `DataTables`、`Assets/Generated/DataTables`、`Assets/Font/Heavy` 摘要不变，`unityStarted=false`。

统一验证历史：`.ai-workspace/runtime/verify-all/verify-all-AI-000166.jsonl`。

## 4. 失败语义与恢复条件

- 未启动、启动失败、等待异常或超时：`batchProcessExitCode=null`，Runner失败；超时仅清理本次句柄所属进程树。
- 实际非零：保留该进程真实退出码，Runner失败。
- 实际0但凭据缺失、旧、runId/nonce不符，或字体/字形证据不一致：保留进程码0、Runner码1，不登记两个Unity API已执行。
- 只有真实退出0和本次凭据全部通过，才进入后续diff/catalog/可选发布；物理锁在此之前不释放。

控制端可在本任务成功后按既定稳定 ProblemKey 恢复 AI164。AI164须重新记录当时生产输入/AI165场景基线，并真实执行 baseline 与隔离overlay两用例；许可连接拒绝仍按真实运行证据处理，不能由本报告代签。

## 5. 人工与范围边界

本任务不要求新视觉验收，也不触碰待批字体材质迁移。没有执行真实Unity、字体资产重建、生成物发布、场景保存或Play/Build，因此不声称这些项目已通过。USER-U1 DONE门禁及显式发布授权保持原状。

## 6. 文档、工具与用量

原接口说明、项目导航、项目基线以及 TK-WF-02/TK-DAT-01 已同步更新；没有创建平行运行器或新TK编号。Provider token/model用量在当前工具面不可得，保持 `null`，不估算；可观察的统一验证记录见上述 JSONL。
