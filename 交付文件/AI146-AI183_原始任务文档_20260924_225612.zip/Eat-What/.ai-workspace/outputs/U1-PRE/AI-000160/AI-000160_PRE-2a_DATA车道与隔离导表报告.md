# AI-000160 / PRE-2a 完成报告

日期：2026-09-23  
边界：仅 Workflow / DevTools / 文档；未启动 Unity，未修改 `.cs/.unity/.prefab/.asset/.meta`，未注册现网 DATA，未重分类 AI-000164。

## 1. 做了什么

- 在现有 `queue.ps1 + supervised.ps1` 上增加 DATA 车道受控注册、已注册门禁、正式重分类兼容、待验索引、监管派发与完整生命周期。DATA 明确返回 `executorKind=CONTROL_SUBAGENT`、`threadId=null`，由控制台内部子代理执行，不伪装成用户线程。
- 建立 USER-U1 轮次契约：authoring 导出只产生 `EXPORTED`；`Set-U1RoundStatus.ps1` 在 CSV 哈希未漂移时显式写 `DONE + userDecision`；控制台 `ConsumeDataRound` 再次核验并按 `dataRoundId` 幂等生成一个 `DATA-Rn` 任务。
- 建立隔离导表框架：Quick 校验、最小工程复制（含相对 `LocalPackages`，排除缓存）、共享全程锁、精确未来入口 `EatWhat.DataTables.DataTableImportService.ImportAllBatch`、非零退出传播、catalog 存在性、生成物 diff/catalog、字形清单、报告与可回滚发布。
- 建立 CSV/生成物同一未来提交边界与字体独立保护规则；所有工具均不自动提交。

## 2. 产物路径

- 调度：`.ai-workspace/queue.ps1`、`.ai-workspace/supervised.ps1`、`.ai-workspace/workers/DATA.md`
- U1 轮次：`DevTools/DataTables/DataRound.Common.ps1`、`Set-U1RoundStatus.ps1`、`Authoring/Export-AuthoringToCsv.ps1`
- 隔离管线：`DevTools/DataTables/DataPipeline.Common.ps1`、`Run-DataPipeline.ps1`、`DATA_PIPELINE.md`
- 回归：`.ai-workspace/tests/Test-DataLane.ps1`、`DevTools/DataTables/Test-Authoring.ps1`、`DevTools/Verify-All.ps1`
- 协议/索引：根兼容页、`protocol/*_FULL.md`、`toolkit/WF.md`、`toolkit/INDEX.md`、`TOOLKIT_REGISTRY.md`
- 项目入口：`CODEBASE_MAP.md`、`项目整体阅读理解与推进基线_2026-08-14.md`

## 3. 控制 API 与事件 schema

```powershell
# AI-000160 Complete 后由控制台执行；本任务没有执行这两条
& .ai-workspace/queue.ps1 -Action RegisterDataLane
& .ai-workspace/queue.ps1 -Action ReclassifyTask -TaskId AI-000164 -Pipeline DATA

# 后续 USER-U1 轮次
& DevTools/DataTables/Authoring/Export-AuthoringToCsv.ps1 -RoundId USER-U1-R1
& DevTools/DataTables/Set-U1RoundStatus.ps1 -RoundId USER-U1-R1 -UserDecision '<明确决定>'
& .ai-workspace/queue.ps1 -Action ConsumeDataRound -RoundId USER-U1-R1
```

注册响应关键字段：`action / pipeline=DATA / executorKind=CONTROL_SUBAGENT / threadId=null / worker`。  
监管 dispatch 关键字段：`taskId / pipeline / executorKind / threadId / token / message`。  
轮次清单字段：`schemaVersion / roundId / userDependency / dataTaskModuleId / status / csvSummarySha256 / exportedAt / doneAt / userDecision / source`。  
生成任务附加字段：`dataRoundId / dataRoundManifestSha256 / userRoundDependency / supervisionPolicy.resourceKeys`。

## 4. 实际验证

- PowerShell 解析：任务涉及的 11 个 `.ps1`，0 错误。
- `Test-DataLane.ps1`：36 项通过；覆盖未注册拒绝、注册幂等、重分类、CONTROL_SUBAGENT 路由、默认资源、未 DONE 拒绝、轮次去重、源漂移、共享锁冲突、batch 非零退出、锁先于 batch、半发布回滚、成功交换与源哈希冲突。
- 该测试对生产 `queue-state.json / worker-state.json / mode-state.json / INSTRUCTIONS.md` 执行前后 SHA-256 比较，全部不变。
- `Test-WorkflowModes.ps1`：PASS；`Test-SupervisedMode.ps1`：135 项 PASS；`Test-QueueReviewAndModules.ps1`：PASS，`productionHashesUnchanged=true`。
- `Test-DocumentationIndex.ps1`：PASS；根文档缩减率 52.01%，活动完整协议允许依法演进，归档旧源仍按固定哈希保护。
- `Test-Validate-DataTables.ps1`、`Test-CK01BSchemas.ps1`、`Test-CK01BImportContracts.ps1`：全部 PASS（14 schema / 14 registrations / compiledSourceCount=21）。
- `Test-Authoring.ps1`：PASS；14 sheets、重复导出稳定、权威 CSV 未变，并验证导出事件仅为 `EXPORTED`、没有虚构用户决定或调用队列。
- 收口静态审计：24 个任务归属文件，禁止扩展名计数 0；`git diff --check` 无错误。
- 现场门禁：`DATA` worker 仍未注册；AI-000164 仍为 `CODE / QUEUED`，满足“交付 API 但不在本任务写在线状态”。

## 5. 待人工/后置项

- 控制台收到 Complete 回报后，按上面的正式 API 注册 DATA 并把 AI-000164 重分类；这是刻意保留的控制端动作。
- 第一次真实 Unity 6 batch、未来 C# 入口实现、生成资产发布及 Unity 内引用/Console 验证由 AI-000164（PRE-2b）承担。本任务没有用当前 CSV 假造 USER-U1 完成，也没有做 Unity 结果声明。

## 6. 文档影响

- 已更新项目数据入口、DATA 路由、U1 轮次、隔离发布和后置验证边界；没有改完整结构复核日期。
- `Test-DocumentationIndex.ps1` 修正为：不可变 archive 固定哈希；活动 `protocol/*_FULL.md` 检查存在且非空，避免活文档每次合法维护都被误判为归档损坏。

## 7. 工具登记影响

- 新增并登记 `TK-WF-02`（沿用）：DATA 车道、U1 轮次与隔离/事务发布管线。
- 复用 `TK-DAT-01` 导表/Catalog 契约、`TK-DAT-07` authoring/Quick 校验；未建立第二队列、平行导入器或固定 DATA 线程。
