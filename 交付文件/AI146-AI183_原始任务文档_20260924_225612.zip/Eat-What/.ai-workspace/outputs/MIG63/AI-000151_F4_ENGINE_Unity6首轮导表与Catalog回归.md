# AI-000151 · F4-ENGINE Unity 6 首轮导表与 Catalog 回归

日期：2026-09-22  
任务：`AI-000151` / `B-T12`  
环境：`D:/GameProject/Eat-What`、`codex/unity6-followup`、Unity `6000.3.24f1`  
定位：USER-U1 前的 A1 基线首跑；不要求 USER-U1 已完成。

## 1. 结论

- F3 共享校验入口通过：14 份 schema、0 error、13 条既有 warning。
- Unity `Tools/Data Tables/Import All` 成功；旧 T8 生成键已精确移除，新键 `fridge_scroll_threshold=1.0`、`fridge_scroll_cooldown=0.2` 已写入 catalog。
- Catalog 回归通过：14 tables、3 菜谱、三条步骤链、三组 whitelist、demo 容量 30、`prd_unknown` product resolver 均有效。
- 第三轮 Import All 为 `created=0 / updated=0 / unchanged=121`；第二、三轮生成目录聚合 SHA 相同，证明最终结果幂等。
- Play 回归通过：现有自动探针 PASS；`ShortCycleManualVerificationDriver` 13 次真实路由全部 `succeeded=True`，双向镜头移动均在输入解锁后继续。
- 最终回到稳定 Edit Mode：P0/P1 scene clean，Console Error/Exception/Assert=0；场景及受保护字体的 asset/meta SHA 均与写前一致。
- 结果保留为 `PENDING_USER`：仍需用户一次性人工验收“13 步驱动器画面 + 真实滚轮手感 + 导表结果”，之后才决定 E2。

## 2. 做了什么与产物

1. 运行 `DevTools/DataTables/Validate-DataTables.ps1 -Quick`。
2. 写前把 `Assets/Generated/DataTables/**` 的 261 个文件完整备份到：
   - `DevTools/Generated/backup/AI-000151/DataTables/`
3. 通过 Unity 菜单执行 `Tools/Data Tables/Import All`。
4. 对旧键资产做全 `Assets` GUID 反向引用核对；除各自 `.meta` 自身外反向引用为 0 后，通过 Unity MCP 精确删除：
   - `Assets/Generated/DataTables/Cooking/CookingGameConfig/fridge_scroll_granularity.asset`
   - `Assets/Generated/DataTables/Cooking/CookingGameConfig/fridge_scroll_damping.asset`
5. 重复 Import All，验证最终字节和 importer 报告幂等。
6. 通过 Unity `CK01GeneratedDataCatalog` 公开面完成静态/catalog 回归，再进入 Play 完成自动探针和 13 步机器驱动。
7. Refresh/Compile、Console、scene/font 哈希、GUID、focused diff 与现场清理全部复核。

最终生成物 focused diff：

- 修改：`Assets/Generated/DataTables/CK01GeneratedDataCatalog.asset`
- 删除：旧 `fridge_scroll_granularity`、`fridge_scroll_damping` 的 asset/meta，共 4 个文件。
- 新增：`fridge_scroll_threshold`、`fridge_scroll_cooldown` 的 asset/meta，共 4 个文件。
- 没有其它 `Assets/Generated/DataTables/**` Git 差异；未修改场景、Prefab、ProjectSettings、字体或其它生产资产。

## 3. 导表、幂等与 GUID 证据

### 3.1 共享校验

`Validate-DataTables.ps1 -Quick`：

- `schemaCount=14`
- `errorCount=0`
- `warningCount=13`
- slot 引用、孤儿本地化、步骤链、白名单覆盖四类报告均成功输出。

13 条 warning 为既有数据审计项：两条多 carrier、两条菜谱可达性/来源审计、九条孤儿本地化 key；没有阻止导入的错误。

### 3.2 备份

- 写前生成目录：261 files / 126,356 bytes。
- 备份完成后逐文件 SHA-256 比较：261/261 相同。
- 写前聚合 SHA-256：`3DADED8E6B5C138EE880A9806B1A3B91FFFA6D10BC8338220370C9DF502075A0`。
- 回退方式：如需回退，仅在停止 Unity 并确认当前结果不再需要后，以备份目录覆盖本任务审定的生成目录；本轮未执行回退。

### 3.3 Import All

- 首轮菜单导入：`created=2 / updated=17 / unchanged=102`。
- 清理两个零反向引用旧键后，第二轮：`created=0 / updated=16 / unchanged=105`；16 个 Tag 行因 placeholder 解析重新标记 dirty，但落盘内容未形成 Git 差异。
- 第三轮：`created=0 / updated=0 / unchanged=121`，0 error。
- 第二、三轮后生成目录均为 261 files / 126,437 bytes，聚合 SHA-256 均为：
  - `34D351B0F96688BA2D9E8F77225571023436DD7D4B94054E164AB9C55087B6E3`

GUID 核验：

- 仍存在的写前 meta：137 个，GUID mismatch=0。
- 删除的旧 GUID：
  - granularity：`c30a2742bcbb3314ab9dd046e2314044`
  - damping：`ee85c30b99e0d5647a07b704ebfb2063`
- 新 GUID：
  - threshold：`ef85a3fb0e566af45954d022be8fc7f7`
  - cooldown：`e43b955f1eadab147ab2728c5709a4e8`
- Catalog GUID 保持 `9ca997eace167cf4c9672b6ac10ee4e2`。

`rg` 与 Catalog API 双重确认：旧 `fridge_scroll_granularity` / `fridge_scroll_damping` 在最终生成目录中无残留；Catalog 对两个旧 stable ID 均返回不存在。

### 3.4 Import warning

Importer 返回 47 条既有“精确 Sprite 未命中，使用 CK01 placeholder”的 warning，覆盖 Items、RecipeVariants、Tags、Tools；其中包括 `prd_unknown` 的 `ui_caipin_unknown_AIGC`。F-α 明确不把 `prd_unknown` 美术占位部署并入核心链，因此以 `WARNING` 记录但不阻断本次数据、catalog 或运行时验收。

## 4. Catalog 实际回归

Unity Editor API 读取 `Assets/Generated/DataTables/CK01GeneratedDataCatalog.asset`：

| 项目 | 结果 |
|---|---|
| Catalog table 数 | 14 |
| Recipes | 3/3 可解析 |
| `rcp_qingtang_noodle` | whitelist 3；step chain 2 |
| `rcp_tomato_egg` | whitelist 6；step chain 4 |
| `rcp_kaishui_cabbage` | whitelist 3；step chain 3 |
| demo 容量 | `30` |
| unknown resolver | `prd_unknown`，`item_kind=product` |
| T8 raw | threshold=`1.0`，cooldown=`0.2` |
| T8 resolved | threshold=`1`，cooldown=`0.2`，无 diagnostic |
| 旧 T8 stable ID | 两项均不存在 |

## 5. Play 与机器 13 步

### 5.1 稳定 Play 前置

两次采样均为 `isPlaying=true`、`isPaused=false`、`isCompiling=false`、`timeScale=1`，帧和游戏时间从 `frame=2 / unscaledTime=3.829` 推进到 `frame=286 / unscaledTime=5.376`。本次仅在 Play 运行时临时设置 `Application.runInBackground=true`，未改 PlayerSettings/ProjectSettings。

### 5.2 自动探针

运行场景已有 `DebugAndReferences/Probe_ShortCycleAutomated`，结果：

```text
CK01-C-PROBE PASS cover/catalog/select/browse; named start/return;
bidirectional camera pan; input lock; clue anchors; P1 retention;
layered ESC clear; generated recipe chain
```

探针完成时 `phase=None`、`view=Cover`、scene dirty=false。

### 5.3 ManualVerificationDriver 13 次路由

通过场景已有 `Probe_ManualDriver` 的公开 `Dispatch` 依次执行当前 FSM 合法顺序：

1. `open_cover`
2. `select_recipe`
3. `open_catalog`
4. `close_catalog`
5. `open_step_detail`
6. `close_step_detail`
7. `toggle_favorite`
8. `toggle_favorite`（恢复收藏原状态）
9. `open_clue_board`
10. `close_clue_board`
11. `start_cooking`
12. 等待 Phase1 pan 完成和输入解锁后 `return`
13. 等待 Phase0 pan 完成和输入解锁后 `escape`

13/13 均为 `succeeded=True`。关键时序：

- step 11：Phase0 → Phase1，动作后 input lock=true；
- step 12 前：Phase1 / Camera Phase1 / input lock=false，return 成功并再次加锁；
- step 13 前：Phase0 / RecipeBrowse / Camera Phase0 / input lock=false，escape 成功到 RecipeCatalog。

运行段只出现两条既有 Shared Set 合并 warning；Error/Exception/Assert=0。Debug 根和探针仅在 Play 临时激活，退出 Play 后没有保存。

## 6. 现场、哈希与 focused diff

最终 Unity 状态：

- `Application.dataPath=D:/GameProject/Eat-What/Assets`
- Unity `6000.3.24f1`
- active scene：`Assets/Scenes/Cooking/ShortCycle_P0P1.unity`
- Edit Mode；未暂停、未切换、未编译、未更新
- `scene.isDirty=false`
- 字体对象 `EditorUtility.IsDirty=false`
- Console Error/Exception/Assert：0

写前与写后 SHA-256 完全相同：

| 文件 | SHA-256 |
|---|---|
| `Assets/Font/Heavy/ShortCycle_Heavy_WithFallback.asset` | `1D379A7EB64DE1871194614F83BF61AC52E0D323677048FE237E3FBD3B399CC2` |
| 字体 `.meta` | `FD636B8448C6711DD53F53205655FDA86FAB6D2D597BF9B9F60C02BB6EFD89DA` |
| `Assets/Scenes/Cooking/ShortCycle_P0P1.unity` | `D082585690918C2E17683FBB8C107A7B8F2BB10D74091D7DD589297764FB11A1` |
| 场景 `.meta` | `F866CCF2493AAFB347EB92D498CD485F97EEFDB316FEE7E945EF423045D4C5E0` |

`git diff --check` 无错误；输出仅有工作树既有 LF/CRLF 提示。Focused Git 状态严格等于一份 catalog 修改、两组旧 T8 asset/meta 删除、两组新 T8 asset/meta 新增；未覆盖或清理无关 dirty 工作。

执行中有一次只读 `execute_code` 预检把 `using` 声明误放入工具方法体而编译失败；该片段未执行、无写入，随即改为全限定类型并成功。无残余风险，因此按 WORKFLOW 仅在本报告汇总。

## 7. 待人工验收

任务应以 `PENDING_USER` 完成。用户需在本轮 F-α 末尾一次性复核：

1. P0/P1 Play 中按现有 ManualVerificationDriver 走 13 步，观察实际画面、状态板和日志；
2. 用真实 Windows 鼠标复核方向、边界、焦点恢复及 threshold=1 / cooldown=0.2 的手感；Mac 设备使用前仍需 Mac 实机复测；
3. 审阅本轮导表结果、placeholder warning 与 catalog 数据是否符合内容预期。

机器证据已经通过；人工项不阻断任务 `SUCCEEDED`，但 E2 必须等待用户决定。

## 8. 文档影响

- 无项目级入口文档更新。AI-000148 已更新 T8 新键、入口与验证方式；本轮只生成审定资产并补机器证据，没有新增核心类、路径契约、场景接线或架构决策。
- 本报告是本轮唯一新增说明；没有仅为刷新日期修改 `CODEBASE_MAP.md` 或项目推进基线。

## 9. 工具登记影响

- 沿用 `TK-DAT-07` 的 `Validate-DataTables.ps1 -Quick` 作为 F3 共享前置。
- 沿用 `TK-DAT-01` 的唯一 `CK01GeneratedDataCatalog + DataTableImportService` 数据入口。
- 沿用受保护的 `TK-DBG-01 ShortCycleManualVerificationDriver` 与 `TK-DBG-02 ShortCycleAutomatedProbe`。
- 无新增公开工具、菜单或所有权变化，不修改 `.ai-workspace/TOOLKIT_REGISTRY.md`。

## 10. 追踪表影响

- `AI-000151 / F4-ENGINE / A1 基线首跑` 的机器部分闭合，USER-U1 后续每轮导出均可按同一路径重新触发 A1。
- F-α 自动技术链至此结束；队列应返回 `CHAIN_COMPLETE`。
- 不直接改写 MIG63 执行台账或用户验收状态；以队列 Complete 回执、本报告和后续用户一次性验收记录为准。
- E2 不在本任务触发范围内，须等待用户完成链尾人工验收后决定。
