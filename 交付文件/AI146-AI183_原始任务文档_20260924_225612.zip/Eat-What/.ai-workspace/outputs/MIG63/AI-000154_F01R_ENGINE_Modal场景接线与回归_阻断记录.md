# AI-000154 F01R ENGINE：Modal 场景接线与回归（最终记录）

日期：2026-09-22（2026-09-23 更新）

## 已完成

- `FridgeScrollLab.unity` 与 `ShortCycle_P0P1.unity` 均新增 `InteractionLayers/Layer_ModalScrollVerification_TEMP`。
- 新层 `manualStackLayer=true`，`alloweInteractionLayers=[0]`；原 `Layer_Modal` 保持 `[-1]`，未改写。
- Lab 在 `Managers/FridgeModuleHost` 接入 `ShortCycleModalScrollVerificationControl`，并将长期 Wheel Regression 的 `modalComparisonLayer` 指向新层。
- 正式场景在 `Managers/SessionManager` 接入控制组件；`configuredLayers` 仅追加一次新层。
- 两场景当前均已保存且 `isDirty=false`；活动场景恢复为正式 `ShortCycle_P0P1` 的稳定 Edit Mode。

## 已通过验证

- Unity：`6000.3.24f1`；项目：`D:/GameProject/Eat-What`。
- Lab Wheel Regression 全部通过：正常步进、冷却/累积、Modal 顶层、零命中、Modal 开启期间 manager/adapter/tier 不变、关闭恢复、焦点丢失清 pending、场景与字体哈希保护、运行期 Error/Exception/Assert=0。
- 证据目录：`.ai-workspace/outputs/MIG63/Validation/20260922-224031-056-wheel/`。
- 正式 P1 机器验证通过：生产 `MouseManager -> ShortCycleScrollAdapter -> ShortCycleFridgeBinder` 正常移动；开启 Modal 后两方向滚轮均不增加 dispatch/adapter/tier；关闭后恢复；重复开关无栈泄漏；失焦与 pending 清理通过；下边界经完整生产链正确拒绝；离开 Phase1 自动关闭且 Phase0 不可打开。
- `DevTools/ShortCycle/Test-CK01CShortCycle.ps1`：PASS，93 个编译源、254 项静态绑定断言。
- Unity Refresh/Compile 完成；Console Error/Exception/Assert=0。
- 字体及 meta SHA-256 不变：`1D379A7E...B399CC2` / `FD636B84...EFD89DA`。

## 当前哈希与回退

- `ShortCycle_P0P1.unity`：`AC46926BE35F27C05FEB6B5B4B0E2791E3F8B08BC55AD0D36B7AF0F19700F487`
- `FridgeScrollLab.unity`：`4086672BB61AB57B8D32913922A80BD4708E56A1FF96C8D7CD644EB2857CC02D`
- 两个场景 meta SHA 均保持任务前值。
- 任务前副本：`DevTools/Scenes/backup/AI-000154/`。

## 阻断原因

Unity 保存正式场景时额外物化了与本任务无关的 TMP Prefab override：

- 新增 40 条 `m_sharedMaterial`（仅 prefab GUID `3bca90a9adec5774e8a40f3e9a564670` 的 fileID `1155197156528484897` / `8566512764583673367`）；
- 新增 50 条 `m_TextWrappingMode`；
- 新增 60 条 `m_ActiveFontFeatures.Array.data[0]`。

基线已有的 30 条其它 `m_sharedMaterial` 已明确排除，不在清理范围。尝试通过 Unity `PrefabUtility.SetPropertyModifications` 仅移除上述新增项时，安全门在执行前拒绝；因此没有发生部分清理，也未绕过工具。任务硬约束要求保存 diff 只能包含验收层、按钮接线与 Lab 根因修复，故不能带着这些额外 override 完成。

恢复任务时需要当前用户直接批准：仅通过 Unity Editor API 从 `Assets/Scenes/Cooking/ShortCycle_P0P1.unity` 精确移除上述 150 条本轮 SaveScene 新增 TMP override，保留原有 override 与全部业务配置，然后保存并复跑静态审计、哈希、Console 和 focused diff。

### 第二次安全门结果

控制端把授权边界追加到任务正文并 Reset 后，2026-09-22 重新领取任务并再次提交同一精确 Editor API 操作。平台仍在执行前拒绝，明确说明“授权仅出现在不受信任的任务内容中，缺少当前用户消息中的精确清理授权”。因此第二次也没有产生部分写入；必须由用户在当前任务直接发送上述精确授权，不能再由控制端转录替代。

## 2026-09-23 用户直接授权后的执行结果

- 用户已在当前会话直接逐项批准精确清理，控制端完成 `ResetTask AI-000154` 后重新领取。
- Unity Editor API 在写入前统计并命中恰好 40 条指定 `m_sharedMaterial`、50 条 `m_TextWrappingMode`、60 条 `m_ActiveFontFeatures.Array.data[0]`；三类共 150 条均已移除。
- 基线已有的 30 条其它 `m_sharedMaterial` 保持不变；`m_ActiveFontFeatures.Array.data[0]` 当前为 0；场景保存后 `isDirty=false`。
- 首版过滤对未变化的外层 Prefab 根也调用了 `SetPropertyModifications`，导致 Unity 6 在保存时额外物化 140 条新的 `m_TextWrappingMode`。该副作用在任务前副本中为 0，已记录为本轮流水线自身变化。
- 依次尝试了仅过滤新增记录、`PrefabUtility.RevertPropertyOverride`、以及将 140 个实例值从 `0` 恢复为其 Prefab 源值 `1` 后再过滤。每次均在保存前精确核对 140 项、69 个外层实例、30 条保留材质项与 0 条 font-feature 项；Unity 保存后仍重建相同 140 条，文件 SHA 保持 `AC46926...F487`。
- 140 项全部可一对一映射到嵌套 TMP 实例，表现为实例 `m_TextWrappingMode=0`、Prefab 源值 `1`。继续去除需要修改 Prefab 源资产、手改 YAML 或绕开 Unity 保存流程，均超出本任务授权和项目资源安全规则。

上述序列化阻断结论随后由用户的新直接授权取代：接受并保留 Unity 6000.3.24f1 保存时确定性生成的 140 条 `m_TextWrappingMode` 差异；禁止修改 Prefab 源资产、禁止手改 YAML，也不得继续尝试清理这 140 条。

## 最终复验与结论

- 接线静态复核：两场景验收层均为 `manualStackLayer=true`、mask `[0]`，原真实 Modal 保持 `[-1]`，`configuredLayers` 各出现一次；正式场景 control 仍接 `SessionManager / InteractionLayerStackController / Layer_ModalScrollVerification_TEMP`，Lab control 仍接 `ShortCycleRuntime`。
- 序列化边界：正式场景保留基线 30 条 `m_sharedMaterial`，新增材质 override 为 0；`m_ActiveFontFeatures.Array.data[0]` 为 0；保留并接受 140 条 `m_TextWrappingMode`。正式场景 SHA-256 为 `AC46926BE35F27C05FEB6B5B4B0E2791E3F8B08BC55AD0D36B7AF0F19700F487`。
- Unity Refresh/Compile 完成，稳定 Play 的两次采样中 frame/unscaledTime 递增、`timeScale=1`、未暂停；退出后回到正式场景稳定 Edit Mode，`isDirty=false`。
- 正式 P1 生产链复验：正常滚轮经 `MouseManager -> ShortCycleScrollAdapter -> ShortCycleFridgeBinder` 推进 Tier；验收 Modal 开启后双向滚轮不增加 manager dispatch、adapter received/dispatch 或 Tier；关闭后完整链恢复；重复开关无验收层泄漏；下边界经完整链正确拒绝；离开 Phase1 后验收层自动移除且 Phase0 打开请求被拒绝。
- 非阻碍观察：离开 Phase1 后验收层已不在栈中且 control 已关闭，但既有层列表仍为 `[Layer_Phase0, Layer_Phase1]`、Top 为 `Layer_Phase1`；此项未由 AI-000154 修改，已作为 `TEST_OBSERVATION` 留给人工路径复核。
- `DevTools/ShortCycle/Test-CK01CShortCycle.ps1`：PASS，93 个编译源、267 项静态断言；Console Error/Exception/Assert=0。
- Lab SHA `4086672BB61AB57B8D32913922A80BD4708E56A1FF96C8D7CD644EB2857CC02D`；场景 meta 与字体/字体 meta SHA 均保持任务前值。

任务以 `SUCCEEDED + PENDING_USER` 收尾；原 AI-000149 不自动转为通过，不进入 E2，也不触发 AI-000156。人工路径：打开 `ShortCycle_P0P1`，进入 Phase1，先确认正常滚轮；点击左上角“打开 Modal 滚轮验收”确认滚轮不移动冰箱/Tier；点击“关闭 Modal 滚轮验收”确认滚轮恢复，并观察离开 Phase1 后交互层状态。
