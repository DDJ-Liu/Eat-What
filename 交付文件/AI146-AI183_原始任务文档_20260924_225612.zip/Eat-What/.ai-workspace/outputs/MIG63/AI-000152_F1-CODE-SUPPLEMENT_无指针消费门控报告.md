# AI-000152 / F1-CODE-SUPPLEMENT 无指针消费门控报告

- 日期：2026-09-22
- 工作区 / 分支：`D:/GameProject/Eat-What` / `codex/unity6-followup`
- 引擎基线：Unity `6000.3.24f1`
- 执行边界：仅源码、测试桩和编辑器外验证；未进入 Unity Editor/MCP，未修改 `.unity`、`.prefab`、`.asset`、`.meta`

## 1. 做了什么

- `Tools` 新增权威只读状态 `HasPointer`，其含义为“当前存在 `Mouse.current`，且本帧存在可用 `Camera.main`”。
- 主相机按 `Time.frameCount` 缓存：每帧最多解析一次 `Camera.main`，下一帧自动重新取值，因此相机替换、移除和恢复会使缓存失效。
- 缺少鼠标时直接报告不可用；缺少主相机时每个连续缺失阶段只输出一次 `[Tools]` warning，主相机恢复后允许下一个独立缺失阶段再提示一次，禁止逐帧刷屏。
- 保持最近一次有效世界坐标和兼容 `getMousePos()` 入口；`TryGetMousePos` 只有在真实设备及主相机同时存在时才采样并更新缓存。
- `MouseManager.Update` 每帧只取得一次真实指针坐标；不可用时在悬停命中、拖拽阈值与滚轮采样之前返回，不清空当前拖拽、悬停或滚动目标状态。
- 点击/空白取消、拖拽开始、投放、长按释放和废弃命中入口均改为消费 `TryGetMousePos` 的成功结果；`MouseManager` 不再把 `getMousePos()` 的兼容回退值传给 `Physics2D`。

## 2. 产物路径

- `Assets/Scripts/Tools/Tools.cs`
- `Assets/Scripts/MouseInteractive/MouseManager.cs`
- `DevTools/ShortCycle/UnityStubs.cs`
- `DevTools/ShortCycle/MousePositionFallbackTests.cs`
- `DevTools/ShortCycle/Test-MousePositionFallback.ps1`
- `DevTools/ShortCycle/Test-CK01CShortCycle.ps1`
- 本报告

## 3. 实际验证

1. `powershell -NoProfile -ExecutionPolicy Bypass -File DevTools/ShortCycle/Test-MousePositionFallback.ps1`
   - PASS；13 项运行断言。
   - 覆盖正常采样、无鼠标、无主相机、最近有效位置保持、主相机逐帧缓存失效、warning 单次节流、设备/相机恢复和恢复后的新缺失阶段。
   - 使用 Unity `6000.3.24f1` 自带 Roslyn 与真实 UnityEngine/InputSystem/UI/Assembly-CSharp 引用，对 `Tools.cs`、`MouseManager.cs` 两个生产源文件独立复编通过。
2. `powershell -NoProfile -ExecutionPolicy Bypass -File DevTools/ShortCycle/Test-CK01CShortCycle.ps1`
   - PASS；92 个源文件、224 项静态绑定契约。
   - 新增 8 项门控哨兵：状态公开面、相机缓存、warning 节流、Update/确认/拖拽/释放前置门控，以及 `MouseManager` 禁止消费兼容回退入口。
3. `git diff --check` 对本任务允许范围通过；未发现序列化资源改动。

## 4. 待人工项

- 本 CODE 补修没有新增独立人工闸门。真实 Unity 输入设备拔插、无主相机及恢复后的 Play Mode 观察仍归迁移批次现有 Unity/人工验证链统一结算；本任务未宣称编辑器内验证。

## 5. 文档影响

- 未改变模块目录、序列化字段、场景接线或 Resources 路径；两份项目级入口文档无需更新。
- AI-000146 报告仍保留首轮实现证据，本报告记录后续消费门控与 warning/cache 契约。

## 6. 工具登记影响

- 影响既有 `TK-INT-01`，不新建平行工具。本任务精确修改范围未授权直接改 `.ai-workspace/TOOLKIT_REGISTRY.md`；供控制台合并的完整替换行如下：

| ID | 名称 / 路径 | 能力 | 公开面 | 状态 | 消费方 | 来源 | 备注 |
|---|---|---|---|---|---|---|---|
| TK-INT-01 | `MouseManager` `MouseInteractive/` + `Tools` 指针契约 | 鼠标仲裁：按层 OverlapPointAll，分发按压/拖拽/投放/滚动/取消；无设备/无主相机时暂停所有指针消费 | `Tools.HasPointer` / `TryGetMousePos(out Vector3)`；由 InputManager 驱动；只读阈值/冷却、层栈安全、滚轮 raw/step/帧/序号/指针、候选/阻挡者/解析原因与派发帧 | 沿用·扩充 | ShortCycle 全部交互；TK-DBG-07 观测 | CK01-A #13 / AI-000075 / AI-000113 / AI-000146 / AI-000152 | 主相机每帧缓存并自动失效；缺相机 warning 每个连续缺失阶段一次；`MouseManager` 只消费 Try 成功坐标，不以兼容回退值做命中，缺指针帧保持已有业务状态 |

## 追踪表影响

- `MIG-F04 / F1-CODE-SUPPLEMENT`：源码补修与编辑器外机器门完成，可解除 AI-000148 对 AI-000152 的依赖。
- 不直接改写常驻追踪表；控制台可将 MIG-F04 的 CODE 状态更新为“补修完成”，Unity/人工证据仍沿用对应 ENGINE 与链尾统一验收记录。
