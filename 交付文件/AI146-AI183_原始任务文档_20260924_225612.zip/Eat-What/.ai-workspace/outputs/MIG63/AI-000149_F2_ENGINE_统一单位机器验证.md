# AI-000149 / F2-ENGINE 统一滚轮单位机器验证

日期：2026-09-22  
工作区：`D:/GameProject/Eat-What`  
分支：`codex/unity6-followup`  
Unity：`6000.3.24f1`  
状态：机器验证通过；最终物理滚轮手感 `PENDING_USER`。

## 1. 做了什么

- 连接仓库内固定 Unity MCP 实例 `Eat-What@d5759c75ae7cb5de`，确认 `Application.dataPath`、Unity 版本与稳定 Edit/Play 状态。
- 修复长期滚轮探针的前置 CODE 遗漏：`MouseManager.OnScroll` 已改为接收 `Vector2`，而探针仍以零参数反射调用。修复后传入当前滚动目标的世界坐标，不绕过生产 `MouseManager` 的累积、冷却、目标与层门控。
- 扩充同一探针的机器断言：增加连续多格与失焦清理；仍仅由显式菜单启动，不自动运行，不保存场景。
- 在 `FridgeScrollLab` 与正式 `ShortCycle_P0P1` 分别验证统一单位输入、业务方向映射、Tier 变化和清理语义。正式场景只做 Play Mode 临时状态，不保存。

## 2. 产物路径

- `Assets/Editor/MIG63Validation/MIG63WheelProbe.cs`
- `.ai-workspace/outputs/MIG63/Validation/20260922-144430-093-wheel/`
  - `checks.txt`：18 条 PASS
  - `pulses.txt`：raw / pending / dispatch 序列
  - `completed.txt`：测试完成标记
  - `environment.txt`：Unity、平台、Input System 与恢复场景信息
- `.ai-workspace/outputs/engine/AI-000149/Invoke-UnityMcp.ps1`：本任务对仓库内固定 MCP HTTP 端点的临时调用包装，仅位于任务输出目录。
- 本报告。

## 3. 实际验证

### 3.1 编译与运行环境

- `refresh_unity(mode=force, scope=scripts, compile=request, wait_for_ready=true)` 成功。
- 两次 Play 采样均满足 `isPlaying=true`、`isPaused=false`、`isCompiling=false`，且 `frameCount` 与 `Time.unscaledTime` 持续递增。
- 最终回到 `Assets/Scenes/Cooking/ShortCycle_P0P1.unity`，`playing=false`、`paused=false`、`compiling=false`、`updating=false`、`isDirty=false`。
- 最终 Console Error/Exception/Assert：0。

### 3.2 FridgeScrollLab

自动探针目录：`.ai-workspace/outputs/MIG63/Validation/20260922-144430-093-wheel/`。

18 条断言全部通过，其中交互断言包括：

- T8 默认值进入生产 `MouseManager`：`threshold=1`、`cooldown=0.2s`。
- 单个归一化 detent 立即派发一步。
- 冷却期只保留一步 pending，冷却后仅释放一次，无追赶洪泛。
- 五个 `0.2` 分数输入累积为一步。
- 反向输入清除相反方向的旧余量。
- 离开目标与 Modal/交互层切换均清空 pending。
- 两个间隔 detent 连续推进多层。
- 失焦清空 pending，不额外派发。
- 退出 Play 后自动恢复原保存场景；原场景、字体及字体 meta 哈希不变；运行段无 Error/Exception/Assert。

关键 dispatch 序列：`1 → pending 1 → 2 → fractional 3 → reverse 4 → leave/modal 5 → continuous 6/7 → focus setup 8`。

### 3.3 正式 P0/P1

正式场景以单独 Play 运行，先进入 Phase1，等待呈现层与运行时监听完成后再注入 Input System 滚轮值。使用场景已有 `MouseManager → MouseScrollableObject → ShortCycleScrollAdapter → ShortCycleActionRouter → ShortCycleFridgeBinder` 完整链；没有直接调用 Binder 代替输入链。

20 条断言全部通过：

- `MouseManager` 实际值为 `threshold=1`、`cooldown=0.2s`；`ShortCycleScrollAdapter` 保持既有物理方向反转。
- 单格：raw `-1`，dispatch `1`，Tier `0 → 1`。
- 连续多格：两个间隔 raw `-1`，dispatch `2/3`，Tier `1 → 2 → 3`。
- 反向：raw `+1`，业务映射为 previous，Tier `3 → 2`。
- 慢速分数累计：五个 raw `-0.2`，pending `-0.2/-0.4/-0.6/-0.8`，第五个派发，Tier `2 → 3`。
- 冷却多格：第一步 Tier `3 → 4`，后续快速输入保持 `pending=-1` 且不派发；释放后仅一步 Tier `4 → 5`。
- 反向清余量：`-0.2 → +0.5 → +0.5` 只派发反向一步，Tier `5 → 4`。
- 离区：pending `-1` 被清空，dispatch 序号不变。
- Modal/层切换：pending `+1` 被清空，dispatch 序号不变；Modal 正常压栈/出栈。
- 失焦：pending `-1` 被清空，dispatch 序号不变。
- 完整序列最终 `ScrollDispatchSequence=11`、`ReceivedStepCount=11`、Tier `5`，场景始终未脏；退出 Play 后恢复保存态。

### 3.4 配置链与非阻碍项

- 当前运行确认 `ShortCycleSessionManager.Start → CK01GeneratedDataCatalog.ResolveFridgeScrollSettings → MouseManager.ConfigureScrollInput` 已生效。
- 当前生成资产尚未含 `fridge_scroll_threshold` / `fridge_scroll_cooldown`，Console 明确记录缺键并采用审定默认值 `1 / 0.2`。权威 CSV/schema 已由 AI-000148 更新；生成资产导入与旧键残留清理由 AI-000151/F4 负责，不阻塞本任务。
- 既有探针首次因 `OnScroll(Vector2)` 签名变化触发 `TargetParameterCountException`；无产品写入，已恢复场景并最小修复探针。该历史已通过队列 `TEST_TRIGGER` 留痕。

### 3.5 哈希与 focused diff

验证前后相同：

| 文件 | SHA-256 |
|---|---|
| `Assets/Scenes/Cooking/ShortCycle_P0P1.unity` | `D082585690918C2E17683FBB8C107A7B8F2BB10D74091D7DD589297764FB11A1` |
| `Assets/Scenes/Cooking/ShortCycle_P0P1.unity.meta` | `F866CCF2493AAFB347EB92D498CD485F97EEFDB316FEE7E945EF423045D4C5E0` |
| `Assets/Scenes/ToolTests/FridgeScrollLab.unity` | `2F3579239A7415D13A72217FDEEAABB73604CEA0067F7517CDCF4C2B4A985D92` |
| `Assets/Scenes/ToolTests/FridgeScrollLab.unity.meta` | `A80079CA142FB9CEBC0E76D95BC097D164C670A7D1239DCAE4DE694FA036E32D` |
| `Assets/Font/Heavy/ShortCycle_Heavy_WithFallback.asset` | `1D379A7EB64DE1871194614F83BF61AC52E0D323677048FE237E3FBD3B399CC2` |
| `Assets/Font/Heavy/ShortCycle_Heavy_WithFallback.asset.meta` | `FD636B8448C6711DD53F53205655FDA86FAB6D2D597BF9B9F60C02BB6EFD89DA` |

focused Git 状态中上述 Scene、meta、字体均无差异；本任务产品侧唯一代码差异是已授权的长期探针修复/补断言。`git diff --check` 通过。

## 4. 三组 threshold / cooldown 候选

| 候选 | threshold | cooldown | 机器语义与建议 |
|---|---:|---:|---|
| 稳健 | `1.25` | `0.25s` | 更抗高频误拨；`0.2` 级分数输入约 7 次才触发。适合滚轮刻度偏密或用户易误触的设备。 |
| 基线（当前） | `1.0` | `0.20s` | 本轮完整机器证据；`0.2 × 5` 一步，连续拨动可稳定逐层，无追赶洪泛。建议作为首轮人工对照中心值。 |
| 灵敏 | `0.75` | `0.12s` | 更快响应细小滚动；`0.2` 级输入约 4 次触发，连续拨动响应更紧。需重点检查触控板/高分辨率滚轮是否过敏。 |

候选仅用于 Windows 物理设备人工比较。本轮没有 Mac 硬件，不将跨平台代码路径冒充 Mac 手感验收。

## 5. 待人工项

- 在 Windows 实机的 `FridgeScrollLab` 与正式 P0/P1，使用同一物理鼠标比较三组候选，确认单格可控、连续拨动停止及时、反向不黏连、细小滚动不迟钝。
- 在 F 批次末尾与“13 步驱动器 + 导表结果”合并做一次人工验收。
- Mac 实际接棒/使用前，必须用 Mac 真实鼠标或触控板重新测 threshold；本报告不包含 Mac 通过结论。

## 6. 文档影响

- 无新的产品结构、路径契约或正式场景接线变化；AI-000148 已更新 `CODEBASE_MAP.md`、项目基线和区域滚动配置说明。
- 本任务补的是 Unity 6 机器证据与长期验证探针兼容性，不再次修改项目级入口文档，避免只改核验日期。

## 工具登记影响

- 无新增长期工具条目。
- 沿用 `TK-INT-01`（MouseManager）、`TK-INT-10`（MouseScrollableObject / ShortCycleScrollAdapter）、`TK-INT-11`（ScrollArea）、`TK-DBG-07`（滚轮 trace）与 `TK-DBG-09`（FridgeScrollLab）。
- `MIG63WheelProbe` 属既有长期迁移验证工具的兼容修复与断言扩充，不改变用途、入口或所有权，因此无需改 `.ai-workspace/TOOLKIT_REGISTRY.md`。

## 追踪表影响

- `MIG-F01`：补齐 F2-ENGINE 的 Unity 6 Windows 机器证据；代码/机器阶段可进入后续 A0/A1。
- 最终手感仍为 `PENDING_USER`，不关闭 Mac 实机适配限制，也不阻断自动链后续任务。

