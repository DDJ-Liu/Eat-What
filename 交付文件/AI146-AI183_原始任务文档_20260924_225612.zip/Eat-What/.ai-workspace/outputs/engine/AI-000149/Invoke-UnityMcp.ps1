param(
    [Parameter(Mandatory = $true)]
    [string]$ToolName,
    [string]$ArgumentsJson = '{}',
    [string]$Instance = 'Eat-What@d5759c75ae7cb5de'
)

$ErrorActionPreference = 'Stop'
$endpoint = 'http://127.0.0.1:8080/mcp'
$headers = @{ Accept = 'application/json, text/event-stream' }

function ConvertFrom-McpResponse {
    param([string]$Content)

    $trimmed = $Content.Trim()
    if ($trimmed.StartsWith('{')) {
        return $trimmed | ConvertFrom-Json
    }

    $dataLines = @($Content -split "`r?`n" | Where-Object { $_ -like 'data:*' })
    if ($dataLines.Count -eq 0) {
        throw "MCP response contained no JSON data: $Content"
    }

    return (($dataLines | ForEach-Object { $_.Substring(5).TrimStart() }) -join "`n") | ConvertFrom-Json
}

function Invoke-McpRequest {
    param(
        [hashtable]$RequestHeaders,
        [hashtable]$Body
    )

    $response = Invoke-WebRequest -UseBasicParsing -Uri $endpoint -Method Post -Headers $RequestHeaders `
        -ContentType 'application/json' -Body ($Body | ConvertTo-Json -Depth 100 -Compress)
    return [pscustomobject]@{
        Response = $response
        Json = ConvertFrom-McpResponse -Content $response.Content
    }
}

$initialize = Invoke-McpRequest -RequestHeaders $headers -Body @{
    jsonrpc = '2.0'
    id = 1
    method = 'initialize'
    params = @{
        protocolVersion = '2024-11-05'
        capabilities = @{}
        clientInfo = @{ name = 'codex-ai-000149'; version = '1.0' }
    }
}

$sessionId = [string]$initialize.Response.Headers['mcp-session-id']
if ([string]::IsNullOrWhiteSpace($sessionId)) {
    throw 'Unity MCP initialize response did not provide mcp-session-id.'
}

$sessionHeaders = @{
    Accept = 'application/json, text/event-stream'
    'mcp-session-id' = $sessionId
}

Invoke-WebRequest -UseBasicParsing -Uri $endpoint -Method Post -Headers $sessionHeaders -ContentType 'application/json' `
    -Body (@{ jsonrpc = '2.0'; method = 'notifications/initialized'; params = @{} } | ConvertTo-Json -Compress) | Out-Null

if (-not [string]::IsNullOrWhiteSpace($Instance)) {
    Invoke-McpRequest -RequestHeaders $sessionHeaders -Body @{
        jsonrpc = '2.0'
        id = 2
        method = 'tools/call'
        params = @{ name = 'set_active_instance'; arguments = @{ instance = $Instance } }
    } | Out-Null
}

$arguments = if ([string]::IsNullOrWhiteSpace($ArgumentsJson)) { @{} } else { $ArgumentsJson | ConvertFrom-Json }
$result = if ($ToolName -eq '__list__') {
    Invoke-McpRequest -RequestHeaders $sessionHeaders -Body @{
        jsonrpc = '2.0'
        id = 3
        method = 'tools/list'
        params = @{}
    }
} else {
    Invoke-McpRequest -RequestHeaders $sessionHeaders -Body @{
        jsonrpc = '2.0'
        id = 3
        method = 'tools/call'
        params = @{ name = $ToolName; arguments = $arguments }
    }
}

$result.Json | ConvertTo-Json -Depth 100
