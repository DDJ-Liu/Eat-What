# AI-000147｜F1 ENGINE Unity 6 Play 容错验证

## 1. 结论

AI-000147 已在正确的 Unity 6 原工作区完成只读运行验证。正常鼠标回归、`Camera.main == null`、`Mouse.current == null` 持续 30 秒以及鼠标设备恢复后的实际悬停命中均获得证据；Play 期间与退出 Play 后 Unity Console `Error=0`。本轮没有修改或保存场景、Prefab、资源、产品源码或 ProjectSettings。

本轮验证同时确认 AI-000146 的 `Tools.TryGetMousePos` / `Tools.getMousePos` 容错在缺失鼠标与缺失主相机时不会抛异常。`MouseManager` 对无指针时的主动门控以及主相机缓存/限频告警不属于本任务修改范围，已由后续 AI-000152 计划补充。

## 2. 六要素与范围

| 要素 | 实际值 |
|---|---|
| 日期 | 2026-09-22（Asia/Shanghai） |
| 任务 | AI-000147 / F1 ENGINE Play 容错验证 |
| 项目 | `D:/GameProject/Eat-What`；`Application.dataPath = D:/GameProject/Eat-What/Assets` |
| 分支 | `codex/unity6-followup` |
| Unity | `6000.3.24f1` |
| 场景 | `Assets/Scenes/Cooking/ShortCycle_P0P1.unity` |

边界：只做 Unity MCP/Editor API 的只读检查与 Play 期间临时状态操作；没有保存场景，没有改动产品文件。验证结束时 Editor 已回到稳定 Edit Mode。

## 3. 编译与 Console

- 通过 Unity MCP 执行 Refresh/脚本编译；Domain Reload 完成后 `isCompiling=false`。
- 编译后 Console Error：`0`。
- 清空 Console 后进入 Play；Play 验证结束前 Console Error：`0`。
- 退出 Play 并回到稳定 Edit Mode 后 Console Error：`0`。
- 编译前仅见已知 MIG-P03 D3D11 Shader Warning（`SpriteOutline2D.shader` 第 133/156 行）及既有 obsolete/shared-set Warning；本轮未引入新错误。

## 4. 正常鼠标与既有回归

稳定 Play 采样：

- 样本 1：`frameCount=3323`，`Time.unscaledTime=35.1662`。
- 样本 2：`frameCount=3440`，`Time.unscaledTime=37.1201`。
- 两次采样均为 `isPlaying=true`、`isPaused=false`、`isCompiling=false`、`timeScale=1`、`Mouse.current != null`、`Camera.main != null`，帧数与游戏时间持续递增。

运行 `ShortCycleAutomatedProbe` 后：

- `completed=true`，`succeeded=true`。
- Console 标记：`CK01-C-PROBE PASS`。
- 摘要：`cover/catalog/select/browse; named start/return; bidirectional camera pan; input lock; clue anchors; P1 retention; layered ESC clear; generated recipe chain`。
- 探针读到 14 个绑定；排除 `TrayToggleDetail` 后，既有 13 键基线完整。
- 探针结束时回到 `Cover` 视图，场景仍未脏。

## 5. `Camera.main == null` 容错

在 Play 中临时把唯一 Main Camera 的 Tag 改为 `Untagged`，并在 `finally` 恢复；没有保存场景。

- 临时状态：`Camera.main == null`。
- `Tools.TryGetMousePos(out position)` 返回 `false`。
- `Tools.getMousePos()` 返回最后有效缓存坐标 `(7.5955, 6.4090, 0.0000)`。
- 异常：无。
- 恢复后：Main Camera 再次可见，场景 `isDirty=false`。

## 6. `Mouse.current == null` 30 秒容错

在 Play 中通过 Input System 暂时移除当前 Mouse 设备，使用游戏帧与 `Time.realtimeSinceStartup` 计时；每个采样同时调用 `Tools.TryGetMousePos` 与 `Tools.getMousePos`。结束时重新加入同一设备，并恢复运行时临时值。

结果：

```text
elapsed=30.018
frames=1112
samples=1112
unexpectedValid=0
pointerReappeared=0
restored=True
failure=
```

观察期间没有异常、没有意外返回有效新坐标、Mouse 没有自行重现。设备重新加入后：

- `Mouse.current != null`。
- `Tools.TryGetMousePos` 恢复为 `true`。
- `MouseManager` 仍存在并继续更新滚轮解析帧。
- 场景 `isDirty=false`。

## 7. 设备恢复后的实际命中

设备恢复后，把鼠标运行时临时移动到屏幕坐标 `(1344, 720)`，目标为当前活动的 `OpenCover_Button_AIGC` Collider；等待 20 个游戏帧后读取 `MouseManager` 实际悬停状态，再恢复原鼠标位置。

结果：

```text
frames=20
valid=True
hover=OpenCover_Button_AIGC
mousePresent=True
sceneDirty=False
```

这证明 Input System 设备重连后，指针输入和 `MouseManager` 的实际悬停命中链路均恢复。

## 8. 清理、哈希与 focused diff

退出 Play 后的稳定 Edit Mode 状态：

- `Application.isPlaying=false`
- `EditorApplication.isPlaying=false`
- `isPaused=false`
- `isPlayingOrWillChangePlaymode=false`
- `isCompiling=false`
- 活动场景仍为 `ShortCycle_P0P1.unity`
- 场景 `isDirty=false`
- `DebugAndReferences.activeSelf=false`、`activeInHierarchy=false`
- `ShortCycleManualVerificationDriver.enabled=true`
- `ShortCycleAutomatedProbe.enabled=true`
- MainCamera Tag 数量为 1，`Camera.main != null`
- `Mouse.current != null`

场景与 meta 在退出 Play 前后哈希一致：

```text
ShortCycle_P0P1.unity
D082585690918C2E17683FBB8C107A7B8F2BB10D74091D7DD589297764FB11A1

ShortCycle_P0P1.unity.meta
F866CCF2493AAFB347EB92D498CD485F97EEFDB316FEE7E945EF423045D4C5E0
```

Focused Git 审计：

- 场景与 meta：`git diff --quiet` 返回 0，无 diff。
- `Assets/Scripts/Tools/Tools.cs` 保留 AI-000146 的既有 27 增/3 删工作树改动；AI-000147 未编辑该文件。
- `Assets/Scripts/MouseInteractive/MouseManager.cs`：本轮无 diff。
- 本轮新增内容只有本验证报告和队列运行记录。

## 9. 非阻碍问题记录

1. 首次启动机器探针时使用 `GameObject.Find("DebugAndReferences")`，因该根对象 inactive 而未找到；代码未写入。已记录 `TEST_TRIGGER`，随后改用 `Resources.FindObjectsOfTypeAll` 按活动场景定位并成功完成探针。
2. 退出 Play 的首次只读核验片段直接引用两个未限定命名空间的组件类型，Roslyn 编译失败，代码未执行、无写入。已记录 `RECOVERABLE_EXECUTION`，随后改为按 `MonoBehaviour.GetType().Name` 查找并成功完成核验。

两项均已在本轮安全修正，不影响产品状态或验证结论。

## 10. 后续缺口与影响判断

- 已验证：AI-000146 对无 Mouse / 无 Main Camera 的 Tools 层容错有效。
- 未在本任务修改：`MouseManager` 的无指针主动门控、`Camera.main` 缓存及告警限频；这些属于已规划的 AI-000152 CODE 补充，不作为 AI-000147 失败项。
- M1-B6 / MIG-F04：本报告补充 Unity 6 Play 容错和输入设备重连的机器证据；不改变迁移台账状态或业务范围。
- 工具箱登记：本轮复用既有 Unity MCP、队列脚本和场景探针，没有新增长期工具，不需要更新 `.ai-workspace/TOOLKIT_REGISTRY.md`。
- 项目文档影响：没有改变系统入口、调用链、资源绑定或验证入口；无需更新 `CODEBASE_MAP.md`、项目整体基线或 AGENTS.md。
- 视觉特效说明影响：本轮不涉及视觉特效组件功能或配置，无需更新 `组件说明文档/视觉特效/`。
