[CmdletBinding()]
param()
$ErrorActionPreference = 'Stop'
$project = 'D:/GameProject/Eat-What'
$out = Join-Path $project '.ai-workspace/outputs/DATA-VISIBLE/AI-000175'
Set-Location -LiteralPath $project
. ./DevTools/DataTables/DataPipeline.Common.ps1
[void][IO.Directory]::CreateDirectory($out)
function Save-Evidence([string]$Name, [object]$Value) {
    $json = ConvertTo-Json -InputObject $Value -Depth 30
    [IO.File]::WriteAllText((Join-Path $out $Name), $json, [Text.UTF8Encoding]::new($false))
}
function Get-ProtectedSnapshot {
    $groups = [ordered]@{}
    foreach ($entry in @(
        @{name='csv';root='DataTables';csv=$true},
        @{name='generated';root='Assets/Generated/DataTables'},
        @{name='fonts';root='Assets/Font'},
        @{name='tmp';root='Assets/TextMesh Pro'},
        @{name='rounds';root='.ai-workspace/runtime/data-rounds'}
    )) {
        $full = Join-Path $project $entry.root
        $rows = @(Get-DataDirectoryManifest -Root $full | Where-Object { $null -ne $_ })
        if ($entry.csv) { $rows = @($rows | Where-Object path -Like '*.csv') }
        $groups[$entry.name] = [pscustomobject]@{
            root=$entry.root; exists=(Test-Path -LiteralPath $full -PathType Container)
            fileCount=$rows.Count; summarySha256=(Get-DataManifestSummaryHash -Manifest $rows); files=$rows
        }
    }
    $userPath = Join-Path $project '.ai-workspace/inputs/USER_WORK_STATUS.md'
    $userFile = Get-Item -LiteralPath $userPath
    $rows = @([pscustomobject]@{path=$userFile.Name;length=$userFile.Length;sha256=(Get-FileHash -LiteralPath $userPath -Algorithm SHA256).Hash})
    $groups['userStatus'] = [pscustomobject]@{root='.ai-workspace/inputs/USER_WORK_STATUS.md';exists=$true;fileCount=1;summarySha256=(Get-DataManifestSummaryHash -Manifest $rows);files=$rows}
    return [pscustomobject]@{capturedAt=[DateTimeOffset]::Now.ToString('o');groups=[pscustomobject]$groups}
}
$checkpointText = & ./.ai-workspace/queue.ps1 -Action SupervisionCheckpoint -Pipeline DATA -TaskId AI-000175 | Out-String
$checkpoint = $checkpointText | ConvertFrom-Json
Save-Evidence 'checkpoint-audit.json' $checkpoint
if ($checkpoint.action -ne 'CONTINUE') { throw "Checkpoint did not continue: $($checkpoint.action)" }
$publicationLock = $null
$lockInfo = [ordered]@{path='.ai-workspace/runtime/data-publication.lock';api='Enter-DataPublicationLock';acquiredAt=$null;releasedAt=$null}
try {
    $publicationLock = Enter-DataPublicationLock -LockPath (Join-Path $project $lockInfo.path) -TimeoutSeconds 0
    $lockInfo.acquiredAt = [DateTimeOffset]::Now.ToString('o')
    $before = Get-ProtectedSnapshot
    Save-Evidence 'protected-before.json' $before
    $queue = Get-Content -LiteralPath '.ai-workspace/runtime/queue-state.json' -Raw | ConvertFrom-Json
    $mode = Get-Content -LiteralPath '.ai-workspace/runtime/mode-state.json' -Raw | ConvertFrom-Json
    $worker = (Get-Content -LiteralPath '.ai-workspace/runtime/worker-state.json' -Raw | ConvertFrom-Json).workers.DATA
    $task = @($queue.tasks | Where-Object id -eq 'AI-000175')[0]
    $prior = @($queue.tasks | Where-Object id -eq 'AI-000164')[0]
    if ($worker.executorKind -ne 'THREAD' -or $worker.threadId -ne '01a0ce9d-8e5a-7542-82b6-6d27609d99e0' -or $worker.routeRevision -ne 1) { throw 'Wrong DATA execution target.' }
    if ($worker.activeTaskId -ne 'AI-000175' -or $worker.status -ne 'BUSY' -or $task.status -ne 'RUNNING' -or $task.pipeline -ne 'DATA') { throw 'Wrong active DATA task.' }
    if ($mode.mode -ne 'SUPERVISED' -or $mode.supervised.sessionId -ne '8c12e025cc374865a99cca4042cda1ac' -or $mode.supervised.controllerThreadId -ne '01a08798-8b2a-7d41-9aa8-ab44affd520a') { throw 'Wrong supervised session.' }
    if ($prior.status -ne 'SUCCEEDED' -or $prior.result.verificationStatus -ne 'VERIFIED') { throw 'Historical AI164 result changed.' }
    $requiredKeys = @('workflow-router','unity-project','data-batch','generated-assets','font-assets')
    foreach ($key in $requiredKeys) { if ($key -notin $task.supervisionPolicy.resourceKeys) { throw "Missing resource key: $key" } }
    $conflicts = @($queue.tasks | Where-Object { $_.id -ne $task.id -and $_.status -eq 'RUNNING' -and @($_.supervisionPolicy.resourceKeys | Where-Object { $_ -in $requiredKeys }).Count -gt 0 })
    if ($conflicts.Count -gt 0) { throw 'Concurrent protected resource owner detected.' }
    $sourcePaths = @('DevTools/DataTables/DATA_PIPELINE.md','DevTools/DataTables/Run-DataPipeline.ps1','DevTools/DataTables/DataPipeline.Common.ps1','DevTools/DataTables/DataRound.Common.ps1','Assets/Editor/DataTables/DataTableImportService.cs','.ai-workspace/queue.ps1','.ai-workspace/supervised.ps1','.ai-workspace/outputs/DATA-VISIBLE/AI-000174/AI-000174_DATA-VIS-1_完成报告.md','.ai-workspace/outputs/U1-PRE/AI-000164/host-context-recovery-20260923/AI-000164_正常宿主两用例通过报告.md')
    $sources = @($sourcePaths | ForEach-Object { [pscustomobject]@{path=$_;sha256=(Get-FileHash -LiteralPath $_ -Algorithm SHA256).Hash} })
    $roundRows = @()
    if (Test-Path -LiteralPath '.ai-workspace/runtime/data-rounds') {
        $roundRows = @(Get-ChildItem -LiteralPath '.ai-workspace/runtime/data-rounds' -File -Filter '*.json' | ForEach-Object { $r=Get-Content -LiteralPath $_.FullName -Raw | ConvertFrom-Json; [pscustomobject]@{file=$_.Name;roundId=$r.roundId;status=$r.status} })
    }
    $u1 = @(Get-Content -LiteralPath '.ai-workspace/inputs/USER_WORK_STATUS.md' | Where-Object { $_ -match '^\| USER-U1 \|' })
    $verification = [pscustomobject]@{
        taskId=$task.id;pipeline=$task.pipeline;taskStatus=$task.status;attempts=$task.attempts;claimedAt=$task.claimedAt
        hostProcessPath=[Environment]::ProcessPath;psVersion=$PSVersionTable.PSVersion.ToString()
        executionTarget=($worker | Select-Object executorKind,threadId,routeRevision)
        sessionId=$mode.supervised.sessionId;sessionStatus=$mode.supervised.status;stopRequested=$mode.supervised.stopRequested;exitRequested=$mode.supervised.exitRequested
        worker=($worker | Select-Object status,activeTaskId,leaseUntil);resourceKeys=$task.supervisionPolicy.resourceKeys
        conflictingRunningTasks=@($conflicts.id);rounds=$roundRows;userU1Row=$u1
        ai164=($prior | Select-Object id,status,@{n='verificationStatus';e={$_.result.verificationStatus}})
        reviewedContracts=@('Run-DataPipeline requires DONE plus userDecision and matching CSV hash for normal rounds.','ConsumeDataRound independently checks DONE, source hash and deduplicates roundId.','CurrentCsvValidation rejects Publish.','Isolation root is DevTools/DataTables/.batch-workspace and Unity version is 6000.3.24f1.','ImportAllBatch entry, real process exit and nonce completion proof, shared publication lock and transactional publication remain existing toolkit contracts.')
        evidenceSources=$sources;unityBatchStarted=$false;dataPublished=$false;userDoneWritten=$false
    }
    Save-Evidence 'verification.json' $verification
    $after = Get-ProtectedSnapshot
    Save-Evidence 'protected-after.json' $after
    $comparison = @(
        foreach ($name in $before.groups.PSObject.Properties.Name) {
            $a=$before.groups.$name; $b=$after.groups.$name
            $diff=@(Compare-DataDirectoryManifest -Before $a.files -After $b.files | Where-Object { $null -ne $_ })
            [pscustomobject]@{scope=$name;root=$a.root;beforeExists=$a.exists;afterExists=$b.exists;beforeCount=$a.fileCount;afterCount=$b.fileCount;beforeSha256=$a.summarySha256;afterSha256=$b.summarySha256;differenceCount=$diff.Count;differences=$diff;unchanged=($a.exists -eq $b.exists -and $a.summarySha256 -eq $b.summarySha256 -and $diff.Count -eq 0)}
        }
    )
    Save-Evidence 'protected-comparison.json' $comparison
    if (@($comparison | Where-Object { -not $_.unchanged }).Count -gt 0) { throw 'Protected snapshot difference requires attribution.' }
    [pscustomobject]@{action='READ_ONLY_AUDIT_PASSED';taskId=$task.id;sessionId=$mode.supervised.sessionId;files=($comparison | Measure-Object beforeCount -Sum).Sum;scopeCount=$comparison.Count;differences=0;summary=$comparison | Select-Object scope,beforeCount,beforeExists,beforeSha256,unchanged} | ConvertTo-Json -Depth 6
}
finally {
    if ($null -ne $publicationLock) { $publicationLock.Dispose(); $lockInfo.releasedAt=[DateTimeOffset]::Now.ToString('o') }
    Save-Evidence 'publication-lock.json' $lockInfo
}
