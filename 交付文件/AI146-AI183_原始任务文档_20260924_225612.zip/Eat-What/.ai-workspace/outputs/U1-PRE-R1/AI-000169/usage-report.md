## 8. 额度

- Date: 2026-09-23; week coverage: 2026-09-21 through 2026-09-23.
- Rule: null means unavailable, not zero. No account-capacity percentage is inferred. Coverage is observed/records.

### Daily (320 records)

| Lane | Phase | Records | Input tokens | Output tokens | Tool calls | Result bytes |
| --- | --- | ---: | ---: | ---: | ---: | ---: |
| CODE | claim | 15 | null (0/15) | null (0/15) | 9 (9/15) | 44854 (9/15) |
| CODE | execute | 88 | null (0/88) | null (0/88) | 88 (88/88) | 6138 (88/88) |
| CODE | report | 10 | null (0/10) | null (0/10) | 10 (10/10) | 71429 (10/10) |
| CODE | verify | 11 | null (0/11) | null (0/11) | 10 (10/11) | 37015 (10/11) |
| CONTROL | claim | 1 | null (0/1) | null (0/1) | 1 (1/1) | 170 (1/1) |
| CONTROL | execute | 28 | null (0/28) | null (0/28) | 28 (28/28) | 152144 (28/28) |
| CONTROL | verify | 5 | null (0/5) | null (0/5) | 10 (5/5) | 63200 (5/5) |
| CONTROL_CHAT | execute | 14 | null (0/14) | null (0/14) | 14 (14/14) | 6063 (13/14) |
| CONTROL_CHAT | report | 1 | null (0/1) | null (0/1) | 4 (1/1) | null (0/1) |
| CONTROL_CHAT | verify | 39 | null (0/39) | null (0/39) | 53 (38/39) | 31541 (32/39) |
| DATA | claim | 5 | null (0/5) | null (0/5) | 5 (5/5) | 36033 (5/5) |
| DATA | execute | 12 | null (0/12) | null (0/12) | 12 (12/12) | 4735 (12/12) |
| DATA | report | 6 | null (0/6) | null (0/6) | 5 (5/6) | 45448 (5/6) |
| DATA | verify | 1 | null (0/1) | null (0/1) | 3 (1/1) | 2660 (1/1) |
| ENGINE_MCP | claim | 7 | null (0/7) | null (0/7) | 4 (4/7) | 20848 (4/7) |
| ENGINE_MCP | execute | 73 | null (0/73) | null (0/73) | 73 (73/73) | 14803 (73/73) |
| ENGINE_MCP | report | 4 | null (0/4) | null (0/4) | 4 (4/4) | 47335 (4/4) |

Top 5 calls by result bytes:
- 20751 bytes | AI-000156 | CONTROL/verify | queue:RejectVerification
- 17510 bytes | AI-000162 | ENGINE_MCP/report | queue:Complete
- 17199 bytes | AI-000156 | ENGINE_MCP/report | queue:Complete
- 16899 bytes | AI-000162 | CONTROL/execute | queue:ConfigureSupervisionTask
- 16573 bytes | AI-000154 | CONTROL/verify | queue:ResolveVerification
Top 5 tasks by result bytes:
- 132065 bytes | AI-000164 | CODE | 32 records
- 50970 bytes | AI-000156 | ENGINE_MCP | 34 records
- 49837 bytes | AI-000162 | ENGINE_MCP | 38 records
- 45870 bytes | AI-000157 | CODE | 29 records
- 39547 bytes | AI-000174 | CONTROL | 17 records

### Weekly (320 records)

| Lane | Phase | Records | Input tokens | Output tokens | Tool calls | Result bytes |
| --- | --- | ---: | ---: | ---: | ---: | ---: |
| CODE | claim | 15 | null (0/15) | null (0/15) | 9 (9/15) | 44854 (9/15) |
| CODE | execute | 88 | null (0/88) | null (0/88) | 88 (88/88) | 6138 (88/88) |
| CODE | report | 10 | null (0/10) | null (0/10) | 10 (10/10) | 71429 (10/10) |
| CODE | verify | 11 | null (0/11) | null (0/11) | 10 (10/11) | 37015 (10/11) |
| CONTROL | claim | 1 | null (0/1) | null (0/1) | 1 (1/1) | 170 (1/1) |
| CONTROL | execute | 28 | null (0/28) | null (0/28) | 28 (28/28) | 152144 (28/28) |
| CONTROL | verify | 5 | null (0/5) | null (0/5) | 10 (5/5) | 63200 (5/5) |
| CONTROL_CHAT | execute | 14 | null (0/14) | null (0/14) | 14 (14/14) | 6063 (13/14) |
| CONTROL_CHAT | report | 1 | null (0/1) | null (0/1) | 4 (1/1) | null (0/1) |
| CONTROL_CHAT | verify | 39 | null (0/39) | null (0/39) | 53 (38/39) | 31541 (32/39) |
| DATA | claim | 5 | null (0/5) | null (0/5) | 5 (5/5) | 36033 (5/5) |
| DATA | execute | 12 | null (0/12) | null (0/12) | 12 (12/12) | 4735 (12/12) |
| DATA | report | 6 | null (0/6) | null (0/6) | 5 (5/6) | 45448 (5/6) |
| DATA | verify | 1 | null (0/1) | null (0/1) | 3 (1/1) | 2660 (1/1) |
| ENGINE_MCP | claim | 7 | null (0/7) | null (0/7) | 4 (4/7) | 20848 (4/7) |
| ENGINE_MCP | execute | 73 | null (0/73) | null (0/73) | 73 (73/73) | 14803 (73/73) |
| ENGINE_MCP | report | 4 | null (0/4) | null (0/4) | 4 (4/4) | 47335 (4/4) |

Top 5 calls by result bytes:
- 20751 bytes | AI-000156 | CONTROL/verify | queue:RejectVerification
- 17510 bytes | AI-000162 | ENGINE_MCP/report | queue:Complete
- 17199 bytes | AI-000156 | ENGINE_MCP/report | queue:Complete
- 16899 bytes | AI-000162 | CONTROL/execute | queue:ConfigureSupervisionTask
- 16573 bytes | AI-000154 | CONTROL/verify | queue:ResolveVerification
Top 5 tasks by result bytes:
- 132065 bytes | AI-000164 | CODE | 32 records
- 50970 bytes | AI-000156 | ENGINE_MCP | 34 records
- 49837 bytes | AI-000162 | ENGINE_MCP | 38 records
- 45870 bytes | AI-000157 | CODE | 29 records
- 39547 bytes | AI-000174 | CONTROL | 17 records
