# AI-000176 · PRE-1c-PREFAB-R1 修复报告

日期：2026-09-24  
车道：CODE（SUPERVISED）  
结论：源码修复与编辑器外验证通过；生产迁移写入 0；未启动或控制 Unity Editor，未修改 `.unity/.prefab/.asset/.meta`，未提交或推送 Git。

## 六要素

- 做了什么：在既有 `ShortCycleFontSwapTool` 内修正批准行、真实写入位置和 Prefab 源关系的分类；扩充固定事务、传播防护、写入顺序与精确回退；补充调用生产核心的隔离回归。
- 产物路径：`Assets/Editor/Fonts/ShortCycleFontSwapTool.cs`、`DevTools/Fonts/FontSwapDryRunHarness.cs`、`DevTools/Fonts/Test-FontSwap.ps1`；机器摘要见同目录 `verification-summary.json`。
- 实际验证：窄回归通过；两次 `Verify-All -Profile Fonts -Mode Final` 的两名 runner 均通过。第二次原因是收尾审查发现未批准传播只有生产实现/编译证据，遂提取生产纯判定核心并增加直接回归后复验。最终 Unity 6000.3.24f1/TMP 真实 DLL 编译通过，36 项静态断言、27 个字体 guard、171/171 行级事务覆盖通过。
- 待人工项：ENGINE 必须重新运行真实 Editor 全量预检，取得修复后的真实 `uniqueEntryCount/executeAllowed/reasons`；之后再做单样例→完整回退、正式分批、Play/Build 与最终画面人工验收。本报告不代签这些步骤。
- 文档影响：更新 `DevTools/Fonts/README.md`、`.ai-workspace/toolkit/LOC.md`、`CODEBASE_MAP.md`、`项目整体阅读理解与推进基线_2026-08-14.md`，说明新分类、schema 3、传播/顺序约束及真实 Editor 未验边界；未改完整复核日期。
- 工具登记影响：扩充 TK-LOC-03，不新增平行迁移器或公开私有反射入口。

## 源码与事务结果

1. `assetPath + objectPath + componentIndex` 保持为每条批准行和实际写入位置的稳定身份；`prefabSourceIdentity` 只记录继承关系，不再无条件取代实例身份。
2. 仅当批准源行唯一存在、实例没有对应字段 override、迁移前 font/material 都与源等价、批准后的目标 font/material 也等价时，实例才由源写入覆盖；目标不同或具有真实 override 的实例保持独立，原风格不被源目标覆盖。
3. 固定事务升级到 schema 3，保存全部 171 行的写入覆盖、Prefab 源关系、迁移前/后引用、字段 override 结构和非目标指纹。每批验证全部行，而不只检查选中的 canonical 代表。
4. 对目标不同的源/实例，前向批次要求场景实例先于源 Prefab；回退采用相反顺序。源写入若可能传播到未批准 TMP，则在建事务前列出 `UNAPPROVED_PREFAB_PROPAGATION|source|row|fields` 并拒绝执行。
5. 状态转换保持公开且可恢复：`PLANNED → IN_PROGRESS → FULLY_APPLIED_PENDING_VALIDATION → COMPLETED`；业务写入后异常进入 `ROLLED_BACK_AFTER_FAILURE`，回退自身失败才进入 `ROLLBACK_FAILED`；显式回退为 `ROLLED_BACK`。同一 batchId+同一身份集合重入先全量复核，然后 `changed=0`。
6. 回退恢复原 font/material 引用和字段 override 结构；原本继承的字段使用 Prefab override 回退语义，重复回退为零写入。未知 before/after、已完成或待办漂移、关系变化、文件快照变化和非目标指纹变化都拒绝后续写入。

## 回归证据

`DevTools/Fonts/Test-FontSwap.ps1` 的生产核心夹具结果：

| 断言 | 结果 |
|---|---:|
| 批准 CSV 原始行 / 逐行覆盖 | 171 / 171 |
| 不同 before/after 的源与实例保持独立 | 通过（离线语义夹具唯一项 171；不是 Editor 真实计数） |
| 完全等价继承安全去重 | 通过（专用夹具 171→170） |
| 真实 override 分类 / 同一物理写入互斥目标拒绝 | 通过 / 通过 |
| 批准继承传播 / 未批准传播防护 | 通过 / 通过 |
| 实例优先及源先行拒绝 | 通过 |
| 单样例不扩散、回退、重复回退 | 通过 |
| 两批覆盖 / 同批恢复零重复写 | 2 批 / 通过 |
| 非法选择零写、待办/既成/未知状态漂移拒绝 | 通过 |
| 非目标指纹、失败全事务回退、override 结构恢复 | 通过 |
| `productionWrites` | 0 |

Fonts Final：首次通过；随后为新增“未批准 Prefab 继承传播精确差异”生产核心直测执行一次有理由复验，第二次也通过：

```text
DevTools/Verify-All.ps1 -TaskId AI-000176 -Profile Fonts -Mode Final
VERIFY_ALL_PASSED; runnerCount=2
Test-ShortCycleFonts.ps1 PASSED; Unity=6000.3.24f1; staticAssertions=36; guardCases=27; compiledEditorDllBytes=129536
Test-FontSwap.ps1 PASSED; rawEntries=171; approvedRowCoverage=171; productionWrites=0
RepeatReason=补充未批准Prefab继承传播的生产纯核心直接回归，验证精确source/row/fields差异后复验真实Unity6/TMP DLL编译与全量Fonts契约。
```

历史记录：`.ai-workspace/runtime/verify-all/verify-all-AI-000176.jsonl`。

## 批准输入与生产零写入

- 批准 CSV：`.ai-workspace/outputs/control/U1-PRE-20260923/PRE1_字体材质迁移逐项草案.csv`
- SHA-256：`EB0CED01C1BBB0050DCF30BAA3D5354E9F2C7326C3DF97375DE87467D8FE347B`，与任务锁定值一致，内容未改。
- AI170 预检后的场景基线仍为 `233113A72258444BD69C6FD014424435C4D15DD4D1EA9C01A8CF61F13E71BECB`。
- 五个批准 Prefab 仍分别为：CatalogCard `9A30DA8F1F7080BDDCFAE12848FD0E022FA13C226A3903789A3B5C400C502146`、FridgeSlot `0B840E5942F96694B44BF27A9FC2216596495A64B788C7A6F885C296A4C60245`、IngredientCard `4C516362DA457838C0CC99BA811D20119131F760EDCA47A509B9A348762A1308`、Sticker `5BD1E3B284C832500F205234EA1A1C206DCE11BCC8F2B2D1E96102F6FFC473B6`、TraySlot `DD7986B78C89BF07750F30FA2F5D5E91A965674E1236B42471BD0E616122D0C9`。
- 三份 `ShortCycle_Static_From*.mat` 目标材质仍不存在；本任务没有材质创建、分配或 Unity 自动导入。

## diff 与最终源码指纹

共享工作树中字体源码/测试自 AI167 起仍为未跟踪交付，不能伪造为相对 HEAD 的常规 diff；本任务保留其它任务改动，使用前后报告指纹、最终文件指纹、范围检查和真实 DLL 编译作证：

| 文件 | AI173 报告指纹 | AI176 最终 SHA-256 |
|---|---|---|
| `ShortCycleFontSwapTool.cs` | `B79A1B100D1ADCD15BDFD589CB09FAC0ECD608E6E6E11513E85D1D27FBF9AAA3` | `34C2C7636EAE7274F814E2080A691FE40663707FA10FCCC59CA109003306CEB8` |
| `FontSwapDryRunHarness.cs` | `AFEA7D9B0EE020FE52054276DD5CCADA1AA25C62C33DD3724491E2C5A5FEB945` | `7C75D5526C65EE31C739FF748BD0C104F8C4ADFA7DC5EB1C5FC14749A3BC0AB0` |
| `Test-FontSwap.ps1` | 未在 AI173 报告单列 | `FD780C526F95D807AE7260D7DD795569D017DD16781910C930D9BFBD19E1EEE0` |

任务范围 `git diff --check` 通过；没有清理、回退、提交或覆盖共享工作树。文档及报告之后的最终哈希由机器摘要单独记录，不宣称整个工作树干净。

## ENGINE 公开 API 移交

继续使用公开入口 `PreviewApprovedMigration/PreviewApprovedBatch`、`BeginApprovedMigration`、`ApplyApprovedBatch`、`FinalizeApprovedMigration`、`RollbackApprovedMigration/RollbackApprovedBatch`；不允许反射 private 方法或手写事务。ENGINE 新预检必须确认：raw 与行覆盖均为171、无未批准传播、每条行覆盖关系可解释、实例/源顺序满足计划、`executeAllowed=true` 后才可开始样例。AI170 的 `uniqueEntryCount=63` 与 8 组旧冲突仅保留为失败史，不是修复后结论。

## 影响与异常

- 影响块：仅字体批准迁移 Editor 工具、离线回归、TK-LOC-03 和相关导航说明；不改变批准范围、序列化字段名、旧字体/材质、布局、140 wrap、Renderer 或全局 fallback。
- 异常：0 个未解决 CODE 阻断。真实 Editor 结果为明确后继验证项，不记为本任务异常或成功。
- 使用量：运行时任务记录不可见 token/model 字段按 `null` 处理，不从账户窗口推算；以队列生命周期记录为准。
