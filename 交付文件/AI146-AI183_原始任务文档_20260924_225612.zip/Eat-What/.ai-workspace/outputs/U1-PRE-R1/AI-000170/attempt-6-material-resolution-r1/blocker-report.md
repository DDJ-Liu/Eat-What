# AI-000170 attempt 6 blocker report

## Outcome

The fresh Unity 6000.3.24f1 schema-7 / non-target-fingerprint-v3 preview failed closed before any transaction, backup, material creation, or production asset write.

- `rawEntryCount`: 231
- `uniqueEntryCount`: 153
- `rows`: 183
- `approvedAssetPaths`: 7
- `materials`: 3
- `executeAllowed`: `false`
- `reasons`: 49
  - `APPROVED_ROW_COVERAGE|actual=183|expected=231`: 1
  - prefab-source `SOURCE_DRIFT`: 8
  - `TraySlot_01_TUNE..20_TUNE` scene `SOURCE_DRIFT`: 40

The required acceptance gate was 231 rows, 7 resources, `reasons=[]`, and `executeAllowed=true`, so diagnostic, sample transaction, and full transaction were not started.

## Newly exposed CODE inconsistency

The schema-7 implementation reads exact serialized `m_sharedMaterial` references for direct prefab assets. The approved CSV expects the WithFallback default material for these eight prefab-source rows, while the baseline prefab bytes contain other material references:

- `CatalogCard.prefab`: `BadgeLabel`, `NameLabel` -> SourceHan material
- `IngredientCard.prefab`: `BadgeLabel`, `NameLabel` -> SourceHan material
- `Sticker.prefab`: `BadgeLabel`, `NameLabel` -> Heavy material
- `TraySlot.prefab`: `BadgeLabel`, `NameLabel` -> SourceHan material

All eight are rejected with `MATERIAL_GLOBAL_ID,UNEXPLAINED_EFFECTIVE_MATERIAL`. They are outside the only permitted normalization set, which is exactly the 40 ShortCycle `TraySlot_01_TUNE..20_TUNE` scene rows. Weakening the guard, changing either approved CSV, or broadening normalization would violate the task boundary.

The same preview also rejects the 40 permitted scene rows with `MATERIAL_GLOBAL_ID`, leaving them absent from the 183 accepted rows. This means the AI-000180 CODE fix does not yet produce the task's required raw/effective resolution contract in the real Editor.

## Safety and preservation evidence

- Unity instance: `Eat-What@d5759c75ae7cb5de`
- Unity version: `6000.3.24f1`
- Project root: `D:/GameProject/Eat-What`
- Active scene: `Assets/Scenes/Cooking/ShortCycle_P0P1.unity`
- Final state: Edit Mode, not compiling, active scene clean
- Console: 0 errors; 2 existing compile warnings and 2 informational visibility messages
- Base CSV SHA-256: `EB0CED01C1BBB0050DCF30BAA3D5354E9F2C7326C3DF97375DE87467D8FE347B`
- Supplemental CSV SHA-256: `E8AA50B24E3ACA11E55D21F752EB92CD801B83960F443DF12E199DBC1B33A579`
- All seven production resources and their metas retain the attempt-5 baseline SHA-256 values.
- The three target material assets do not exist.
- No attempt-6 backup exists.
- No `BeginApprovedMigration`, `ApplyApprovedBatch`, `FinalizeApprovedMigration`, or rollback call occurred.

Primary evidence: `approved-plan.json` in this directory.

## Required next action

Return to CODE. Reconcile exact saved prefab-source material references with the externally approved CSV while preserving the hard rule that only the 40 named scene rows may carry `TMP_LOAD_FONT_ATLAS_MISMATCH_DEFAULT_MATERIAL`. Do not change the CSVs or production assets to make the preview pass.
