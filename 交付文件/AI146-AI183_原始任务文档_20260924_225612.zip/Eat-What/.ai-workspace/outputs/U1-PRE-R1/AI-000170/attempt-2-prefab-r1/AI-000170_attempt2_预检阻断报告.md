# AI-000170 · attempt 2 Prefab R1 预检阻断报告

日期：2026-09-24。结论：**正式迁移未开始**。AI176 修正后的 schema 3 工具已在 Unity 6000.3.24f1 中完成真实只读预检，原 canonical identity 冲突已消除；新的 Prefab 传播安全门发现批准范围外的 `FridgeScrollLab` 实例，因此 `executeAllowed=false`。本轮未绕过安全门、未建立生产事务、未创建目标材质、未修改场景或 Prefab。

## 六要素

- 做了什么：固定使用 `Eat-What@d5759c75ae7cb5de`，在 Edit Mode 对批准 CSV 和旁证运行 `ShortCycleFontSwapTool.PreviewApprovedMigration`；确认 schema 3 行级覆盖、Prefab 源关联、传播守卫与三份材质计划。首次加载时 Unity 仍持有旧 Editor 程序集，已按正常 Refresh/Compile 恢复并在队列记录 `RECOVERABLE_EXECUTION`，随后成功执行新版预检。
- 产物路径：`approved-plan.json`、本报告及 `verification-summary.json`。本 attempt 使用独立目录 `.ai-workspace/outputs/U1-PRE-R1/AI-000170/attempt-2-prefab-r1/`，未覆盖 attempt 1 证据。
- 实际验证：批准输入 `raw=171`，schema 3 `rows=171`、`unique=141`、`directEntries=141`、`sourceLinkedRows=130`、`coveredByPrefabSourceRows=30`；三个目标材质计划均 `ready=true`。预检返回 60 条 `UNAPPROVED_PREFAB_PROPAGATION`，且没有旧版 `CANONICAL_CONFLICT`。Unity 终态为 `ShortCycle_P0P1`、Edit Mode、scene clean、未编译、Console Error 为 0；三份目标材质均不存在。
- 阻断项：批准修改 `Assets/Prefabs/Cooking/ShortCycle/GridPieces/FridgeSlot.prefab` 的 `FridgeSlot/BadgeLabel` 与 `FridgeSlot/NameLabel` 的 `m_fontAsset`，会传播到 `Assets/Scenes/ToolTests/FridgeScrollLab.unity` 中 `FridgeSlot_01` 至 `FridgeSlot_30` 的同名标签，共 30 实例 × 2 字段 = 60 条未在 171 行批准映射内的变化。任务卡明确要求新预检阻断出现时保留证据并停止，不能修改 CSV、绕过传播守卫或盲目重试。
- 文档影响：未改变项目入口、业务调用链、资源契约或验证路径；无项目级文档影响。
- 工具登记影响：仅消费既有 TK-LOC-03 字体迁移工具公开面；没有新增、扩充、更名或弃用工具。

## 零写入与基线保护

- 未调用 `BeginApprovedMigration`、`ApplyApprovedBatch` 或 `FinalizeApprovedMigration`，生产写入数为 0；因此没有生产写批次，也无需 `SupervisionCheckpoint` 或回退。
- 活动场景 SHA-256 保持 `233113A72258444BD69C6FD014424435C4D15DD4D1EA9C01A8CF61F13E71BECB`，scene meta 保持 `F866CCF2493AAFB347EB92D498CD485F97EEFDB316FEE7E945EF423045D4C5E0`。
- 五个批准 Prefab SHA-256 保持：CatalogCard `9A30DA8F1F7080BDDCFAE12848FD0E022FA13C226A3903789A3B5C400C502146`；FridgeSlot `0B840E5942F96694B44BF27A9FC2216596495A64B788C7A6F885C296A4C60245`；IngredientCard `4C516362DA457838C0CC99BA811D20119131F760EDCA47A509B9A348762A1308`；Sticker `5BD1E3B284C832500F205234EA1A1C206DCE11BCC8F2B2D1E96102F6FFC473B6`；TraySlot `DD7986B78C89BF07750F30FA2F5D5E91A965674E1236B42471BD0E616122D0C9`。
- 三份批准目标材质均未创建。目标字体 `ShortCycle_Heavy_Static.asset` 仍为 Static；其既有 fallback 表含一份 Dynamic fallback，本轮没有改动。
- Git 聚焦检查仅显示场景已有工作树差异；本轮前后以 AI169 接力 SHA 为边界，哈希未变化，五个 Prefab 无聚焦差异。

## 后续决策需求

控制端需要决定是否把 `FridgeScrollLab` 的 60 条继承变化纳入明确批准范围，或先在独立任务中建立不会传播到该 Lab 的资源边界。ENGINE_MCP 不应在现有 171 行授权下继续写入。

## 用量

- Provider 输入/输出 token 与模型：`null`；当前执行器未暴露对应指标，不估算为 0。

