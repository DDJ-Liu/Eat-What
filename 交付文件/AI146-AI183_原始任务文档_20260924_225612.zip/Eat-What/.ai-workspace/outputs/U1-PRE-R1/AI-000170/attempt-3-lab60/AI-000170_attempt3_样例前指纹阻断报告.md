# AI-000170 · attempt 3 Lab60 样例前指纹阻断报告

日期：2026-09-24。结论：**231 行 schema 4 只读预检通过，但样例事务在备份及任何生产写入前被实时非目标指纹校验拒绝。** 本轮未绕过校验、未创建备份或事务、未创建目标材质、未修改两个场景或五个 Prefab。

## 六要素

- 做了什么：读取 AI177、两份批准输入和监管/清理协议；固定 `Eat-What@d5759c75ae7cb5de`，刷新并编译 AI177 Editor 工具；调用双映射公开 `PreviewApprovedMigration`，随后在 `SupervisionCheckpoint=CONTINUE` 后调用公开 `BeginApprovedMigration` 建立单 FromSourceHan 样例事务。Begin 在 `ValidateLiveTransactionState` 阶段拒绝，未到 `CreateBackup` 或事务写入。
- 产物路径：`approved-plan.json`、`sample-plan.json`、`fingerprint-drift-evidence.json`、`verification-summary.json` 及本报告，全部位于 `.ai-workspace/outputs/U1-PRE-R1/AI-000170/attempt-3-lab60/`。
- 实际验证：schema 4 真实 Editor 预检为 `raw=231`、`rows=231`、`unique=201`、批准资源 7、`executeAllowed=true`、reasons 0、三材质计划 ready。Begin 随后报 `NON_TARGET_FINGERPRINT_DRIFT|...CatalogCard/BadgeLabel|0`。连续两份只读计划有 70 个非目标指纹变化：五个 Prefab 各 2 个标签及 FridgeScrollLab 60 个标签；字体和材质引用保持一致。最小只读复现证明同一 Prefab 连续两次 `LoadPrefabContents` 时只有 `m_GameObject.m_FileID` 与 `m_renderer.m_FileID` 变化，它们是瞬态实例 ID。
- 待处理项：`ComputeNonTargetFingerprint` 当前会递归进入对象引用的子 `m_FileID`，使 Preview 与紧随其后的实时校验必然可能产生不同指纹。需由 CODE 在不削弱真正非目标字段保护的前提下，使对象引用采用稳定 GlobalObjectId 且不再纳入瞬态子 FileID；ENGINE 不得改事务、反射 private、删除校验或盲目重试同一方案。
- 文档影响：未改变项目入口、资源契约或验证流程；仅新增本次失败证据，无项目级文档影响。
- 工具登记影响：仅消费既有 TK-LOC-03 公开 API；没有在 ENGINE 侧扩展工具。

## 零写入与现场保护

- 样例 `BeginApprovedMigration` 失败前没有生成 `sample-transaction.json`，`DevTools/Fonts/backup/AI-000170` 仍不存在；三份 `ShortCycle_Static_From*.mat` 均不存在，生产写入数为 0。
- `ShortCycle_P0P1.unity` SHA-256 保持 `233113A72258444BD69C6FD014424435C4D15DD4D1EA9C01A8CF61F13E71BECB`；`FridgeScrollLab.unity` 保持 `4086672BB61AB57B8D32913922A80BD4708E56A1FF96C8D7CD644EB2857CC02D`。五个批准 Prefab 及全部 meta 哈希与 AI177 控制端基线一致。
- Unity 最终为单场景 `ShortCycle_P0P1`、Edit Mode、scene clean、未编译；Console Error/Exception 为 0。Dynamic fallback character/glyph 均为 0。
- 因样例事务未能建立，未进入样例写入/回退、全量批次、Play、截图或 Build；这是任务卡规定的硬停止点，不把未执行验证写成通过。

## 可恢复历史

首次 schema 4 探针发现 Unity 仍加载 AI176 旧程序集，Roslyn 在编译期拒绝且代码未执行；已记录 `RECOVERABLE_EXECUTION`，正常 Refresh/Compile 后新版预检成功。该问题与本次确定性的非目标指纹阻断分开记录。

## 用量

- Provider 输入/输出 token 与模型：`null`；当前执行器未暴露对应指标，不估算为 0。

