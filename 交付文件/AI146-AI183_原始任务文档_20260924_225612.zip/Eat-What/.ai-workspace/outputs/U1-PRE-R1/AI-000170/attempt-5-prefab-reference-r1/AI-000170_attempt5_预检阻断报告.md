# AI-000170 attempt 5 预检阻断报告

## 做了什么

- 在 Unity 6000.3.24f1 主 Editor 中刷新并编译 AI-000179 的 schema 6 / 非目标指纹 v3 工具；Console 为 0 error。
- 以批准的原 171 行 CSV、Lab60 补表及两份批准旁证生成全新预览；随后在任务自有空场景中暂时卸载两个目标场景，再执行一次只读预览复核，并在 `finally` 恢复原场景布局。
- 两次预览均在 `BeginApprovedMigration` 之前拒绝执行，未创建备份、事务、材质或任何业务资源写入。

## 产物路径

- `approved-plan.json`（SHA-256 `8AE1C7722840AB40866FF021AFE8B6F289F1E62A4E5496C09595E117BB9D3A8D`）
- `approved-plan-unloaded.json`（SHA-256 `12802FCD9B1BAE6822B49B599602F381A6851D76DA85F77F92BBA406AE7DD344`）

## 实际验证

- 两次结果一致：`schemaVersion=6`、`nonTargetFingerprintVersion=3`、`rawEntryCount=231`、`rowCount=191`、`uniqueEntryCount=161`、批准资产 7、`executeAllowed=false`。
- 原因共 41 条：1 条 `APPROVED_ROW_COVERAGE|actual=191|expected=231`，以及 ShortCycle 场景 `TraySlot_01_TUNE` 至 `TraySlot_20_TUNE` 的 BadgeLabel/NameLabel 共 40 条 `MATERIAL_GLOBAL_ID` 源漂移。
- 批准 CSV 和磁盘 YAML 仍指向 SourceHan 材质 `GlobalObjectId_V1-3-53ffd732c8bc2034f93d5a714c25eda2-12569091968840867831-0`；Unity 6 刷新后的真实 `SerializedObject.m_sharedMaterial` 则解析为 WithFallback 内嵌材质 `GlobalObjectId_V1-3-75909fc3d0fa2c94baa5706654d37655-9052723641695353799-0`。加载场景与卸载场景路径结果相同。
- 两场景、五 Prefab 及各自 meta 的 SHA-256 均保持任务基线；3 个目标材质不存在，`DevTools/Fonts/backup/AI-000170` 不存在，sample/full transaction 不存在。
- 收尾状态：仅 `ShortCycle_P0P1` 加载且 active，`isDirty=false`，稳定 Edit Mode，Console 0 error。

## 待人工项

- 无可安全跳过的人工验收项。批准映射与 Unity 6 实际序列化对象之间的 40 行材质身份不一致必须由控制端组织 CODE/数据边界修复或重新审定；ENGINE 不修改 CSV、计划或工具以绕过预检。

## 文档影响

- 无项目文档更新：本轮未改变结构、入口、数据契约或生产资源，只新增失败证据。

## 工具登记影响

- 无工具登记变更。AI-000179 的指纹 v3 已在真实 Editor 编译通过；本次阻断属于批准源材质身份与 Unity 6 解析结果不一致，不是 MCP 连接或指纹内部引用故障。
