# AI-000180 / PRE-1c-MATERIAL-RESOLUTION-R1 完成报告

- 任务：修复 TMP 载入时材质归一化与已批准磁盘基线的冲突，并为后续 ENGINE/Unity 实机验证交付可追溯的双视图证据。
- 结果：CODE 范围实现和静态/编译验证已完成。仅严格限定的 40 个 `TraySlot_01_TUNE..20_TUNE` 的 `BadgeLabel/NameLabel` 行可在完整证明成立时接受 `TMP_LOAD_FONT_ATLAS_MISMATCH_DEFAULT_MATERIAL`；任何其他行、证明缺失、SHA 漂移、显式覆盖或第三方有效材质均失败关闭。

## 改动产物

- `Assets/Editor/Fonts/ShortCycleFontSwapTool.cs`：交易/计划 schema 升级为 7，诊断 schema 升级为 2；增加已批准 CSV、原始序列化/继承/覆盖引用、加载后有效材质三方视图与严格分类。
- `DevTools/Fonts/FontSwapDryRunHarness.cs`、`DevTools/Fonts/Test-FontSwap.ps1`：增加归一化成功、失败关闭、回滚及有符号/无符号 GlobalObjectId 回归。
- `DevTools/Fonts/README.md`、`.ai-workspace/toolkit/LOC.md`：更新工具契约、schema 和诊断证据说明。
- `CODEBASE_MAP.md`、`项目整体阅读理解与推进基线_2026-08-14.md`：记录 CODE 完成状态、入口、风险与待 ENGINE 实机签收边界。
- 本目录内的完成报告与 `ENGINE-handoff.md`。

## 验证证据

- 唯一 Final：`DevTools/Verify-All.ps1 -TaskId AI-000180 -Profile Fonts -Mode Final` 返回 `VERIFY_ALL_PASSED`。
- Runner：2/2 通过；`Test-ShortCycleFonts.ps1` 通过，`Test-FontSwap.ps1` 通过。
- 编译：基于 Unity `6000.3.24f1` 与实际 TMP DLL 编译生产 Editor 源码，产物 `161792` bytes。
- 回归：36 项静态断言、27 个 guard case；`materialDualViewGuard=true`、`materialNormalizationFailClosed=true`、`normalizedRollback=true`、`unsignedGlobalObjectIdGuard=true`。
- 诊断基数：原始 171 行 + 补充 60 行 = 231 行，7 个资产；验证过程 `productionWrites=0`。
- 历史记录：`.ai-workspace/runtime/verify-all/verify-all-AI-000180.jsonl`。
- 生产基线保持：目标 Prefab/场景/场景 meta/两份 CSV 哈希与 AI-000170 attempt-5 基线一致；三个目标材质及 meta 仍不存在；`.ai-workspace/runtime/font-backups` 不存在；`productionMigrationWrites=0`。

## 边界与未竟项

- 本任务未启动或操作 Unity/MCP，未修改 `.unity`/`.prefab`/`.asset`/`.meta`，未执行 Git 操作。
- CODE 只能证明编译、算法、静态基线和失败关闭契约；TMP 真实加载生命周期、两次诊断的 231 行一致性、精确 40 行归一化及完整回滚/执行尚需 ENGINE 在当前 Unity 6 Editor 中验证。
- 旧 schema 1–6 计划不得执行，必须生成新 schema-7 计划；旧回滚兼容仅为安全恢复保留。
- 文档影响：已同步更新工具说明、LOC 登记、CODEBASE_MAP 与项目推进基线；未修改完整结构复核日期。

## 可复核哈希

- `ShortCycleFontSwapTool.cs`: `EFFC8196DA21275DF05B194686D78BA6047B20B5F24C4C6F0C7B7BBCAFF94AE9`
- `FontSwapDryRunHarness.cs`: `C8D8A125E12DEDC046B74AE2E85C7B8FA625DB8A3105DDD39B427F7153C74939`
- `Test-FontSwap.ps1`: `67FACBA70D0C08F26E92C47C2DAA5DEED50253FA73FC1B408F1E2C60079C0146`
- 基础 CSV: `EB0CED01C1BBB0050DCF30BAA3D5354E9F2C7326C3DF97375DE87467D8FE347B`
- 补充 CSV: `E8AA50B24E3ACA11E55D21F752EB92CD801B83960F443DF12E199DBC1B33A579`

## 用量

- provider/model/token：`null`。原因：当前任务上下文与工具未暴露 provider/model/token 的精确计量，本报告不伪造数据。
