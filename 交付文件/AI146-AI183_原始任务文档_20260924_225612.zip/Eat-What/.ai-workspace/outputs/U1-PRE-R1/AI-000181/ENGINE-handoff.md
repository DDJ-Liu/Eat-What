# AI-000181 → 控制台只读移交

AI-000181 只完成纯代码修复，不恢复 AI-000170。后继控制台应先核对 `source-hashes.json` 和 14 个冻结生产 SHA，再在当前 Unity 6000.3.24f1 主 Editor、共享资源空闲且两个批准场景关闭时执行新版 schema 8 的真实 231 行 Preview 与两轮 `DiagnoseApprovedNonTargetFingerprints`。

只读通过门槛：rawEntryCount=231、rows=231、7 资源、executeAllowed=true、reasons=0；诊断两轮均逐 231 行稳定，批准观察/saved raw/loaded effective、保存/加载/迁移 override、owner/source SHA 完整；40 个 Tray 场景行只出现 `TMP_LOAD_FONT_ATLAS_MISMATCH_DEFAULT_MATERIAL`，精确 8 个源行只出现 `APPROVED_LOAD_OBSERVATION_TMP_DEFAULT_MATERIAL`，其余行为无解释差异。不得 Begin、创建三材质或迁移。

若只读门槛通过，再由控制台结合 AI-000170 的最后恢复预算决定是否 Recover；本任务不提供该决定。若失败，保留真实逐行证据，不循环新建替代迁移任务。

新回退顺序：批准场景关闭 → 校验阶段快照和当前行状态 → 校验 backup manifest/每个备份 SHA → byte-exact 恢复 7 资源及 meta → ForceSynchronousImport/ForceUpdate → 复核 231 行与冻结 SHA → 删除事务自有材质。真实 Editor 的单样例完整回退仍是正式迁移前必要验证。

