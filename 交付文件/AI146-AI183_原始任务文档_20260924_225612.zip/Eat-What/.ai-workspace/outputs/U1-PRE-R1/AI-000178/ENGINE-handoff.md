# AI-000178 → ENGINE 只读验收接力

## 结论与边界

CODE 已通过真实 Unity 6000.3.24f1/TMP DLL 编译和编辑器外回归，但没有启动 Unity Editor，也没有用离线夹具代签真实 `SerializedProperty` 跨加载稳定性。AI170 仍保持暂停；只有控制台审核并正式恢复后，ENGINE 才执行以下步骤。

## 精确只读步骤

1. 在 `D:/GameProject/Eat-What` 确认目标实例为 Unity `6000.3.24f1`，保存用户工作后关闭 `ShortCycle_P0P1.unity` 与 `FridgeScrollLab.unity`，使两批准场景均不处于 loaded 状态。不得修改或保存任何场景、Prefab、材质、字体、meta。
2. 生成全新 attempt-4 计划，不能复用 attempt-3/schema4：

   ```powershell
   & 'C:/Program Files/Unity/Hub/Editor/6000.3.24f1/Editor/Unity.exe' `
     -batchmode -quit -projectPath 'D:/GameProject/Eat-What' `
     -executeMethod EatWhat.EditorTools.Fonts.ShortCycleFontSwapTool.PreviewApprovedBatch `
     -fontMapping '.ai-workspace/outputs/control/U1-PRE-20260923/PRE1_字体材质迁移逐项草案.csv' `
     -fontApprovalEvidence '.ai-workspace/inputs/U1-PRE_人工反馈与字体批准_20260923.md' `
     -fontSupplementalMapping '.ai-workspace/outputs/control/U1-PRE-R1-20260923/PRE1_Lab60_增量迁移草案.csv' `
     -fontSupplementalApprovalEvidence '.ai-workspace/inputs/U1-PRE_Lab60_增量批准与接力_20260924.md' `
     -fontPlan '.ai-workspace/outputs/U1-PRE-R1/AI-000170/attempt-4-fingerprint-r1/approved-plan.json' `
     -logFile '.ai-workspace/outputs/U1-PRE-R1/AI-000170/attempt-4-fingerprint-r1/preview.log'
   ```

3. 核验新计划 `schemaVersion=5`、`nonTargetFingerprintVersion=2`、`rawEntryCount=231`、`rows=231`、批准资产7、`uniqueEntryCount=201`（若真实值变化须解释）、`executeAllowed=true`、`reasons=[]`、三个材质计划均 ready。
4. 在批准场景仍关闭时执行公开只读双轮诊断；该入口会对五个Prefab连续执行两次独立加载/卸载，并对两个场景执行打开→关闭→再次打开→关闭：

   ```powershell
   & 'C:/Program Files/Unity/Hub/Editor/6000.3.24f1/Editor/Unity.exe' `
     -batchmode -quit -projectPath 'D:/GameProject/Eat-What' `
     -executeMethod EatWhat.EditorTools.Fonts.ShortCycleFontSwapTool.DiagnoseApprovedFingerprintsBatch `
     -fontPlan '.ai-workspace/outputs/U1-PRE-R1/AI-000170/attempt-4-fingerprint-r1/approved-plan.json' `
     -fontFingerprintDiagnostic '.ai-workspace/outputs/U1-PRE-R1/AI-000170/attempt-4-fingerprint-r1/fingerprint-diagnostic.json' `
     -logFile '.ai-workspace/outputs/U1-PRE-R1/AI-000170/attempt-4-fingerprint-r1/fingerprint-diagnostic.log'
   ```

5. 诊断必须为：`success=true`、`rowCount=231`、`approvedAssetCount=7`、`stableAcrossReloads=true`、`referencesValid=true`、`unstableRowCount=0`，两轮各231行；所有记录到的对象引用身份必须为 `NULL`、`PERSISTENT`、`LOCAL_GAME_OBJECT` 或 `LOCAL_COMPONENT`，不得为空，不得含 instanceID，不得包含 `m_fontAsset`/`m_sharedMaterial`。
6. 复核两个CSV、两场景和五Prefab SHA/磁盘差异均未因只读步骤变化，新 Console Error/Exception 为0。若任一未解析引用、场景未关闭、跨重载漂移或磁盘变化，立即停止并按原问题保留证据，不得改计划、反射 private、伪造 `executeAllowed` 或跳过检查。
7. 上述只读验收通过后，才按 AI170 既有卡执行 `BeginApprovedMigration`、单 FromSourceHan TMP 写入与完整回退、全量显式分批和既有 Play/Build/人工字体构图验收。新 schema5 事务必须使用新路径；旧 schema1～4 计划/非终态事务不续跑。

## CODE 证据

- [verification-summary.json](verification-summary.json)
- [source-diff-evidence.json](source-diff-evidence.json)
- Fonts Final 历史：`.ai-workspace/runtime/verify-all/verify-all-AI-000178.jsonl`

