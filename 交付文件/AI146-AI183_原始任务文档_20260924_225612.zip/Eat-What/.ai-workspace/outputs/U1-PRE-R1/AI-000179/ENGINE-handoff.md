# AI-000179 → ENGINE 真实只读验收接力

## 结论与边界

CODE 已通过真实 Unity 6000.3.24f1/TMP DLL 编译及编辑器外回归，没有启动或控制 Unity，也未修改任何序列化资源。AI170 仍保持暂停；只有控制台审核AI179并正式恢复后，ENGINE才能执行attempt5。

## 精确执行要求

1. 复用当前主Editor和仓库内固定MCP，不在已打开的 `D:/GameProject/Eat-What` 上启动batchmode，不停止共享Editor/MCP。每次操作前重新发现/选择实例，核对 `Application.dataPath`、Unity `6000.3.24f1`、Edit/Play/Compile、全部loaded场景及dirty状态。
2. 记录当前加载布局、活动场景与恢复点。仅当 `ShortCycle_P0P1.unity` 和 `FridgeScrollLab.unity` 均clean、且无未知用户未保存成果时，才由Editor API按任务归属暂关；必要时使用任务自有空场景，并在 `try/finally` 恢复原布局。不得保存未知dirty、不得用MarkSceneClean掩盖变化。
3. 用公开 `PreviewApprovedMigration(baseMapping, baseEvidence, supplementalMapping, supplementalEvidence, planPath)` 生成 `attempt-5-prefab-reference-r1/approved-plan.json`。不得复用或手改attempt1～4/schema1～5计划。要求 `schemaVersion=6`、`nonTargetFingerprintVersion=3`、`rawEntryCount=231`、`rows=231`、批准资产7、`executeAllowed=true`、`reasons=[]`；真实unique由Editor给出，不硬填201。
4. 场景保持关闭时调用公开 `DiagnoseApprovedNonTargetFingerprints(planPath, diagnosticPath)`。要求 `success=true`、`rowCount=231`、`approvedAssetCount=7`、`stableAcrossReloads=true`、`referencesValid=true`、`unstableRowCount=0`，两轮各231行。引用身份允许 `NULL`、`PERSISTENT`、`LOCAL_GAME_OBJECT`、`LOCAL_COMPONENT`、`UNITY_INTERNAL_PREFAB_INSTANCE`；均不得为空或含instanceID，且不得包含两个目标字段。
5. 特别核对 `UNITY_INTERNAL_PREFAB_INSTANCE`：引用和owner为type 2、同保存资产GUID，引用targetObjectId等于owner targetPrefabId，引用targetPrefabId为0；不同Prefab实例保持不同身份。`m_CorrespondingSourceObject`、`m_PrefabAsset`若为正常persistent引用走严格持久身份；未知内部类型仍须拒绝，不能降级成null或跳过字段。
6. 只读诊断后复核两CSV、两场景、五Prefab及meta未变，Console无新增Error/Exception，并恢复原场景布局。任一身份未解析、跨重载漂移、归属不符或磁盘变化均停止并保留证据，不得反射private、改CSV/计划、伪造 `executeAllowed` 或跳过检查。
7. 只读验收通过后，才按AI170卡执行公开 `BeginApprovedMigration`、单FromSourceHan样例完整回退、独立全量事务显式分批和既有Play/Build/人工验收。新计划、样例事务、全量事务和报告均落 `attempt-5-prefab-reference-r1`；旧目录不覆盖。

## CODE 证据

- `verification-summary.json`
- `source-diff-evidence.json`
- Fonts Final历史：`.ai-workspace/runtime/verify-all/verify-all-AI-000179.jsonl`
