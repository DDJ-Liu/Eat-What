# AI-000182 PRE-1c-TRANSACTION-CONTRACT-R1 完成报告

## 结论

- TaskId / 状态 / 验证状态：`AI-000182` / 预期 `SUCCEEDED` / `VERIFIED`
- 一句话结果：修复字体短周期迁移的诊断计划比对与分阶段事务快照契约，新增确定性回归覆盖；唯一一次 Fonts Final 验证 2/2 通过，生产写入为 0。

## 六要素

- 做了什么：
  - 诊断改为使用与 Preview/执行计划一致的材质解析观察值，并逐行校验诊断结果与计划；两次稳定但共同错误的结果不再被接受。
  - 事务 schema 升至 9、备份清单升至 7；将不可变原始基线与每批次阶段快照分离，在写入前持久化 `APPLYING` 批次、选择集和允许写入路径。
  - Apply 仅接受当前批次声明路径的变化；Rollback 先验证稳定阶段或可证明的 `APPLYING` 部分阶段、所有权和 14 项备份内容，再执行逐字节恢复，拒绝未拥有的漂移及旧 schema。
  - 新增 40 条场景原因、8 条来源原因、183 条普通行、同文件分批写入/回滚、meta/外部漂移和 14 项备份篡改等回归断言。
- 产物路径：
  - `Assets/Editor/Fonts/ShortCycleFontSwapTool.cs`
  - `DevTools/Fonts/FontSwapDryRunHarness.cs`
  - `DevTools/Fonts/Test-FontSwap.ps1`
  - `DevTools/Fonts/README.md`
  - `.ai-workspace/toolkit/LOC.md`
  - `CODEBASE_MAP.md`
  - `项目整体阅读理解与推进基线_2026-08-14.md`
  - 本报告：`.ai-workspace/outputs/U1-PRE-R1/AI-000182/AI-000182_PRE-1c-TRANSACTION-CONTRACT-R1_完成报告.md`
- 实际验证：
  - 窄范围 `DevTools/Fonts/Test-FontSwap.ps1`：通过；以 Unity `6000.3.24f1` / TMP 程序集完成源码编译，新增 5 个事务/诊断守卫均为 true，`productionWrites=0`。
  - 唯一一次 `DevTools/Verify-All.ps1 -TaskId AI-000182 -Profile Fonts -Mode Final`：`VERIFY_ALL_PASSED`，runner 2/2 通过；`Test-ShortCycleFonts.ps1` 为 36 个静态断言、27 个守卫用例通过，编译产物 191488 bytes；`Test-FontSwap.ps1` 通过。
  - Final 历史：`.ai-workspace/runtime/verify-all/verify-all-AI-000182.jsonl`，记录时间 `2026-09-24T13:31:00+08:00`。
  - 14/14 个批准生产 asset/meta 的 SHA-256 与冻结基线一致；三个目标材质均不存在；事务文件 `.ai-workspace/runtime/font-migration/transaction.json` 与备份目录 `DevTools/Fonts/backup/AI-000182` 均不存在。
  - 关键源码 SHA-256：`ShortCycleFontSwapTool.cs=379CFBC96E617309F0020C79173055122153B96F9E855C0529AA361804EA4A40`；`FontSwapDryRunHarness.cs=FD1763BB0647A85A38C9736947059F3B509D939E163B05D3159FADA7BA654456`；`Test-FontSwap.ps1=69AD9F54729C2E99A317BACC977221E2AF083E3333B87DAE5F5ABBD824613877`。
- 待人工项：本 CODE 任务无新增人工项。真实 Editor 保存生命周期、样本回滚及 schema 9 公共 Preview/诊断仍由控制台在 AI-000170 后续人工/Editor 阶段处理；本任务未运行 Unity，也未将其宣称为已通过。
- 文档影响：更新 `DevTools/Fonts/README.md`、`.ai-workspace/toolkit/LOC.md`、`CODEBASE_MAP.md` 和 `项目整体阅读理解与推进基线_2026-08-14.md`，说明 schema 9 阶段快照、诊断计划比对、回滚证据及验证边界。
- 工具登记影响：扩充 `TK-LOC-03`，登记新的诊断计划一致性和事务阶段/备份验证能力；未新增平行工具。

## 影响与异常

- 影响块：字体短周期迁移工具、PRE-1c 事务契约、诊断/Preview 一致性、分批共享文件写入、备份与回退边界。公共入口名称保持不变；schema 1–8 的旧事务不再允许由当前公共执行/回滚路径继续处理，按 fail-closed 原则重新 Preview。
- 异常：0。任务卡所述“静态 phase SHA 复用”是契约缺陷，不是本轮观察到的生产回滚失败；本轮没有生产资产、材质、事务或备份残留。
- 使用量：`.ai-workspace/runtime/usage-202609.jsonl`；provider input/output/model=`null`（当前执行环境未暴露这些字段），队列/工具侧使用记录按运行时可用字段留存。
