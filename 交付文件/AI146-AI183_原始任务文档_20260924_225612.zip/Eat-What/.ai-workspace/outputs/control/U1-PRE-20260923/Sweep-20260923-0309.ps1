$ErrorActionPreference = 'Stop'
if ($PSVersionTable.PSEdition -ne 'Core') { throw 'PowerShell 7 required.' }
$s = (& '.ai-workspace/queue.ps1' -Action SupervisionStatus | Out-String) | ConvertFrom-Json
$r = $null
$d = $null
if ($s.disposition -eq 'ACTIVE') {
    $r = (& '.ai-workspace/queue.ps1' -Action ReconcileSupervision -IdlePipelines @() -Verification '2026-09-23 03:09 heartbeat: wait_threads timeoutMs=0 verifies CODE and ENGINE_MCP both active/inProgress. No idle scope lanes. Preserve active tasks; observation file sweep-20260923-0309-workers.json.' | Out-String) | ConvertFrom-Json
    $d = (& '.ai-workspace/queue.ps1' -Action DispatchSupervision -IdlePipelines @() | Out-String) | ConvertFrom-Json
}
$receipt = [pscustomobject]@{ at=(Get-Date -Format o); status=$s; reconcile=$r; dispatch=$d }
$receipt | ConvertTo-Json -Depth 30 | Set-Content -LiteralPath (Join-Path $PSScriptRoot 'sweep-20260923-0309.json') -Encoding utf8
$snapshot = if ($null -ne $d.snapshot) { $d.snapshot } else { $s }
[pscustomobject]@{ disposition=$snapshot.disposition; tasks=@($snapshot.tasks | Select-Object taskId,status,blockers); ready=$snapshot.readyTaskIds; recoveryReady=$snapshot.recoveryReadyTaskIds; handoffGaps=$snapshot.handoffGaps; dispatches=$d.dispatches; automationDirective=$snapshot.automationDirective } | ConvertTo-Json -Depth 8
