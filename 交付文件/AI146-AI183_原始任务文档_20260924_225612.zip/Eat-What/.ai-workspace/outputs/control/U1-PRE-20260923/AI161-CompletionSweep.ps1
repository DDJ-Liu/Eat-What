$ErrorActionPreference='Stop'
$s=(& '.ai-workspace/queue.ps1' -Action SupervisionStatus | Out-String) | ConvertFrom-Json
if($s.disposition -ne 'ACTIVE'){throw 'Supervision is not active.'}
$r=(& '.ai-workspace/queue.ps1' -Action ReconcileSupervision -IdlePipelines @('CODE','ENGINE_MCP') -Verification '2026-09-23 AI161 completion: wait_threads confirms CODE turn 01a0cabb-4aed-7d60-b284-b27154f4d5a7 completed/idle, separate snapshot confirms ENGINE turn 01a0ca76-dd25-70d3-89a1-77cabe3e52d9 idle. AI161 report/code tool docs reviewed: real Unity6 DLL compile and guard fixtures passed; no Unity asset creation claimed.' | Out-String) | ConvertFrom-Json
$d=(& '.ai-workspace/queue.ps1' -Action DispatchSupervision -IdlePipelines @('CODE','ENGINE_MCP') | Out-String) | ConvertFrom-Json
[pscustomobject]@{at=(Get-Date -Format o);status=$s;reconcile=$r;dispatch=$d} | ConvertTo-Json -Depth 32 | Set-Content -LiteralPath (Join-Path $PSScriptRoot 'AI161-completion-sweep.json') -Encoding utf8
[pscustomobject]@{disposition=$d.snapshot.disposition;dispatches=$d.dispatches;recoveryReady=$d.snapshot.recoveryReadyTaskIds;handoffGaps=$d.snapshot.handoffGaps} | ConvertTo-Json -Depth 8
