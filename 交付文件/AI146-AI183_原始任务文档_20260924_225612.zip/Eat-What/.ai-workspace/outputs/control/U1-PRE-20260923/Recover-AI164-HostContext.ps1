$ErrorActionPreference = 'Stop'
Set-Location -LiteralPath 'D:/GameProject/Eat-What'
$out = $PSScriptRoot
$mode = Get-Content '.ai-workspace/runtime/mode-state.json' -Raw | ConvertFrom-Json
if ($mode.mode -ne 'SUPERVISED' -or $mode.supervised.status -ne 'ACTIVE' -or $mode.supervised.stopRequested -or $mode.supervised.sessionId -ne 'dec23c073f8f411a8ac6c6e898828ac7') { throw 'Session changed; do not recover.' }
$task = (Get-Content '.ai-workspace/runtime/queue-state.json' -Raw | ConvertFrom-Json).tasks | Where-Object id -eq 'AI-000164'
if ($task.status -ne 'PAUSED_CIRCUIT' -or $task.supervisionProblemKey -ne 'batch_host_license_ipc_initialization_failed' -or @($task.supervisionRepairs).Count -ne 2) { throw 'Failure or recovery history changed; inspect first.' }
$restricted = Get-Content (Join-Path $out 'heartbeat-1829-knownfolder-sandbox.json') -Raw | ConvertFrom-Json
$hostProbe = Get-Content (Join-Path $out 'heartbeat-1829-knownfolder-host.json') -Raw | ConvertFrom-Json
if ($restricted.localLow.hresult -ne '0x80070002' -or $hostProbe.localLow.hresult -ne '0x00000000' -or -not $hostProbe.localLow.exists) { throw 'Expected comparative host evidence is missing.' }
if (Get-Process -Id 141152 -ErrorAction SilentlyContinue) { throw 'Previous owned batch still exists.' }
$lockPath = Join-Path (Get-Location) '.ai-workspace/runtime/data-publication.lock'
$handle = [IO.File]::Open($lockPath,[IO.FileMode]::OpenOrCreate,[IO.FileAccess]::ReadWrite,[IO.FileShare]::None)
$handle.Dispose()
$observed = [ordered]@{at=(Get-Date).ToString('o');CODE=@{state='idle';turn='01a0cb40-26b6-7c22-8b3c-26093eb93e73';cursor='a1d9a005-78ec-45ed-9398-0a8d58675b89:2'};ENGINE_MCP=@{state='idle';turn='01a0cb20-f106-7780-9139-e32c9a0c007a';cursor='9676865a-b588-4faa-a3c5-3e68be3b75b3:2'};DATA=@{state='completed';agent='/root/data_ai164_resume';receipt='AI-000164/user-retry-20260923/fail-receipt.json'};priorBatchAbsent=$true;publicationLockAvailable=$true}
$observed | ConvertTo-Json -Depth 5 | Set-Content (Join-Path $out 'heartbeat-1829-workers.json') -Encoding utf8NoBOM
$evidence = '18:29 heartbeat actual wait_threads CODE/ENGINE idle and DATA child completed. Previous owned batch141152 absent; publication lock can open exclusively. User retry main MCP healthy; 5722 production files unchanged. At18:34:05 restricted host SHGetKnownFolderPath(LocalLow) failed 0x80070002; at18:34:24 the SAME read-only probe via supported require_escalated succeeded 0x00000000 at C:/Users/DDJ/AppData/LocalLow. This proves host visibility differs, not that Unity batch is already fixed. No platform denial occurred. Read-only probe permission does not authorize a later launch automatically; executor must request supported launch escalation separately.'
$reconcile = & .ai-workspace/queue.ps1 -Action ReconcileSupervision -IdlePipelines @('CODE','ENGINE_MCP','DATA') -Verification $evidence
$reconcile | Set-Content (Join-Path $out 'heartbeat-1829-reconcile.json') -Encoding utf8NoBOM
$plan = 'Use the supported exec_command require_escalated approval path for the exact guarded PS7 CurrentCsvValidation batch command, running under normal host context instead of the restricted process context which empirically cannot resolve LocalLow. Keep the existing AI166 runner, isolated fresh workspace, current run nonce, owned process wait and full publication lock; no source code or security/licensing configuration changes. Preserve working main Editor/current scene, do not operate stale Terms window, no Publish or USER-U1 DONE. New output host-context-recovery-20260923; never overwrite prior attempts. If actual launch permission is denied, preserve the refusal and stop with HUMAN scope, no alternate bypass. If same licensing fault survives approved host launch, preserve stable ProblemKey and stop rather than repeating without new evidence.'
$recovery = & .ai-workspace/queue.ps1 -Action RecoverSupervisionTask -TaskId AI-000164 -IdlePipelines DATA -RepairPlan $plan -Verification $evidence
$recovery | Set-Content (Join-Path $out 'heartbeat-1829-recovery.json') -Encoding utf8NoBOM
$r = $recovery | ConvertFrom-Json
$after = (Get-Content '.ai-workspace/runtime/queue-state.json' -Raw | ConvertFrom-Json).tasks | Where-Object id -eq 'AI-000164'
if ($after.status -ne 'QUEUED') { $recovery; throw 'Recovery did not queue the task; do not dispatch.' }
$dispatch = & .ai-workspace/queue.ps1 -Action DispatchSupervision -IdlePipelines @('CODE','ENGINE_MCP','DATA')
$dispatch | Set-Content (Join-Path $out 'heartbeat-1829-dispatch.json') -Encoding utf8NoBOM
$dispatch
