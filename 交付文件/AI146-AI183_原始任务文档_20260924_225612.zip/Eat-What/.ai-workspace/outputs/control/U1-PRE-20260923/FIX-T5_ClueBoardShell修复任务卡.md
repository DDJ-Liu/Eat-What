# FIX-T5 · ④左页保留压暗与返回行为补漏

控制端于2026-09-23依据已批准G69安排必要修复；不重跑或重置AI156。原证据：AI156报告、04_ClueBoardShell.png（控制端已查看）和源码ShortCycleSpace.WantsActive。截图右半为背景，Browse Set被禁用；这是“左半页保留并压暗”的未达项，不能只留作偏好判断。原机位/命中/Pan验证与PENDING_USER记录保留。

必读：CORE.md、workers/ENGINE_MCP.md、SUPERVISED及完整协议相关节；项目入口页首/ShortCycle模块；inputs/控制台输入_FIX-T5空间结构修复派发_20260923.md G69/§3；inputs/U1-PRE_执行边界与接力_20260923.md；TK-INT-03、TK-MOT-06、TK-DBG-04、G26/UNITY_SCENE_CLEANUP。

目标只有一个：①→④→①符合G69：保留并压暗屏内书左页，书页不可交互；线索板正常展开，Escape和线索板外真实点击均可返回；无额外Pan，无点击穿透。

先发现MCP并核对D:/GameProject/Eat-What与6000.3.24f1，记录保存点、hash和现场。读取实际viewTable/structureSets、Book_Base/Pages/Browse Set、渲染可见/交互门控/退出动作链；不能根据截图直接决定参数。优先复用现有表现/遮罩和状态门控能力修正配置，分开可见性与交互权限，不能为压暗把书页隐藏，也不能用禁用整个对象替代禁止交互。

精确授权：仅通过Unity Editor/MCP改Assets/Scenes/Cooking/ShortCycle_P0P1.unity内Phase0_RecipeBook的④显示配置、相关共享Set登记/既有颜色遮罩字段，以及无视觉的外围关闭命中接线；必要的临时探针按G26登记并清理。先备份场景/meta到DevTools/Scenes/backup/<TaskId>/，记录拟改对象路径与字段/前后值。保持四Marker世界x、线索板锚点/板面、字体与TMP/材质override、全部已有业务/Modal、已验收滚轮和资产GUID；不修改Prefab源、不手写YAML、不改运行时.cs、不添加新Shader/RendererFeature。若实际实现缺少所需代码或视效能力，给最小代码清单/根因与安全现场，由控制端补CODE依赖；不能静默放弃必需效果并宣告成功。若必须新建视效组件，遵守统一VisualEffectsLab先验规则。

机器验收：同相机同配置对照①/④截图与hash、书页Renderer仍可见且变暗的明确证据；④书页点击无动作，线索板内容正常；板外点击返回一次、同次点击不穿透到Browse控件，Esc同理；①↔④ PanStarted增量0；完整Cover/Catalog/Browse/Kitchen返回路径回归；Console新增错误0，最终Edit/clean、临时资产恢复。真实人工构图/暗度审查后置，Complete须PENDING_USER，不代签。

每批写入前SupervisionCheckpoint，使用当前PowerShell7票据；真实平台拒绝按原文留证，不换通道绕过。场景临时脏变化按归属自主恢复；报告六要素加证据路径，不回大层级/图片base64。不提交推送，完成回传控制台。
