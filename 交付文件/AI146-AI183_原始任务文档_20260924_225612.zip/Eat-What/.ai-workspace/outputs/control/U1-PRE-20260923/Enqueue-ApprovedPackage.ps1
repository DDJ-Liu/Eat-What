$ErrorActionPreference='Stop'
$plan=Get-Content -Raw -Encoding UTF8 (Join-Path $PSScriptRoot 'task-plan.json')|ConvertFrom-Json
$receipt=Join-Path $PSScriptRoot 'task-map.json'
if(Test-Path -LiteralPath $receipt){throw 'Package already enqueued: inspect task-map.json; do not rerun.'}
$map=[ordered]@{}
foreach($card in $plan.tasks){
    $deps=@($card.deps | ForEach-Object {if($_ -like 'AI-*'){$_}elseif($map.Contains($_)){$map[$_]}else{throw "Unresolved dependency $_"}})
    $result=(& '.ai-workspace/queue.ps1' -Action Enqueue -Pipeline $card.lane -ModuleId $card.module -Title $card.title -Instruction $card.instruction -DependsOn $deps -AllowBypass | Out-String)|ConvertFrom-Json
    $map[$card.key]=$result.task.id
    $map|ConvertTo-Json|Set-Content -LiteralPath $receipt -Encoding utf8
    $policy=(& '.ai-workspace/queue.ps1' -Action ConfigureSupervisionTask -TaskId $result.task.id -ResourceKeys @($card.resources) -Reason 'PRE包明确允许独立DevTools与只读Unity并行；Assets源码与Editor操作保留unity-project，共享工作流文件串行。'|Out-String)|ConvertFrom-Json
    [pscustomobject]@{id=$result.task.id;key=$card.key;pipeline=$card.lane;dependsOn=$deps;policy=$policy.action}
}
$queue=Get-Content -Raw -Encoding UTF8 '.ai-workspace/runtime/queue-state.json'|ConvertFrom-Json
$t=$queue.tasks|Where-Object id -eq 'AI-000156'
$extra=@'

2026-09-23 PRE包执行覆盖（当前用户明确恢复监管）：必读 .ai-workspace/inputs/U1-PRE_执行边界与接力_20260923.md。AI154已经SUCCEEDED/PENDING_USER；领取基线包括用户明确接受的140条m_TextWrappingMode和30条原材质override，旧指令要求清除150条不意味着再清理这140条。不能修改Prefab源或手改YAML。指导书v0.3有意未出，不阻塞本任务；使用稳定v0.2+已审G68/G69增量，报告必须追加实际世界坐标/Renderer bounds/四Marker/ClueBoard两anchor/滚轮区域坐标表、截图路径与SHA，供设计端重算指导书§三。PRE-4只读诊断结论可供避坑，不实施其额外业务修复。MCP遍历/日志输出文件，返回计数/路径/前20异常；限定Hierarchy路径/深度，截图不内联；批量平移/接线先脚本再一次执行；Play轮询间隔>=2秒、每阶段上限30次。六要素报告只给结果/证据路径，不复述任务卡。F-α已成功任务不重跑，AI149/154人工结果不代签。本任务完成仍PENDING_USER。
'@
$updated=(& '.ai-workspace/queue.ps1' -Action ReviseInstruction -TaskId 'AI-000156' -Instruction ($t.instruction+$extra)|Out-String)|ConvertFrom-Json
$deps=(& '.ai-workspace/queue.ps1' -Action UpdateDependencies -TaskId 'AI-000156' -DependsOn @('AI-000155','AI-000154',$map.pre5,$map.pre4)|Out-String)|ConvertFrom-Json
[pscustomobject]@{id='AI-000156';revision=$updated.action;dependencyUpdate=$deps.action}
