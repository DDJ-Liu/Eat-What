$ErrorActionPreference='Stop'
$r=(& '.ai-workspace/queue.ps1' -Action ReconcileSupervision -IdlePipelines @('CODE') -Verification 'Current heartbeat wait_threads: CODE idle/completed, ENGINE AI165 active/inProgress. Evidence heartbeat-2214-workers.json. Only CODE supplied as observed idle. AI164 blocked by AI166; no recovery until repair succeeds.'|Out-String)|ConvertFrom-Json
$d=(& '.ai-workspace/queue.ps1' -Action DispatchSupervision -IdlePipelines @('CODE')|Out-String)|ConvertFrom-Json
[pscustomobject]@{at=(Get-Date -Format o);reconcile=$r;dispatch=$d}|ConvertTo-Json -Depth 32|Set-Content -LiteralPath (Join-Path $PSScriptRoot 'heartbeat-2214-sweep.json') -Encoding utf8
[pscustomobject]@{disposition=$d.snapshot.disposition;ready=$d.snapshot.readyTaskIds;recoveryReady=$d.snapshot.recoveryReadyTaskIds;handoffGaps=$d.snapshot.handoffGaps;dispatches=$d.dispatches}|ConvertTo-Json -Depth 8
