$ErrorActionPreference='Stop'
$r=(& '.ai-workspace/queue.ps1' -Action ReconcileSupervision -IdlePipelines @('ENGINE_MCP') -Verification 'Current heartbeat wait_threads confirms CODE AI166 active/inProgress and ENGINE completed/idle. Only observed idle ENGINE supplied. AI164 remains dependent on166 and has no new recovery evidence. See heartbeat-2248-workers.json.'|Out-String)|ConvertFrom-Json
$d=(& '.ai-workspace/queue.ps1' -Action DispatchSupervision -IdlePipelines @('ENGINE_MCP')|Out-String)|ConvertFrom-Json
[pscustomobject]@{at=(Get-Date -Format o);reconcile=$r;dispatch=$d}|ConvertTo-Json -Depth 32|Set-Content (Join-Path $PSScriptRoot 'heartbeat-2248-sweep.json') -Encoding utf8
[pscustomobject]@{disposition=$d.snapshot.disposition;ready=$d.snapshot.readyTaskIds;recoveryReady=$d.snapshot.recoveryReadyTaskIds;handoffGaps=$d.snapshot.handoffGaps;dispatches=$d.dispatches}|ConvertTo-Json -Depth 8
