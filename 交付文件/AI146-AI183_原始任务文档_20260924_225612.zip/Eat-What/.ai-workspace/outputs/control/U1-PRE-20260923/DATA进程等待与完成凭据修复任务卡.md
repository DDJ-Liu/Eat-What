# PRE-2b 修复：真实进程生命周期与完成凭据

## 代码改动清单

| 文件 | 处置 | 要点 | 归属层 | 工具层三问 |
| --- | --- | --- | --- | --- |
| DevTools/DataTables/DataPipeline.Common.ps1 | 修改 | 显式等待本次GUI进程、真实退出码、进程归属与锁持有期；输入快照范围与实际副本一致 | 工作流工具 | 复用 TK-WF-02，不建平行运行器；通用DATA执行职责；登记原接口变化 |
| DevTools/DataTables/Run-DataPipeline.ps1 | 修改 | 当前run完成凭据校验、未运行/失败不记0或API已执行、原始报告留存、超时停止语义 | 工作流工具 | 复用 TK-WF-02；复用原门禁/资源/发布事务 |
| Assets/Editor/DataTables/DataTableImportService.cs | 必要时扩充 | 为既有 ImportAllBatch 输出可核验的本次导表+字体完成凭据，复用项目CSV解析输出字形需求 | Editor导表 | 复用 TK-DAT-01；不增新业务导表器 |
| DevTools/DataTables/Test-BatchImport.ps1、StaticCompile/UnityStubs.cs、Test-CK01BImportContracts.ps1 | 按需扩充 | 真实Windows GUI子进程等待/非零/缺凭据/锁持续与失败结果测试，保留既有回归 | 测试工具 | 复用 TK-WF-02/TK-DAT-01；fixture只写临时目录 |
| DevTools/DataTables/DATA_PIPELINE.md、CODEBASE_MAP.md、项目整体阅读理解与推进基线_2026-08-14.md、.ai-workspace/toolkit/WF.md、.ai-workspace/toolkit/DAT.md | 修改相关节 | 真实运行边界、输入快照、失败分类与恢复条件 | 文档 | 原入口更新，不另建平行规则 |

此为用户已授权 U1 PRE-2b 监管范围内必要修复，由控制台落实精确源码范围；不代签人工验收、不扩大字体材质审批，不重跑/重置已成功AI163。

## 根因与唯一目标

AI164真实首跑发现 Invoke-DataBatchCommand 直接 & GUI Unity.exe 后把预设LASTEXITCODE=0当成功；隔离进程仍活着就释放锁，复制来的catalog/零diff被当作真实验证。原错误和未可信runner报告保留。目标是让DATA运行器只在本次实际batch已结束并证明导表+字体完成后报告成功，全程保持锁。

必读：.ai-workspace/CORE.md；.ai-workspace/workers/CODE.md；.ai-workspace/SUPERVISED.md 与 protocol/SUPERVISED_FULL.md 恢复/控制台委托节；.ai-workspace/inputs/U1-PRE_执行边界与接力_20260923.md；.ai-workspace/outputs/U1-PRE/AI-000164/AI-000164_PRE-2b_首跑阻断与修复接力.md 及其原始证据；DevTools/DataTables/DATA_PIPELINE.md；两项目文档页首/数据专项；TK-WF-02、TK-DAT-01；.ai-workspace/ENGINEERING_CONVENTIONS.md C1～C4（保持既有Editor/运行时边界）。

## 实现与验收

1. 使用本次创建的明确Process句柄，隐藏窗口，等待真实退出并取该句柄ExitCode；不从默认LASTEXITCODE或已有catalog推定成功。锁从输入快照前持有到进程退出和校验完成。超时/取消/异常需可诊断，不能留下进程仍运行而释放锁；只能清理有PID/StartTime/exe/projectPath归属证据的本次测试进程，不能动用户Editor或许可服务。
2. 成功须实际exit0 + 本次run唯一且新鲜的完成凭据 + 实际字体构建结果；失败/尚未运行的真实退出码保持null，脚本自己的退出码另列。缺标记、旧标记、假0均失败；不能在未调用时写API已执行。若原有新日志标记已足够，优先小改；需要结构化凭据则在唯一批入口补齐，不新建运行器。
3. 新增真实 Windows GUI 延迟退出非零的离线子进程测试，另验证成功、缺凭据、锁在子进程运行期间不可再次独占，退出后正确释放。不用立即返回脚本fixture替代GUI路径。测试仅临时隔离fixture，不启动真实Unity，不生产故障注入。
4. 输入摘要对齐实际复制完整Assets等范围（或有证据的完整最小依赖闭包），不能文档宣称只复制Importer却实际全Assets。核对Fonts Builder依赖/manifest输入是否存在于隔离副本；不复制活动Library、不更改GUID。照保守资源声明持有unity-project。
5. 字形报告239对238差异须核对项目CSV解析语义（头/说明行、转义/换行、Unicode码点），统一可解释的实际输出，不强凑数量、不以脚本Import-Csv计数假称Builder事实。
6. 维持CurrentCsvValidation禁止Publish/不写USER-U1 DONE；字体材质审批未获回复，不触碰场景、Prefab、生产字体或生成资产；不修改任何Unity序列化资源，不手写YAML。Unity许可连接拒绝是原始运行时证据，保留供DATA重验；不得改许可/系统设置或换通道绕过限制。
7. 跑有意义的窄回归及一次DataTables收口验证；对GUI等待缺陷有真实失败再通过的证据，保留45事务/36DATA语义。报告仍注明真实Unity首跑未完成，由原AI164在修复成功后恢复，不能由CODE执行真实Unity。
8. PowerShell7正常权限，不使用ExecutionPolicy Bypass；每批写入前SupervisionCheckpoint，按需续租。报告六要素+文档/工具影响，证据 .ai-workspace/outputs/U1-PRE/<TaskId>/，不可得provider用量null。不提交推送。
