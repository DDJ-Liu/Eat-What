$ErrorActionPreference='Stop'
$s=(& '.ai-workspace/queue.ps1' -Action SupervisionStatus | Out-String) | ConvertFrom-Json
if($s.disposition -ne 'ACTIVE'){ $s | ConvertTo-Json -Depth 20; return }
$r=(& '.ai-workspace/queue.ps1' -Action ReconcileSupervision -IdlePipelines @('CODE') -Verification 'AI159 completion callback: wait_threads verifies CODE turn 01a0ca76-eab8-7c03-a76b-3aa88c45e9b0 completed (1790104603), idle. Separate ENGINE snapshot confirms turn 01a0ca76-dd25-70d3-89a1-77cabe3e52d9 active. Reviewed PRE3 completion/verification-summary: PASS; no reset or ENGINE reconciliation.' | Out-String) | ConvertFrom-Json
$d=(& '.ai-workspace/queue.ps1' -Action DispatchSupervision -IdlePipelines @('CODE') | Out-String) | ConvertFrom-Json
[pscustomobject]@{at=(Get-Date -Format o);status=$s;reconcile=$r;dispatch=$d} | ConvertTo-Json -Depth 30 | Set-Content -Encoding utf8 (Join-Path $PSScriptRoot 'AI159-completion-sweep.json')
[pscustomobject]@{disposition=$d.snapshot.disposition;tasks=@($d.snapshot.tasks | Select-Object taskId,status);recoveryReady=$d.snapshot.recoveryReadyTaskIds;handoffGaps=$d.snapshot.handoffGaps;dispatches=$d.dispatches} | ConvertTo-Json -Depth 8
