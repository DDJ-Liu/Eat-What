$ErrorActionPreference='Stop'
if ($PSVersionTable.PSEdition -ne 'Core') { throw 'PowerShell 7 required.' }
$state=Get-Content -LiteralPath '.ai-workspace/runtime/mode-state.json' -Raw | ConvertFrom-Json
if($state.mode -ne 'SUPERVISED' -or $state.supervised.status -ne 'ACTIVE' -or $state.supervised.stopRequested){throw 'Supervision is not active.'}
$q=Get-Content -LiteralPath '.ai-workspace/runtime/queue-state.json' -Raw | ConvertFrom-Json
$pre=$q.tasks | Where-Object id -eq 'AI-000160'
if($pre.status -ne 'SUCCEEDED'){throw 'AI160 has not completed.'}
$results=[ordered]@{at=(Get-Date -Format o)}
$results.register=(& '.ai-workspace/queue.ps1' -Action RegisterDataLane | Out-String) | ConvertFrom-Json
$data=$q.tasks | Where-Object id -eq 'AI-000164'
if($data.pipeline -ne 'DATA'){$results.reclassify=(& '.ai-workspace/queue.ps1' -Action ReclassifyTask -TaskId AI-000164 -Pipeline DATA | Out-String) | ConvertFrom-Json}
$note='.ai-workspace/outputs/control/U1-PRE-20260923/DATA接力审查与首跑前修正.md'
foreach($id in @('AI-000163','AI-000164')){
    $task=$q.tasks | Where-Object id -eq $id
    $add=if($id -eq 'AI-000163'){'2026-09-23 控制端首跑前源码审查补充（原任务范围内必要修复）：必读 '+$note+'；把事务回退保护、源/目标漂移校验、无用户轮次的隔离验证模式、Unity版本与隔离目录/资源锁一致性一并纳入原Run-DataPipeline及Common/tests改动，先修复再交付给DATA，不运行生产发布。AI160成功历史保留。'}else{'2026-09-23 控制端接力覆盖：本卡已通过正式API从CODE转DATA，executorKind=CONTROL_SUBAGENT；此前暂存CODE段落作废。必读 '+$note+'。仅用AI163完成后的显式验证模式执行当前CSV首跑，不伪造USER-U1 DONE；保持源Editor响应，持有unity-project与物理发布锁，现批两用例不发布测试修改。'}
    $newInstruction=$task.instruction+"`n`n"+$add
    $results[('revise_'+$id)]=(& '.ai-workspace/queue.ps1' -Action ReviseInstruction -TaskId $id -Instruction $newInstruction | Out-String) | ConvertFrom-Json
}
$results.resources=(& '.ai-workspace/queue.ps1' -Action ConfigureSupervisionTask -TaskId AI-000164 -ResourceKeys @('data-batch','generated-assets','font-assets','unity-project') -Reason 'DATA隔离快照/导表及生成物发布与现CODE/ENGINE共享输入输出，保守持有unity-project并配合物理data-publication.lock；独立CONTROL_SUBAGENT路由。' | Out-String) | ConvertFrom-Json
$results.reconcile=(& '.ai-workspace/queue.ps1' -Action ReconcileSupervision -IdlePipelines @('CODE') -Verification 'This round: wait_threads confirms CODE turn 01a0ca8d-8dd1-7711-85d2-b88c116eae93 completed, idle; separate ENGINE snapshot confirms active. AI160 SUCCEEDED. DATA newly registered, no agent/task started; no RUNNING reset.' | Out-String) | ConvertFrom-Json
$results.dispatch=(& '.ai-workspace/queue.ps1' -Action DispatchSupervision -IdlePipelines @('CODE') | Out-String) | ConvertFrom-Json
$results | ConvertTo-Json -Depth 36 | Set-Content -LiteralPath (Join-Path $PSScriptRoot 'AI160-registration-and-sweep.json') -Encoding utf8
$snapshot=$results.dispatch.snapshot
[pscustomobject]@{register=$results.register.action;route=$results.register.executorKind;dataTask=@($snapshot.tasks | Where-Object taskId -eq 'AI-000164');tasks=@($snapshot.tasks | Select-Object taskId,status);disposition=$snapshot.disposition;ready=$snapshot.readyTaskIds;recoveryReady=$snapshot.recoveryReadyTaskIds;handoffGaps=$snapshot.handoffGaps;dispatches=$results.dispatch.dispatches} | ConvertTo-Json -Depth 9
