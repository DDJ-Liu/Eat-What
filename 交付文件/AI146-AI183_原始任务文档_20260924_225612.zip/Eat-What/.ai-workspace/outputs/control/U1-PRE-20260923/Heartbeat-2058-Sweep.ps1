$ErrorActionPreference='Stop'
$r=(& '.ai-workspace/queue.ps1' -Action ReconcileSupervision -IdlePipelines @('ENGINE_MCP') -Verification 'Current heartbeat wait_threads snapshot confirms CODE AI163 turn 01a0caf8-451e-7d51-adee-91e83c42d6d5 active/inProgress; ENGINE AI162 completed/idle. Only ENGINE is supplied as observed idle. Evidence: heartbeat-2058-workers.json. Preserve active CODE and font material approval boundary.' | Out-String) | ConvertFrom-Json
$d=(& '.ai-workspace/queue.ps1' -Action DispatchSupervision -IdlePipelines @('ENGINE_MCP') | Out-String) | ConvertFrom-Json
[pscustomobject]@{at=(Get-Date -Format o);reconcile=$r;dispatch=$d} | ConvertTo-Json -Depth 32 | Set-Content -LiteralPath (Join-Path $PSScriptRoot 'heartbeat-2058-sweep.json') -Encoding utf8
[pscustomobject]@{disposition=$d.snapshot.disposition;ready=$d.snapshot.readyTaskIds;recoveryReady=$d.snapshot.recoveryReadyTaskIds;handoffGaps=$d.snapshot.handoffGaps;dispatches=$d.dispatches} | ConvertTo-Json -Depth 8
