# PRE-4 诊断接收

AI158：SUCCEEDED/VERIFIED，仅诊断目标完成。场景SHA/字体/meta不变，未实施修复。完整证据：[诊断报告](../../U1-PRE/AI-000158/AI-000158_PRE-4_DIAG-T3_托盘与封面气泡诊断.md)。

|跟踪项|已证实条件|后续修复卡建议|当前安排|
|---|---|---|---|
|M7-B1-R1 托盘|Phase1激活三态Y=0/0.08/0.18及Scale=1/1.025/1.05有效；Phase0目标inactive时直接请求Highlight，逻辑先变但协程失败；重新激活不重放。H代码保留，当前驱动器不活跃所以未订阅|先核正常业务调用是否允许inactive请求，再确定缓存/激活后重放或上游门控；恢复明确的调试驱动激活路径。主观幅度调整另由设计决定|建议留档，未新建执行任务、未扩展本包|
|M2-B1-R2 气泡文案|A/B Sprite/Renderer/Cover Set齐全；无TMP/LocalizedText，T9缺ui_p0_cover_bubble_a.text与ui_p0_cover_bubble_b.text|文案先由设计给定；沿DATA导表链添加键，ENGINE以世界空间TMP/LocalizedText接线，保留现Sprite/Set/遮挡|建议留档，未虚构文案、未实施|

控制台文档影响：上述事实改变当前风险/未开发边界，已追加到项目推进基线；没有修改完整复核日期。代码入口未改，CODEBASE_MAP无新增结构变化。该结论不阻碍AI156或F-α人工验收；当前AI156/159仅等待AI157机器完成。
