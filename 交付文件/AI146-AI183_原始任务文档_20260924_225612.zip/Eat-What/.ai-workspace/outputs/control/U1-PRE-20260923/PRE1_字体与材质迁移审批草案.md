# PRE-1 字体与材质迁移：待批准的精确范围

> 2026-09-23 最新状态：用户已在控制台明确批准下述全部范围，含CoverTitle统一Static。批准原文、171项CSV的SHA及保持项见 `inputs/U1-PRE_人工反馈与字体批准_20260923.md`；AI162授权门已通过，AI167扩充工具、AI170执行。本文及CSV原提案内容保留历史；审批不等于迁移已完成或最终字体验收。以下“待批准/仅草案”描述为审批前时点，不再阻断获批范围。

2026-09-23。状态：**仅草案，尚未执行引用/材质迁移**。AI162 完成了双字体生成与只读预检，未完成正式场景字体迁移及其 Play/Build 验证。原限定是只写 m_fontAsset、保持材质；171 条预览全部因旧材质指向旧 atlas 而无法执行，需要批准以下增量范围。不是请求对未完成的画面签收。

## 建议方案

统一使用已生成的 ShortCycle_Heavy_Static（GUID `9b07c6c50dde09d4b8719754c27ddc96`）。为三种现有材质分别建立兼容新 atlas 的材质副本，保留各自渲染风格，旧字体/旧材质不修改。CoverTitle 一并从 Heavy SDF 改为同一 Static；这是唯一 source font 发生变化的对象，批准后需专门比较标题字形、宽度和换行，结果后置人工验收。

当前可核查证据：[AI162报告](../../U1-PRE/AI-000162/AI-000162_PRE-1_双字体生成与迁移预检报告.md)、[逐对象原始预览](../../U1-PRE/AI-000162/font-swap-preview.json)、[拟迁移逐项表](PRE1_字体材质迁移逐项草案.csv)。三个旧材质均为同一 TMP Shader，atlas 大小及 GradientScale 不同，不能只复制旧 MainTex 或只换字体引用。

## 允许写入的资产与字段

|资产|对象范围|拟允许字段|
|---|---|---|
|Assets/Scenes/Cooking/ShortCycle_P0P1.unity|预览的 Spaces 下161个TMP；逐项表按对象路径和组件序号锁定|m_fontAsset、m_sharedMaterial；仅关联此次切换所需引用|
|Assets/Prefabs/Cooking/ShortCycle/GridPieces/CatalogCard.prefab|预览中的2个TMP|同上|
|Assets/Prefabs/Cooking/ShortCycle/GridPieces/FridgeSlot.prefab|预览中的2个TMP|同上|
|Assets/Prefabs/Cooking/ShortCycle/GridPieces/IngredientCard.prefab|预览中的2个TMP|同上|
|Assets/Prefabs/Cooking/ShortCycle/GridPieces/Sticker.prefab|预览中的2个TMP|同上|
|Assets/Prefabs/Cooking/ShortCycle/GridPieces/TraySlot.prefab|预览中的2个TMP|同上|
|Assets/Font/Heavy/Materials/ShortCycle_Static_FromSourceHan.mat|新建及Editor生成meta；当前86条预览引用该来源|复制原材质的Shader/颜色/描边/Underlay等风格，atlas关联_MainTex、_TextureWidth、_TextureHeight、_GradientScale使用目标Static对应值|
|Assets/Font/Heavy/Materials/ShortCycle_Static_FromLegacyShortCycle.mat|新建及meta；当前77条预览引用该来源|同上|
|Assets/Font/Heavy/Materials/ShortCycle_Static_FromHeavy.mat|新建及meta；当前8条预览引用该来源，含CoverTitle|同上|

171 是场景与Prefab的预览条目数，不代表171个独立可见物体。场景实例与Prefab传播可能重合，执行前按真实对象和覆盖项重新生成去重清单；不得把实例路径变化当成扩大范围。需要新增Materials文件夹时仅由AssetDatabase生成目录/meta。

## 工具、保持项与停止线

- 批准后先安排CODE扩充现有ShortCycleFontSwapTool：显式读取批准的逐项映射、创建材质副本、全量预检后配对写font/material、记录事务/回退与非目标字段比较。不得关闭兼容性检查或为通过预检伪造executeAllowed。
- 随后ENGINE仅通过Unity Editor API执行。先单样例验证、回到可恢复基线，再批量执行审定清单；每批检查scope/备份/停止要求。若实际需改本表外字段、未知Prefab或材质风格属性，先产差异再处理，不静默扩大。
- 保持文本、字号、颜色、布局/Transform、sorting、业务接线、Modal、四区坐标、滚轮和所有无关override。已批准140条wrap继续保留。原30条材质override的历史保留；只有在上述171条映射内的引用允许随这次审批改变，不清理无关覆盖项或扩大TMP序列化。
- 不覆盖旧WithFallback、SourceHan、Heavy字体/材质，不改全局TMP fallback、RendererFeature或Build列表；不手改YAML。新材质不是重做现有描边/泡泡效果。
- 本审批不包含Git提交/推送，不等于新字体精确SHA提交守卫放行；build manifest保持PENDING_REVIEW，待最终真实成果审阅。

## 备份、回退与验证

执行时在DevTools/Fonts/backup/<后续任务ID>/按原路径备份上述6份场景/Prefab及meta，保存源/目标字体、原材质指纹和新建资产清单。失败首先保留现场和失败批次；由Editor API恢复本任务已写引用并验证非目标字段/哈希，只有本次新增且无引用的材质可清理，不能覆盖其他任务后续变化。

机器验收：171条映射重新预览通过（数量漂移须逐项解释）、Scene/Prefab字体与材质atlas匹配、无非目标字段变化、Console无新增错误、五视图中文/标题截图、Play和Build前后Static SHA不变、动态回退明确清空、退出Edit/clean。人工随后审标题字形/布局和全视图文字表现；未完成这些步骤不能声称PRE-1已经全部完成。

可直接审批：**批准此草案的171项字体/材质迁移、新建3份材质及列明5个Prefab源修改，CoverTitle也统一Static；其余保持项不变。** 若希望保留CoverTitle原字形，请明确保留该例外，后续以160个场景TMP+10个PrefabTMP迁移并调整该单项审计口径；不自动替用户选择例外。
