# DATA 接力审查与首跑前修正

2026-09-23。AI160 已完成，控制端核对注册/重分类/CONTROL_SUBAGENT 路由源码及 36 项 DATA、135 项监管回归证据。尚未执行 Unity batch 或生成物发布。以下问题由源码审查发现，追加到尚未领取的 AI163，AI164 继续依赖 AI163；不得通过伪造 USER-U1 DONE 来完成首跑。

## 已核实问题

1. `DataPipeline.Common.ps1 / Invoke-DataPublicationTransaction` 的 catch 无条件删除 live target：若准备 incoming 或备份时失败、尚未搬走旧目录，会删除未触碰的正式生成物。finally 无条件删除 previous 也可能在恢复失败时删除唯一保全副本。当前尚无生产发布，未观察到数据损坏。
2. 发布只校验 DataTables 源摘要，未对生成目录在隔离前/发布前的哈希漂移做比较。源码/包/Importer 与生成物也需按实际快照范围登记，避免发布与主工程不一致的产物。
3. `Run-DataPipeline.ps1` 当前只接受 USER-U1 DONE manifest，不能直接承载用户已授权的“现有 CSV 首跑”，后者不是用户内容导出完成。需要显式的验证模式，保持正常 DATA-Rn 的 DONE 门控不变。
4. 隔离目录默认在 runtime；本批执行边界指定 `DevTools/DataTables/.batch-workspace/`，可以通过 WorkspaceRoot 参数对齐，补忽略验证。UnityPath 存在性不能替代 6000.3.24f1 版本核验。

## AI163 同一目标内的必修项

- 扩充原卡已经允许的 Run-DataPipeline、必要 Common 辅助和离线 fixture，修复事务状态机：未触碰 live 时失败不能删 live；只清理本次确实创建的对象；恢复失败保留 previous/backup 并报告绝对路径；所有递归删除/移动先校验绝对目标在审定工程/输出目录。
- 覆盖准备 incoming 失败、备份失败、交换失败、回退失败、源或目标漂移、成功发布与幂等零变化。使用临时 fixture，禁止对生产生成物做故障注入。
- 增加首跑验证入口：当前 CSV 快照 + 明确任务/来源，隔离执行且禁止发布，不写 USER-U1 完成记录；正常轮次仍须 DONE/用户决定/哈希一致。验证模式里的真实改动仅发生在隔离源，两用例均不能改生产 CSV。
- 全阶段保守资源互斥沿用现实现；AI164 额外持有 unity-project，物理 data-publication.lock 保持从快照到 batch/结果核对结束。未来 DATA-Rn 与 CODE/ENGINE 接触同一输入输出也须声明相同资源键，不能仅靠文档声称互斥。
- 使用获批隔离目录并核验 Unity 版本；无变更不重写生产资产。将修正与原 PRE-2b ImportAllBatch 入口、幂等/真实变更测试一并收口，不新增重复任务或重跑已成功 AI160。

## DATA 首跑的停止线

AI163 未完成上述修正及验证，AI164 不可执行 batch/发布。AI164 使用独立内部 DATA 子代理领取正式票据；线程 id 为空表示正确的子代理路由，不能冒充消息已投递。AI164 与未来 USER-U1-Rn 的触发授权分别记录。

文档影响：登记 DATA 注册后的真实状态和首跑限制；不新增人工审批、不更改 AI149/154 验收结果、不提交推送。
