$ErrorActionPreference='Stop'
$r=(& '.ai-workspace/queue.ps1' -Action ReconcileSupervision -IdlePipelines @() -Verification '2026-09-23 03:33 wait_threads confirms CODE AI160 and ENGINE AI156 both active/inProgress; zero observed idle scope lanes. Observation in sweep-20260923-0333-workers.json. Active tasks unchanged.' | Out-String) | ConvertFrom-Json
$d=(& '.ai-workspace/queue.ps1' -Action DispatchSupervision -IdlePipelines @() | Out-String) | ConvertFrom-Json
[pscustomobject]@{at=(Get-Date -Format o);reconcile=$r;dispatch=$d} | ConvertTo-Json -Depth 30 | Set-Content -LiteralPath (Join-Path $PSScriptRoot 'sweep-20260923-0333.json') -Encoding utf8
[pscustomobject]@{disposition=$d.snapshot.disposition;ready=$d.snapshot.readyTaskIds;recoveryReady=$d.snapshot.recoveryReadyTaskIds;handoffGaps=$d.snapshot.handoffGaps;dispatches=$d.dispatches} | ConvertTo-Json -Depth 8
