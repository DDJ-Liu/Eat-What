$ErrorActionPreference='Stop'
Set-StrictMode -Off
Set-Location -LiteralPath 'D:/GameProject/Eat-What'
$out='.ai-workspace/outputs/control/U1-PRE-20260923'
$qscript='./.ai-workspace/queue.ps1'
$beforeMode=Get-Content .ai-workspace/runtime/mode-state.json -Raw|ConvertFrom-Json
$beforeQueue=Get-Content .ai-workspace/runtime/queue-state.json -Raw|ConvertFrom-Json
$beforeTask=$beforeQueue.tasks|Where-Object id -eq 'AI-000164'
if($beforeMode.mode -ne 'SUPERVISED' -or $beforeMode.supervised.status -ne 'PAUSED' -or $beforeTask.status -ne 'NEEDS_USER'){throw 'Expected paused supervision with AI164 NEEDS_USER.'}
if(@($beforeQueue.tasks|Where-Object status -eq 'RUNNING').Count -ne 0){throw 'A live task still runs.'}
$scope=@($beforeMode.supervised.taskIds)
$userDecision='用户于2026-09-23明确：再进行一次重试，刚才mcp没有正确连接。'
$evidence='MCP实测已连接Eat-What@d5759c75ae7cb5de；projectRoot D:/GameProject/Eat-What，assetsPath D:/GameProject/Eat-What/Assets，Unity6000.3.24f1；editor非Play/非编译/ready，当前HorizontalPlayerControllerTest clean。CODE/ENGINE末轮completed，DATA子代理completed；使用当前正常连接实例，不处理旧条款进程，不重启主Editor。证据mcp-reconnected-user-retry-evidence.json。'
[ordered]@{mode=$beforeMode;task=$beforeTask;userDecision=$userDecision;evidence=$evidence}|ConvertTo-Json -Depth 35|Set-Content (Join-Path $out 'mcp-user-retry-before.json') -Encoding utf8NoBOM
(& $qscript -Action ExitSupervision -Reason ($userDecision+' 依SUPERVISED_FULL人工重试协议安全退出后单项Reset，保留所有恢复史。'))|Set-Content (Join-Path $out 'mcp-user-retry-exit.json') -Encoding utf8NoBOM
if((Get-Content .ai-workspace/runtime/mode-state.json -Raw|ConvertFrom-Json).mode -ne 'MANUAL'){throw 'Exit did not reach MANUAL.'}
(& $qscript -Action ResetTask -TaskId AI-000164 -Reason $userDecision)|Set-Content (Join-Path $out 'mcp-user-retry-reset.json') -Encoding utf8NoBOM
$afterTask=(Get-Content .ai-workspace/runtime/queue-state.json -Raw|ConvertFrom-Json).tasks|Where-Object id -eq 'AI-000164'
if($afterTask.errorHistory.Count -ne $beforeTask.errorHistory.Count -or $afterTask.supervisionRepairs.Count -ne $beforeTask.supervisionRepairs.Count){throw 'History preservation check failed.'}
(& $qscript -Action RecordIssue -Pipeline DATA -TaskId AI-000164 -IssueKind RECOVERABLE_EXECUTION -IssueMessage ($userDecision+' '+$evidence+' 仅此次原任务人工授权重试；官方Reset将本轮attempt归零，但累计前三次执行及2条supervisionRepairs/3条errorHistory保留。新产物放user-retry-20260923，禁止覆盖attempt1/2/3。'))|Set-Content (Join-Path $out 'mcp-user-retry-record.json') -Encoding utf8NoBOM
(& $qscript -Action SetMode -Mode SUPERVISED -TaskIds $scope -ControllerThreadId $beforeMode.supervised.controllerThreadId -Reason $userDecision)|Set-Content (Join-Path $out 'mcp-user-retry-mode.json') -Encoding utf8NoBOM
(& $qscript -Action DeferSupervisionReviews -UserDecision '沿用本会话用户明确要求：把所有需要人工审查的任务全部后置，不要干扰开发任务推进。本次用户明确要求AI164重试；不代签原人工结果/字体草案。')|Set-Content (Join-Path $out 'mcp-user-retry-deferral.json') -Encoding utf8NoBOM
(& $qscript -Action BindSupervisionAutomation -AutomationId ai)|Set-Content (Join-Path $out 'mcp-user-retry-bind.json') -Encoding utf8NoBOM
(& $qscript -Action ReconcileSupervision -IdlePipelines @('CODE','ENGINE_MCP','DATA') -Verification $evidence)|Set-Content (Join-Path $out 'mcp-user-retry-reconcile.json') -Encoding utf8NoBOM
$dispatch=& $qscript -Action DispatchSupervision -IdlePipelines @('CODE','ENGINE_MCP','DATA')|ConvertFrom-Json
$dispatch|ConvertTo-Json -Depth 35|Set-Content (Join-Path $out 'mcp-user-retry-dispatch.json') -Encoding utf8NoBOM
[pscustomobject]@{sessionId=$dispatch.snapshot.session.sessionId;disposition=$dispatch.snapshot.disposition;dispatches=$dispatch.dispatches}|ConvertTo-Json -Depth 8
