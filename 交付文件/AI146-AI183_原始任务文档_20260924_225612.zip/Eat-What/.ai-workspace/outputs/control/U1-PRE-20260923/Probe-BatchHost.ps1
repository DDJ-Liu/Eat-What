param([Parameter(Mandatory)][ValidateSet('sandbox','host')][string]$Context)
$ErrorActionPreference = 'Stop'
Add-Type -TypeDefinition @'
using System;
using System.Runtime.InteropServices;
public static class BatchHostKnownFolderProbe {
 [DllImport("shell32.dll")]
 public static extern int SHGetKnownFolderPath(ref Guid id, uint flags, IntPtr token, out IntPtr path);
}
'@
$result = [ordered]@{at=(Get-Date).ToString('o'); context=$Context; psVersion=$PSVersionTable.PSVersion.ToString(); localLow=$null; processQuery=$null}
$folderId = [Guid]'A520A1A4-1780-4FF6-BD18-167343C5AF16'
$pathPointer = [IntPtr]::Zero
try {
 $hr = [BatchHostKnownFolderProbe]::SHGetKnownFolderPath([ref]$folderId,0,[IntPtr]::Zero,[ref]$pathPointer)
 $folderPath = if ($pathPointer -ne [IntPtr]::Zero) {[Runtime.InteropServices.Marshal]::PtrToStringUni($pathPointer)} else {$null}
 $result.localLow = [ordered]@{hresult=('0x{0:X8}' -f $hr);path=$folderPath;exists=([IO.Directory]::Exists($folderPath))}
} finally {if ($pathPointer -ne [IntPtr]::Zero) {[Runtime.InteropServices.Marshal]::FreeCoTaskMem($pathPointer)}}
try {
 $result.processQuery = [ordered]@{ok=$true;processes=@(Get-CimInstance Win32_Process -Filter "Name='Unity.exe' OR Name='Unity.Licensing.Client.exe'" | Select-Object ProcessId,ParentProcessId,SessionId,ExecutablePath,CreationDate)}
} catch {$result.processQuery = [ordered]@{ok=$false;error=$_.Exception.Message}}
$result | ConvertTo-Json -Depth 6 | Tee-Object -FilePath (Join-Path $PSScriptRoot ("heartbeat-1829-knownfolder-"+$Context+'.json'))
