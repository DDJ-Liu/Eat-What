$ErrorActionPreference='Stop'
$s=(& '.ai-workspace/queue.ps1' -Action SupervisionStatus | Out-String) | ConvertFrom-Json
if($s.disposition -ne 'ACTIVE'){throw 'Supervision is not active.'}
$gate=(& '.ai-workspace/queue.ps1' -Action ConfigureSupervisionTask -TaskId AI-000162 -ResourceKeys @('unity-project','font-assets') -HumanGateAfter $true -Reason '字体生成/预览已交付，但171项材质不兼容导致正式迁移和Play/Build未完成；用户原范围仅m_fontAsset。记录真实材质授权与最终验收停止线，人工后置继续独立代码/导表/场景修复；不得把PENDING_USER当字体迁移完成。' | Out-String) | ConvertFrom-Json
$r=(& '.ai-workspace/queue.ps1' -Action ReconcileSupervision -IdlePipelines @('CODE','ENGINE_MCP') -Verification 'AI162 callback: wait_threads confirmed ENGINE turn 01a0cadb-1f82-7343-bac7-f45c369fc5c7 completed/idle and CODE turn 01a0cabb-4aed-7d60-b284-b27154f4d5a7 completed/idle. Reviewed actual report: dual assets generated; no scene/font-reference migration. Independent CODE AI163 may proceed; no blind reset.' | Out-String) | ConvertFrom-Json
$d=(& '.ai-workspace/queue.ps1' -Action DispatchSupervision -IdlePipelines @('CODE','ENGINE_MCP') | Out-String) | ConvertFrom-Json
[pscustomobject]@{at=(Get-Date -Format o);status=$s;gate=$gate;reconcile=$r;dispatch=$d} | ConvertTo-Json -Depth 32 | Set-Content -LiteralPath (Join-Path $PSScriptRoot 'AI162-completion-sweep.json') -Encoding utf8
[pscustomobject]@{disposition=$d.snapshot.disposition;humanReviewTiming=$d.snapshot.humanReviewTiming;dispatches=$d.dispatches;recoveryReady=$d.snapshot.recoveryReadyTaskIds;handoffGaps=$d.snapshot.handoffGaps} | ConvertTo-Json -Depth 8
