Set-StrictMode -Off
$ErrorActionPreference = 'Stop'
$repo = 'D:/GameProject/Eat-What'
Set-Location -LiteralPath $repo
$out = Join-Path $repo '.ai-workspace/outputs/control/U1-PRE-20260923'
$queueScript = Join-Path $repo '.ai-workspace/queue.ps1'
$q = Get-Content .ai-workspace/runtime/queue-state.json -Raw | ConvertFrom-Json
$task = $q.tasks | Where-Object id -eq 'AI-000164'
if ($task.attempts -ne 2 -or $task.status -notin @('RUNNING','PAUSED_CIRCUIT')) { throw 'Expected the confirmed orphaned attempt 2 only.' }
if ($task.status -eq 'PAUSED_CIRCUIT' -and $task.supervisionProblemKey -ne 'provider_usage_limit_interruption') { throw 'Refuse to resume a different failure.' }
$preflight = Join-Path $repo '.ai-workspace/outputs/U1-PRE/AI-000164/attempt-3/preflight'
foreach ($name in @('processes-get-process.json','publication-lock-check.json','attempt-2-execution-inventory.json')) {
    if (-not (Test-Path -LiteralPath (Join-Path $preflight $name))) { throw "Missing safety evidence: $name" }
}
$evidence = '2026-09-23 new real thread snapshots: CODE/ENGINE completed; old DATA turn 01a0cb5d-8054-7413-b378-e7dd5c56cfdc failed with usage limit. Original agent absent. attempt-2 has claim and git status only; no new batch project/report. DATA recovery child executes PS7 successfully. At17:39:53 Get-Process shows no Unity or old pwsh, old PIDs42880/98412 absent; publication lock exclusive open succeeds; scene97CD unchanged. Evidence: usage-resume-workers.json and AI164/attempt-3/preflight. Platform ordinaryUsageAllowed=true. User explicitly requested recovery today.'
if ($task.status -eq 'RUNNING') {
    $fail = & $queueScript -Action Fail -Pipeline DATA -TaskId AI-000164 -ErrorKind ORPHANED_RUN -ProblemKey provider_usage_limit_interruption -FailureScope TASK -ErrorMessage $evidence
    $fail | Set-Content -LiteralPath (Join-Path $out 'usage-resume-fail.json') -Encoding utf8NoBOM
}
$current = (Get-Content .ai-workspace/runtime/queue-state.json -Raw | ConvertFrom-Json).tasks | Where-Object id -eq 'AI-000164'
if ($current.status -ne 'PAUSED_CIRCUIT') { throw 'Fail did not produce recoverable state; stop.' }
$reconcile = & $queueScript -Action ReconcileSupervision -IdlePipelines @('CODE','ENGINE_MCP','DATA') -Verification $evidence
$reconcile | Set-Content -LiteralPath (Join-Path $out 'usage-resume-reconcile.json') -Encoding utf8NoBOM
$plan = 'Provider availability has returned and user explicitly requests resume. Replace expired DATA execution with a fresh authorized internal DATA agent and new queue ticket; preserve attempts1/2 and all evidence. Reopen only the existing Unity6000.3.24f1 main workspace and established local MCP as needed, verify dataPath/version and scene safety, then execute corrected AI166 runner in a fresh attempt-3 isolation for two current-CSV validation cases. No publication, USER-U1 completion, material migration, or successful prerequisite rerun.'
$recovery = & $queueScript -Action RecoverSupervisionTask -TaskId AI-000164 -IdlePipelines DATA -RepairPlan $plan -Verification $evidence
$recovery | Set-Content -LiteralPath (Join-Path $out 'usage-resume-recovery.json') -Encoding utf8NoBOM
$dispatch = & $queueScript -Action DispatchSupervision -IdlePipelines @('CODE','ENGINE_MCP','DATA')
$dispatch | Set-Content -LiteralPath (Join-Path $out 'usage-resume-dispatch.json') -Encoding utf8NoBOM
$d = $dispatch | ConvertFrom-Json
$d | ConvertTo-Json -Depth 20
