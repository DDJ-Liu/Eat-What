$ErrorActionPreference='Stop'
$s=(& '.ai-workspace/queue.ps1' -Action SupervisionStatus|Out-String)|ConvertFrom-Json
if($s.disposition -ne 'ACTIVE'){throw 'Supervision is no longer active.'}
$q=Get-Content -Raw '.ai-workspace/runtime/queue-state.json'|ConvertFrom-Json
$existing=@($q.tasks|Where-Object moduleId -eq 'PRE-2b-PROCESS-R1')
if($existing.Count -eq 0){
 $card=Get-Content -Raw (Join-Path $PSScriptRoot 'DATA进程等待与完成凭据修复任务卡.md')
 $e=(& '.ai-workspace/queue.ps1' -Action Enqueue -Pipeline CODE -ModuleId PRE-2b-PROCESS-R1 -Title '修复DATA进程等待、完成凭据与快照验证' -DependsOn @('AI-000163') -Instruction $card|Out-String)|ConvertFrom-Json
 $newId=$e.task.id
}elseif($existing.Count -eq 1){$newId=$existing[0].id}else{throw 'Duplicate repair module.'}
$c=(& '.ai-workspace/queue.ps1' -Action ConfigureSupervisionTask -TaskId $newId -ResourceKeys @('unity-project','workflow-devtools') -Reason 'AI164实证运行器提前成功，范围内CODE修复既有DATA工具及必要Editor完成凭据；保持Unity互斥。'|Out-String)|ConvertFrom-Json
$deps=(& '.ai-workspace/queue.ps1' -Action UpdateDependencies -TaskId AI-000164 -DependsOn @('AI-000163',$newId)|Out-String)|ConvertFrom-Json
$extension=(& '.ai-workspace/queue.ps1' -Action ExtendSupervision -TaskIds @($newId) -Reason '用户已授权U1监管必要修复：AI164真实GUI进程未等待导致误报成功，新增跨CODE修复依赖；保留164失败/原始证据与恢复额度，不重跑163。'|Out-String)|ConvertFrom-Json
$r=(& '.ai-workspace/queue.ps1' -Action ReconcileSupervision -IdlePipelines @('CODE','ENGINE_MCP') -Verification 'AI164 failure: wait_threads confirms CODE/ENGINE idle. DATA completed its Fail and cleanup; do not recover until CODE repair passes. Controller confirms main PID42880 responding, owned batch98412 absent and sceneSHA unchanged (AI164-controller-safety-check.json). Original failure preserved.'|Out-String)|ConvertFrom-Json
$d=(& '.ai-workspace/queue.ps1' -Action DispatchSupervision -IdlePipelines @('CODE','ENGINE_MCP')|Out-String)|ConvertFrom-Json
[pscustomobject]@{at=(Get-Date -Format o);newTaskId=$newId;enqueue=$e;configure=$c;dependencies=$deps;extension=$extension;reconcile=$r;dispatch=$d}|ConvertTo-Json -Depth 32|Set-Content (Join-Path $PSScriptRoot 'AI164-fail-sweep.json') -Encoding utf8
[pscustomobject]@{newTaskId=$newId;disposition=$d.snapshot.disposition;dispatches=$d.dispatches;recoveryReady=$d.snapshot.recoveryReadyTaskIds;handoffGaps=$d.snapshot.handoffGaps}|ConvertTo-Json -Depth 9
