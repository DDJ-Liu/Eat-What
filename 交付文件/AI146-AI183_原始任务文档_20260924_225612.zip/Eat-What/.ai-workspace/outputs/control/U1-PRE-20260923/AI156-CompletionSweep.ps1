$ErrorActionPreference='Stop'
$s=(& '.ai-workspace/queue.ps1' -Action SupervisionStatus | Out-String) | ConvertFrom-Json
if($s.disposition -ne 'ACTIVE'){throw 'Current supervision is not active.'}
$q=Get-Content -LiteralPath '.ai-workspace/runtime/queue-state.json' -Raw | ConvertFrom-Json
$existing=@($q.tasks | Where-Object moduleId -eq 'FIX-T5-G69-R1')
if($existing.Count -eq 0){
    $card=Get-Content -LiteralPath (Join-Path $PSScriptRoot 'FIX-T5_ClueBoardShell修复任务卡.md') -Raw
    $enqueued=(& '.ai-workspace/queue.ps1' -Action Enqueue -Pipeline ENGINE_MCP -ModuleId FIX-T5-G69-R1 -Title '④左页保留压暗与板外返回的场景修复验证' -DependsOn @('AI-000156') -Instruction $card | Out-String) | ConvertFrom-Json
    $newId=$enqueued.task.id
}elseif($existing.Count -eq 1){$newId=$existing[0].id}else{throw 'Duplicate follow-up module ids.'}
$config=(& '.ai-workspace/queue.ps1' -Action ConfigureSupervisionTask -TaskId $newId -ResourceKeys @('unity-project') -Reason 'AI156截图实证未满足获批G69；范围内场景修复，与字体/源码/导表保持Unity互斥。' | Out-String) | ConvertFrom-Json
$extension=(& '.ai-workspace/queue.ps1' -Action ExtendSupervision -TaskIds @($newId) -Reason '用户已授权FIX-T5 G69与监管范围内必要修复；AI156截图实证左页隐藏不满足保留压暗，新增独立场景补漏，不重跑成功前置或延后字体开发。' | Out-String) | ConvertFrom-Json
$r=(& '.ai-workspace/queue.ps1' -Action ReconcileSupervision -IdlePipelines @('CODE','ENGINE_MCP') -Verification 'AI156 completion callback: wait_threads confirms ENGINE turn 01a0ca76-dd25-70d3-89a1-77cabe3e52d9 completed/idle and CODE turn 01a0ca8d-8dd1-7711-85d2-b88c116eae93 completed/idle. Scene SHA equals AI156 report. Preserve succeeded/PENDING_USER and original error history.' | Out-String) | ConvertFrom-Json
$d=(& '.ai-workspace/queue.ps1' -Action DispatchSupervision -IdlePipelines @('CODE','ENGINE_MCP') | Out-String) | ConvertFrom-Json
[pscustomobject]@{at=(Get-Date -Format o);status=$s;newTaskId=$newId;enqueue=$enqueued;configure=$config;extension=$extension;reconcile=$r;dispatch=$d} | ConvertTo-Json -Depth 32 | Set-Content -LiteralPath (Join-Path $PSScriptRoot 'AI156-completion-sweep.json') -Encoding utf8
[pscustomobject]@{newTaskId=$newId;disposition=$d.snapshot.disposition;dispatches=$d.dispatches;recoveryReady=$d.snapshot.recoveryReadyTaskIds;handoffGaps=$d.snapshot.handoffGaps} | ConvertTo-Json -Depth 8
