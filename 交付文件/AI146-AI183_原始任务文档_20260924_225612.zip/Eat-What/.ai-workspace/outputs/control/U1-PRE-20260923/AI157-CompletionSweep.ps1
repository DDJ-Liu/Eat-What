$ErrorActionPreference='Stop'
$s=(& '.ai-workspace/queue.ps1' -Action SupervisionStatus|Out-String)|ConvertFrom-Json
if($s.disposition -ne 'ACTIVE'){[pscustomobject]@{disposition=$s.disposition;dispatches=@()}|ConvertTo-Json;return}
$r=(& '.ai-workspace/queue.ps1' -Action ReconcileSupervision -IdlePipelines @('CODE','ENGINE_MCP') -Verification 'AI157完成回报本轮分别wait_threads(timeoutMs=0)确认CODE turn01a0ca52-3eb0-7320-be8d-8c49957bb034与ENGINE turn01a0ca52-4d5d-7193-98b1-cbf465814385均completed/idle。AI157/158队列SUCCEEDED，按真实idle对账。'|Out-String)|ConvertFrom-Json
$d=(& '.ai-workspace/queue.ps1' -Action DispatchSupervision -IdlePipelines @('CODE','ENGINE_MCP')|Out-String)|ConvertFrom-Json
[pscustomobject]@{at=(Get-Date -Format o);status=$s;reconcile=$r;dispatch=$d}|ConvertTo-Json -Depth 25|Set-Content -Encoding utf8 (Join-Path $PSScriptRoot 'AI157-completion-sweep.json')
[pscustomobject]@{disposition=$d.snapshot.disposition;dispatches=$d.dispatches}|ConvertTo-Json -Depth 6
