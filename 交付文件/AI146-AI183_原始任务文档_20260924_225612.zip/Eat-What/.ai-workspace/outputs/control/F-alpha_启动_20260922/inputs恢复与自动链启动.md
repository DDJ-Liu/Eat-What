# inputs 恢复与 F-α 自动链启动

生成时间：2026-09-22 12:41:58 +08:00

## 结论

- 工作区/分支：D:/GameProject/Eat-What / codex/unity6-followup；HEAD 启动点 170275321f31d15b0ec876838dcefa776108412e。
- 阶段包 records.zip SHA-256：407CD00BD8B78D41C281BC1C68F36722546238EA90AC0D142B2920C56D2A91CB；Archive-Stage -Action Verify 已通过 3087 文件，SelfTest 11/11 通过。
- 归档恢复 17 个文件全部与 manifest SHA 一致；用户提供 6 个文件全部与 Downloads 源 SHA 一致。
- 归档内不存在文档所写的精确文件名 CK01_P0P1_需求对照基准_v1_7.md。实际归档有 v1.5 和无版本后缀的 v2.0 现行主本；本轮恢复 v2.0 主本（SHA CFB8ECF9754447989BD4624C8EF9652E350F7304814FCEC55BE8C2E642FABF47），其内容覆盖 G31 并包含后续 G32～G36。没有伪造 v1.7 别名。
- F-α 初始拆为 AI-000146～AI-000151；并行审查经用户批准后，因 AI-000146 已完成、AI-000147 已运行，新增 AI-000152 无指针消费门控补修并置于 F2 前。实际顺序为 146 → 147 → 152 → 148 → 149 → 150 → 151。精确范围见 .ai-workspace/inputs/F-alpha_任务精确范围_20260922.md。
- USER-U1～U6 已登记为伪车道；首轮 A1 是 U1 前基线回归，不受 USER-U1 TODO 阻断。后续正式 U1 迭代的 A1 必须等待 USER-U1 DONE。
- 旧 ai-10、ai-mcp-10、ai-aigc-10、ai-10-2 当前均为 PAUSED；独立美术午夜审查未改。

## 归档恢复 SHA

| 路径 | 当前 SHA-256 | 与归档一致 |
|---|---|---|
| .ai-workspace/inputs/CK01-B_配表Schema_v2_4.md | 541FA63C8F39A668D465F9A0858037DBCD7866B235BC1716D92AD93A6F9B3AC3 | True |
| .ai-workspace/inputs/CK01_P0P1_需求对照基准.md | CFB8ECF9754447989BD4624C8EF9652E350F7304814FCEC55BE8C2E642FABF47 | True |
| .ai-workspace/inputs/排布指导书_ShortCycle_P0P1_v0_1.md | AC00929D33AF378DF715671A9D3C421A4402286755EECD0F974F0D776D857590 | True |
| .ai-workspace/inputs/CK01_内容CSV_v1_2/Cooking/CookingGameConfig.csv | 4E9330B9156EA340F9660DB1FE3DEF7549E3CE4111030240160CA8DF65D88748 | True |
| .ai-workspace/inputs/CK01_内容CSV_v1_2/Cooking/FridgeCapacityLevels.csv | 613D38842DE58F9EA7A14688CBC979EECF2FAFC320F4DEAB994EF5B10D2B30EB | True |
| .ai-workspace/inputs/CK01_内容CSV_v1_2/Cooking/InitialInventory.csv | 5DEC08EF5D6087AE5E10582024276308481E41792058AA137A03EB731258F81D | True |
| .ai-workspace/inputs/CK01_内容CSV_v1_2/Cooking/Items.csv | 2A2C9E94BDD4BC9AEE2CE2AB05176E1C4CF911934BE028F96F929EE1CE05EC88 | True |
| .ai-workspace/inputs/CK01_内容CSV_v1_2/Cooking/KitchenAreas_补列参考.csv | E627E3204274A444E07C59BA68B265EE94962291CF7766C44B3348F92222462B | True |
| .ai-workspace/inputs/CK01_内容CSV_v1_2/Cooking/ProcessActions.csv | E684A7F4C6D5C25DBC935AB2ABC60E588782072C50480281C42F6BFA8A937A61 | True |
| .ai-workspace/inputs/CK01_内容CSV_v1_2/Cooking/ProcessingRecords.csv | 5295D9DB3907A768D28AAEB9E35DAE6FC66163FF0674652CC357092934DD07FF | True |
| .ai-workspace/inputs/CK01_内容CSV_v1_2/Cooking/Recipes.csv | B15BA847564BE438FF5DC8B2FB1DD5745285AD7A22BD50A9937069EFAB94CBB8 | True |
| .ai-workspace/inputs/CK01_内容CSV_v1_2/Cooking/RecipeSlots.csv | 1F9171E2FE58BE206C89F2E7064C3171A3FD0DAAEBF22829D92AC097DB3C2953 | True |
| .ai-workspace/inputs/CK01_内容CSV_v1_2/Cooking/RecipeSteps.csv | 7DF07594CE860A1B3FDA43503C983C545D9EEFF9A7BFE59964EFD517346B8599 | True |
| .ai-workspace/inputs/CK01_内容CSV_v1_2/Cooking/RecipeVariants.csv | 5E6BA505A769D30473B76F57DAFD17C67E71C65D28DCD7337C69DCBECCB52C26 | True |
| .ai-workspace/inputs/CK01_内容CSV_v1_2/Cooking/Tags.csv | 0302008CC783813A3EE31636B10C430548E3BEF9CFA82F449202169D70B56F77 | True |
| .ai-workspace/inputs/CK01_内容CSV_v1_2/Cooking/Tools.csv | 8404D70EAA835ACFF143260B9819E6FE4E1D9643811638BD092E886EFA92123B | True |
| .ai-workspace/inputs/CK01_内容CSV_v1_2/Localization/Localization.csv | EA4F67B5441C688A2D88E97C5FF29C7B80C5BADA0567A7D6C60B4601F839DA0F | True |

## 用户提供文件 SHA

| 路径 | 当前 SHA-256 | 与 Downloads 源一致 |
|---|---|---|
| .ai-workspace/inputs/迁移后状态同步_inputs恢复_F批次建议_20260922.md | 1D84943D3F684DECB39F64383EF50FDCA5C53C6D365B5F4243953C01ACE0275F | True |
| .ai-workspace/inputs/P0-P1_模块拆分追踪表_v1_2_2_20260922.md | 49E8F5024D5B50CB51EF5A5BC6B3FA546287A1309D5C3681B5832F49C0D9E61A | True |
| .ai-workspace/inputs/P0-P1_开发路径规划_v2_1_1_20260922.md | 4D0762317B5C2847332E139AC1658129ED820795E415677F85F33A85E19AAE3C | True |
| .ai-workspace/inputs/USER_WORK_STATUS.md | E02E7F87C512A9F6D319FFA594700186FCD4FEDF2844A047D1BBB9E5468F44F7 | True |
| .ai-workspace/inputs/AI开发工作流总档_设计端_v1_5_1.md | 525F45CCE2D29D43883BE890A957B4FFB3E0766275E8DFBD4CA3B057FAD42A71 | True |
| .ai-workspace/inputs/排布指导书_ShortCycle_P0P1_v0_2.md | DCDFEA1FA9FA7B58CD1EE07E68ED87073A92F340CE1257359EBFD06B00312381 | True |

完整机器清单见 inputs-hashes.json。

## 工作流与文档改动

- DevTools/Workflow/Archive-Stage.ps1：增加常驻输入白名单和 SelfTest，Plan/Create 不再归档命中项。
- .ai-workspace/CONTROL_CHAT.md、.ai-workspace/README.md、.ai-workspace/inputs/README.md：写入 G64、常驻输入和 F-α/AUTOMATIC 入口。
- .ai-workspace/INSTRUCTIONS.md：登记 USER-U1～U6，并由队列追加 AI-000146～AI-000151。
- .ai-workspace/TOOLKIT_REGISTRY.md：TK-WF-01 补充白名单与自检说明。
- AGENTS.md、CODEBASE_MAP.md、项目整体阅读理解与推进基线_2026-08-14.md、H后交接：同步 F 已选和执行边界；完整结构复核日期未虚增。

## 六要素

1. 目标：恢复跨阶段输入并启动 Unity 6 首个功能批次 F-α。
2. 范围：输入/工作流登记、MIG-F04、MIG-F01、A0、A1；不含 MIG-F09、ART 占位部署、_TUNE 全审。
3. 依赖：初始六项加一项 F1 小型补修严格串行；链尾才进入用户一次人工验收。
4. 写入：精确文件清单在任务范围文档；Scene/Prefab 变更仅 Lab 确有必要时经 MCP，正式 P0/P1 不在本链配置范围。
5. 验证：归档 SHA、输入源 SHA、Archive-Stage Verify/SelfTest、各任务 runner/Unity Play/Console/字体恢复。
6. 回退：输入可由 records.zip+manifest 重建；A1 生成资产写前备份到 DevTools/Generated/backup/<任务号>/；流水线临时 dirty 由责任任务清理。

## 链尾人工节点

自动段完成后仅汇总等待：13 步驱动器、FridgeScrollLab 手感、导表结果。该节点不由执行器代签，不自动进入 E2。
