# AI-000180 → ENGINE 交接

## 必要前提

- 仅使用当前 `D:/GameProject/Eat-What` 的 Unity `6000.3.24f1` 已运行实例和指定 MCP；不启动新 Editor，不用 batchmode。
- 先核对 `Application.dataPath`、Unity 版本、Console 和未保存/未知 dirty 基线。发现未知变化则停止，不覆盖。
- 不复用 attempt 1–5 的计划或诊断；新轮命名为 `attempt-6-material-resolution-r1`。

## 验证顺序

1. 生成全新 schema-7/v3 计划：必须是 231 行、7 个资产、`reasons=[]`、`executeAllowed=true`。任一不符立即停止，不改 CSV，不执行。
2. 运行公开双次指纹诊断（report schema 2）：两次都必须有 231 行，并逐行包含 raw font/material、effective material、normalization reason、saved-reference owner/path/SHA/proven。
3. 归一化数量必须精确为 40：只能是 `TraySlot_01_TUNE..20_TUNE` 的 `BadgeLabel/NameLabel`，理由为 `TMP_LOAD_FONT_ATLAS_MISMATCH_DEFAULT_MATERIAL`；其余 191 行的理由必须为空。
4. 逐一核对这 40 行：raw 引用仍是获批的 SourceHan 字体/材质，effective material 是该 font 的精确 default material，且 owner/path/SHA/proven 证明完整。
5. 先执行一个可回滚的小样本并完整恢复，复核文件哈希、Console 和 dirty 状态。
6. 样本回滚通过后再进行完整分批执行及现有全套验收，包含重启/重载后验证、视觉/场景要求与无未知 dirty 收尾。

## 失败边界

- 任意 raw/effective 不可解释差异、归一化数量不是 40、身份/来源/覆盖/SHA 证明缺失、两次诊断不一致或 Console/资产状态异常，立即停止并保留证据。
- 不得为通过验证而修改批准 CSV、弱化规则或手工改 Unity YAML。
- CODE 已证明编译与契约，但无法代替真实 TMP 加载生命周期签收；ENGINE 必须回传实机诊断与执行/回滚证据。

