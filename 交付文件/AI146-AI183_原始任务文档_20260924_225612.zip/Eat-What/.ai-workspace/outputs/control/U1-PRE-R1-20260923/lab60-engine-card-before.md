# PRE-1c [ENGINE_MCP] 已批准字体材质迁移执行

## AI176成功后的第一次正式恢复（2026-09-24）

先读`outputs/U1-PRE-R1/AI-000176/AI-000176_PRE-1c-PREFAB-R1_修复报告.md`与`verification-summary.json`。控制台核对3份源码哈希、两次有理由Fonts Final各2/2通过、场景及批准CSV哈希不变；该结果只允许恢复真实Editor验证，不代表生产预检通过。恢复输出使用`outputs/U1-PRE-R1/AI-000170/attempt-2-prefab-r1/`，样例与全量使用不同新事务路径；旧预检、事务、失败与宿主恢复史保留，不覆盖。

新事务schema=3，固定每条批准行的写入身份及Prefab关系，仅before/after/继承结构等价才可去重；场景实例目标不同时先写实例再写Prefab源，回退相反。必须核实raw/逐行覆盖=171、真实uniqueEntryCount及覆盖关系、未批准传播检查、全部reasons和executeAllowed。不得沿用旧63或强置unique=171。单样例须明确只写1个真实FromSourceHan TMP、不经源传播扩大；真实回退核对字体/材质、override结构及非目标字段，完成后才另起全量事务。批次按公开API与实例优先规则选择；所有171行的已完成/待办状态、未知漂移和非目标指纹继续检查，不能直接编辑事务/反射private或改批准CSV。若出现新预检阻断，留真实差异和零/部分写入证据回报，不重复同方案盲试。

## 首轮预检失败后的恢复约束

AI170首轮正式Preview得到raw=171、有效计划entries=63、8组CANONICAL_CONFLICT、executeAllowed=false，未Begin/写生产/创建材质。旧`approved-plan-before.json`、失败报告及错误史原样保留。CODE修复任务AI176已加入依赖；只有其真实成功、控制台审核并正式Recover/新票据后才恢复，不自动Reset或重用旧票据。恢复采用新的attempt子目录与新事务路径，重新核Editor/批准CSV/布局/三材质和全部171行；必须解释去重数与源/实例覆盖及传播，不机械要求unique=171或把63写成已完成。继续单FromSourceHan样例→真实回退→分批全量。旧CANONICAL_CONFLICT不得通过改CSV、删检查或手造executeAllowed绕过。

所有队列操作必须让exec_command的shell参数精确为`C:/Users/DDJ/.cache/codex-runtimes/codex-primary-runtime/dependencies/native/powershell/pwsh.exe`，在其内直接`& ./.ai-workspace/queue.ps1 ...`；禁止外层PS7内再启动`powershell.exe`，首轮领取宿主错误已入issueHistory。

## AI169完成后的基线接力（2026-09-23）

AI169已SUCCEEDED/PENDING_USER，最终Edit/clean、Console Error=0。先读`outputs/U1-PRE-R1/AI-000169/AI-000169_FIX-T5-R1b_完成报告.md`、`verification-summary.json`、`geometry.csv`；控制台已核场景/scene meta与7张PNG哈希一致。当前scene SHA为`233113A72258444BD69C6FD014424435C4D15DD4D1EA9C01A8CF61F13E71BECB`，是字体迁移前已保存布局成果，不还原AI169以前的场景。仍由你重新发现核对Editor实际状态并建立本任务备份。

保护P0Left=-9.6、两返回键CameraViewportAnchor=(0.06,0.08)、唯一ClueBoard持续视觉与P1恢复布局。171映射是否漂移仍须真实Editor预检。AI169清理了SaveScene新增40材质/60fontFeature override与40 Renderer材质漂移，保留140wrap/30材质基线；本卡不能把范围外序列化漂移当作用户批准的字体变化。

已知旧诊断`fixT5FourMarkers=False`来自LayoutAudit仍硬编码P0Left=-12.8，和本轮获准构图不一致；此非字体迁移失败、不要求场景回退旧坐标。已纳入AI171长期验证工具维护、AI172复验；本卡如引用该字段须标明已知诊断偏差，不能写成整个LayoutAudit全绿或静默改断言。其余真实异常照常检查。

接力增量：正式迁移另依赖AI173（PRE-1b-R1）。AI167原工具仅全量执行，不能用它冒充单样例/分批；按AI173公开API先完整预检→单样例→回退验证→逐批checkpoint/写入→全量收尾。禁止反射私有方法、改批准CSV或手工伪造事务来补工具缺口。AI167/173报告各自的离线验证不替代本卡真实Editor验证。
共同执行约束：领取 CORE.md、当前任务卡及对应 worker；按 SUPERVISED.md 使用同一 PowerShell 7 宿主和真实 TaskId/DispatchToken，生产写入批次前 SupervisionCheckpoint。目标 D:/GameProject/Eat-What、codex/unity6-followup、Unity 6000.3.24f1。读 inputs/U1-PRE_人工反馈与字体批准_20260923.md；最新用户授权优先于旧待批准文本。保留所有已有修改、错误/恢复史，不 Reset 成功任务，不提交/推送，不手改 Unity YAML/meta。输出 outputs/U1-PRE-R1/<TaskId>/，六要素报告、真实工具计量，不估算 provider token；Complete/Fail 后回传 supervisorHandoff 并结束，由控制台派下一棒。人工审查后置但不代签。
依赖PRE-1b与本轮空间修复：避免布局修改同一scene并污染非目标指纹。读取明确批准及原逐项草案CSV，不再以“材质尚未批准/5Prefab禁止修改”阻断批准范围。仍必须遵守真实平台审批。
写入范围仅171映射：ShortCycle scene161、CatalogCard/FridgeSlot/IngredientCard/Sticker/TraySlot各2TMP、3新material及meta、AssetDatabase生成Materials目录；Static GUID9b07c6c50dde09d4b8719754c27ddc96，CoverTitle也统一。代码问题交控制端CODE返修，不绕过预检。禁止手改YAML。
先运行PRE-1b及AI176交付的真实EditorAPI只读复核及dryrun，核对171原始批准行和逐行覆盖，真实去重计数由Editor输出并解释；实例/Prefab传播重复及任何漂移逐条报告，不拓scope。批准CSV原SHA及真实授权必须留证。若已有同名材质核对归属/内容而非覆盖未知成果。
备份到DevTools/Fonts/backup/<TaskID>/六份scene/prefab+meta、旧新字体/材质指纹、非目标序列化字段和新增清单。单样例任选1条FromSourceHan → 验证font/material/atlas/风格与非目标字段 → 回退基线并确认相同（回退包含测试新增资产归属） → 全量按审定清单分批执行，每批SupervisionCheckpoint、scope、备份和停止检查，保留失败现场/事务而非半写假通过。
材质copy旧Shader/颜色/outline/underlay，只有_MainTex/_TextureWidth/_TextureHeight/_GradientScale取Static；配对m_fontAsset+m_sharedMaterial。5Prefab源可改这两字段，其他Prefab源仍禁改；30材质override映射内按本授权，其他保留，140wrap保留。
机器验收：171重预览（漂移解释）、Scene/Prefab全atlas匹配、非目标字段前后一致、Console无新增Error/Exception、五视图中文/标题截图、Play与Build前后StaticSHA不变、DynamicFallback清空、Edit clean。Build列表不改、manifest始终PENDING_REVIEW；若已知旧warning明确基线，不称全Console历史0。CoverTitle同镜头前后单列截图和宽度/换行测量，人工后置。
保留旧fonts/materials、fallback全局、布局/Transform/文案/字号/颜色/sorting/交互、滚轮/Modal、所有无关override。范围外必改先差异停该项。SUCCEEDED + PENDING_USER，不ApproveGate，不Git提交/推送或字体guard哈希放行。机器通过不能等同最终字体人工签收。
