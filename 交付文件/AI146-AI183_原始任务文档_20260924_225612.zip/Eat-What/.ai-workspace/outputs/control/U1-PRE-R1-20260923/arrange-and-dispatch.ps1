$ErrorActionPreference='Stop'
Set-StrictMode -Off
$root='D:/GameProject/Eat-What'
Set-Location -LiteralPath $root
$out=Join-Path $root '.ai-workspace/outputs/control/U1-PRE-R1-20260923'
if(Test-Path -LiteralPath (Join-Path $out '12-send-receipt.json')){throw 'This archived one-shot orchestration already ran. Read current state; do not replay administrative actions or enqueue duplicates.'}
New-Item -ItemType Directory -Force -Path $out | Out-Null
function Invoke-Control([string]$Receipt,[hashtable]$ArgsMap) {
  $raw=& .ai-workspace/queue.ps1 @ArgsMap
  [IO.File]::WriteAllText((Join-Path $out ($Receipt+'.json')),($raw -join [Environment]::NewLine),[Text.UTF8Encoding]::new($false))
  $r=($raw -join [Environment]::NewLine)|ConvertFrom-Json
  [Console]::WriteLine(('{0}: {1} {2}' -f $Receipt,$r.action,$r.task.id))
  return $r
}
$q=Get-Content -Raw .ai-workspace/runtime/queue-state.json|ConvertFrom-Json
if(@($q.tasks|Where-Object status -eq 'RUNNING').Count){throw 'Task started since preflight; inspect instead of switching.'}
$m=Get-Content -Raw .ai-workspace/runtime/mode-state.json|ConvertFrom-Json
if($m.mode -eq 'SUPERVISED'){
  $null=Invoke-Control '01-administrative-exit' @{Action='ExitSupervision';Reason='本轮用户明确保持监管并关闭Modal任务；现无运行任务，仅暂转MANUAL满足旧REJECTED任务行政关闭API，随后立即新建本轮监管scope；不Reset、不清错误史。'}
}
$null=Invoke-Control '02-modal-accepted' @{Action='ResolveVerification';TaskId='AI-000154';Summary='用户正式人工验收Modal通过，关闭本功能验收。';Verification='2026-09-23本控制台用户原话：modal功能的验收是通过的，没有问题。功能相关任务可以进行关闭。见inputs/U1-PRE_人工反馈与字体批准_20260923.md；不延伸为本轮布局或字体验收。'}
$null=Invoke-Control '03-ai149-superseded' @{Action='CloseWithoutAcceptance';TaskId='AI-000149';ClosureReason='SUPERSEDED';Reason='旧Modal拒绝已由AI153修复、AI154正式接入且本轮人工验收通过；旧AI149按被修复任务覆盖关闭，accepted=false保留原REJECTED与错误历史，不伪称旧测试当时通过。';UserDecision='2026-09-23用户：modal功能的验收是通过的，没有问题。功能相关任务可以进行关闭。滚轮手感此前已认可。'}
$null=Invoke-Control '04-ai156-rejected' @{Action='RejectVerification';TaskId='AI-000156';Reason='2026-09-23用户实测：返回箭头仍固定书下而非镜头左下；板与书大空隙，要求全左页+右页30–40%；进入P1线索板闪隐；P1猫/板/GO/托盘/返回明显错位。本轮FIX-T5-R1a/b独立修复，保留旧机器证据，不能整场回滚破坏已验收Modal。'}
$null=Invoke-Control '05-font-authorization' @{Action='ApproveSupervisionGate';TaskId='AI-000162';UserDecision='2026-09-23用户明确批准PRE-1字体材质草案全部范围：171逐项CSV映射、Static GUID9b07c6c50dde09d4b8719754c27ddc96与配对material、3新材质/meta和Materials目录、5具名Prefab各2TMP、CoverTitle统一Static、DevTools/Fonts/backup/<任务ID>/备份回退；保持项/停止线原草案，不含Git提交推送，manifest PENDING_REVIEW。原文与CSV SHA见inputs/U1-PRE_人工反馈与字体批准_20260923.md。此闸门仅授权后续PRE-1b/c，AI162仍PENDING_USER，不代签新字体最终画面；PRE-1c另保留最终人审。'}

$cards='.ai-workspace/inputs/U1-PRE-R1-20260923'
$ids=[ordered]@{}
$defs=@(
 @{key='fontCode';lane='CODE';module='PRE-1b';title='已批准字体材质配对迁移工具与回退干跑';file='PRE-1b_CODE.md';deps=@('AI-000155','AI-000161');gate=$false;resources=@('unity-project','font-assets','workflow-devtools')},
 @{key='layoutCode';lane='CODE';module='FIX-T5-R1a';title='镜头视口锚定与线索板持续显示逻辑';file='FIX-T5-R1a_CODE.md';deps=@('AI-000155');after='fontCode';gate=$false;resources=@('unity-project','workflow-devtools')},
 @{key='layoutEngine';lane='ENGINE_MCP';module='FIX-T5-R1b';title='连续空间构图、返回键锚定与P1画面恢复';file='FIX-T5-R1b_ENGINE.md';deps=@();after='layoutCode';gate=$true;resources=@('unity-project')},
 @{key='fontEngine';lane='ENGINE_MCP';module='PRE-1c';title='批准171项字体材质迁移、样例回退和机器验收';file='PRE-1c_ENGINE.md';deps=@('AI-000162');after='layoutEngine';also='fontCode';gate=$true;resources=@('unity-project','font-assets','generated-assets')},
 @{key='e2Code';lane='CODE';module='MIG-E2a';title='迁移证据归档恢复核验与长期工具功能命名准备';file='MIG-E2a_CODE.md';deps=@('AI-000154');after='fontEngine';gate=$false;resources=@('unity-project','workflow-devtools','migration-archive')},
 @{key='e2Engine';lane='ENGINE_MCP';module='MIG-E2b';title='长期验证资产保GUID更名与迁移收尾复验';file='MIG-E2b_ENGINE.md';deps=@();after='e2Code';gate=$false;resources=@('unity-project','migration-archive')}
)
foreach($d in $defs){
  $deps=@($d.deps)
  if($d.after){$deps+=@($ids[$d.after])}
  if($d.also){$deps+=@($ids[$d.also])}
  $instruction=Get-Content -Raw -LiteralPath (Join-Path $cards $d.file)
  $r=Invoke-Control ('enqueue-'+$d.key) @{Action='Enqueue';Pipeline=$d.lane;ModuleId=$d.module;Title=$d.title;Instruction=$instruction;DependsOn=$deps}
  $ids[$d.key]=$r.task.id
  $null=Invoke-Control ('policy-'+$d.key) @{Action='ConfigureSupervisionTask';TaskId=$r.task.id;ResourceKeys=$d.resources;HumanGateAfter=$d.gate;Reason='2026-09-23用户保持监管并授权本轮修复/字体精确迁移/迁移收尾；统一Unity资源互斥，布局与字体最终人工后置保留，不伪造验收。'}
}
$ids|ConvertTo-Json|Set-Content -LiteralPath (Join-Path $out 'task-map.json') -Encoding utf8NoBOM
$null=Invoke-Control '06-new-session' @{Action='SetMode';Mode='SUPERVISED';TaskIds=@($ids.Values);ControllerThreadId='01a08798-8b2a-7d41-9aa8-ab44affd520a'}
$null=Invoke-Control '07-review-deferral' @{Action='DeferSupervisionReviews';UserDecision='沿用用户明确要求：把所有需要人工审查的任务全部后置，不要干扰开发任务推进。本轮保持监管模式；PRE-1c明确SUCCEEDED+PENDING_USER。后置不解除归档持久化/副本删除安全条件，不代签字体画面。'}
$null=Invoke-Control '08-bind-heartbeat' @{Action='BindSupervisionAutomation';AutomationId='ai'}
$null=Invoke-Control '09-reconcile' @{Action='ReconcileSupervision';IdlePipelines=@('CODE','ENGINE_MCP');Verification='本轮wait_threads实证两线notLoaded且最新turn completed；worker IDLE、无RUNNING，Editor已Edit/clean。'}
$null=Invoke-Control '10-dispatch' @{Action='DispatchSupervision';IdlePipelines=@('CODE','ENGINE_MCP')}
$null=Invoke-Control '11-pending-review' @{Action='PendingReview'}
[pscustomobject]@{taskMap=$ids;mode=(Get-Content -Raw .ai-workspace/runtime/mode-state.json|ConvertFrom-Json)}|ConvertTo-Json -Depth 8
