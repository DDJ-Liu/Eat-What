# PRE-1c [ENGINE_MCP] 231行批准字体材质迁移执行

## AI179修复等待与后继恢复约束（2026-09-24）

AI170 attempt4已真实失败并恢复安全现场：Preview因m_PrefabInstance的UnityEngine.Object内部引用被DescribeObjectReference拒绝，未产计划/Begin/备份/生产写入。控制台独立只读核对有效保存GlobalObjectId，12原哈希+2场景meta一致。已新增AI179必要CODE修复作为依赖；保持PAUSED_CIRCUIT，等AI179真实成功及控制台核源码/测试/公开移交后才正式Recover，不能凭此卡重领。后继以AI179确认的实际schema/指纹版本创建全新计划，不续用旧schema1～5计划或旧事务。具体证据和卡见PRE-1c-PREFAB-REFERENCE-R1_CODE.md。

AI178已SUCCEEDED/VERIFIED（CODE范围）；控制台核唯一Fonts Final两runner exit0、真实Unity6/TMP DLL149504字节、3源码及9批准/生产输入共12哈希一致、三新材质和备份不存在。已核生产共用归一化核心、引用原子遍历、持久/本地结构身份、缺失引用拒绝、schema5/v2兼容门及双轮只读诊断；实际SerializedProperty仍待本卡验收，不以离线成功代签。报告/公开移交位于 .ai-workspace/outputs/U1-PRE-R1/AI-000178/，控制端证据 ai178-source-baseline-check.json。

本卡优先于AI178 ENGINE-handoff.md的示例启动命令：复用当前主Editor并通过MCP调用公开C# API；不得在已打开的D:/GameProject/Eat-What上再起batchmode，不停止当前Editor或共享MCP服务。不得照示例自动“保存用户工作”。以下场景关闭/重开仅在逐场景确认clean、保存恢复点/内存修改归属和当前加载布局后执行；未知用户dirty不保存、不丢弃。

## 原失败与新执行目录

原AI170四条错误/六条issue/总三次恢复保留，不Reset：attempt1归并冲突已修；attempt2未批准Lab60传播已由用户精确批准和AI177扩充解决；attempt3真实schema4预检231行/201写入项/7资产、executeAllowed=true，但Begin因瞬态FileID非目标指纹漂移在备份/事务前拒绝，生产写入0。本次Fail遗漏ProblemKey，当前正式key=EXECUTION；原pre1_non_target_fingerprint_transient_fileid恢复与本次内部Prefab引用缺口按同一稳定身份根因家族保守累计：家族已1次、总3次；下次恢复至多家族第2/总第4次。不得换key/Reset清预算，所有原始历史保留。同类后续Fail显式用pre1_non_target_fingerprint_transient_fileid，控制台仍合并EXECUTION别名核账。旧目录和计划/报告全部保留。

只有正式Recover/新票据后执行；当前卡不自行授权领取。新输出 .ai-workspace/outputs/U1-PRE-R1/AI-000170/attempt-5-prefab-reference-r1/，sample/full均为新事务路径。新计划/事务使用AI179最终交付的实际版本；本轮旧schema1～5计划全部弃用并保留证据，不可续跑，不能改旧计划/事务版本绕过。真实unique由Editor给出并解释，不能用合成231或旧201代签。

## 必读、宿主与边界

先读 .ai-workspace/CORE.md、workers/ENGINE_MCP.md、SUPERVISED.md、UNITY_SCENE_CLEANUP.md、toolkit/LOC.md TK-LOC-03及字体/Editor坑；ENGINEERING_CONVENTIONS.md C1～C4。读两份项目文档页首及Fonts/空间模块。本卡与AI178的ENGINE-handoff.md共同使用，冲突以本卡的主Editor/场景保护及用户授权为准。

工作区D:/GameProject/Eat-What，codex/unity6-followup，6000.3.24f1。每次MCP使用前发现/选择实例并核Application.dataPath/version、Edit/Play/Compile、各loaded场景dirty和Console。exec_command显式shell=C:/Users/DDJ/.cache/codex-runtimes/codex-primary-runtime/dependencies/native/powershell/pwsh.exe；其内直接 & ./.ai-workspace/queue.ps1，不嵌套Windows5或降低ExecutionPolicy。先正常Refresh/Compile确认AI179实际程序集，不把旧DLL缺成员重报为本根因。

## 真实批准与范围

原批准旁证 .ai-workspace/inputs/U1-PRE_人工反馈与字体批准_20260923.md，映射 .ai-workspace/outputs/control/U1-PRE-20260923/PRE1_字体材质迁移逐项草案.csv，SHA EB0CED01C1BBB0050DCF30BAA3D5354E9F2C7326C3DF97375DE87467D8FE347B。
Lab60旁证 .ai-workspace/inputs/U1-PRE_Lab60_增量批准与接力_20260924.md，映射 .ai-workspace/outputs/control/U1-PRE-R1-20260923/PRE1_Lab60_增量迁移草案.csv，SHA E8AA50B24E3ACA11E55D21F752EB92CD801B83960F443DF12E199DBC1B33A579。
两CSV保持原样，历史PROPOSED_ONLY/PENDING_USER不是缺批准；批准不代表平台回执或最终人审。

- Assets/Scenes/Cooking/ShortCycle_P0P1.unity：原CSV路径+组件序号锁定161 TMP。
- Assets/Prefabs/Cooking/ShortCycle/GridPieces/下 CatalogCard.prefab、FridgeSlot.prefab、IngredientCard.prefab、Sticker.prefab、TraySlot.prefab：各2 TMP。
- Assets/Scenes/ToolTests/FridgeScrollLab.unity：Spaces/FridgeScrollModule/FridgeCat_Group/SlotPool/FridgeSlot_01～30各BadgeLabel/NameLabel组件0，共60 TMP。font原继承、material原override，回退必须还原结构。
- 总raw/逐行coverage231，7资源及meta备份；只改m_fontAsset与配对m_sharedMaterial及必要override。Static GUID9b07c6c50dde09d4b8719754c27ddc96；CoverTitle唯一源字体例外继续有效，单列字形/宽度/换行对比。
- 新资产仅 Assets/Font/Heavy/Materials/ShortCycle_Static_FromSourceHan.mat、ShortCycle_Static_FromLegacyShortCycle.mat、ShortCycle_Static_FromHeavy.mat及meta；Materials目录由AssetDatabase创建。复制原Shader/颜色/描边/Underlay风格，仅_MainTex/_TextureWidth/_TextureHeight/_GradientScale取Static。Lab复用FromSourceHan，不加第4份；同名未知资产不覆盖。
- 保留140wrap，旧30材质override仅映射内可变；其它Prefab/字段/文本/字号/颜色/Transform/布局/Renderer/sorting/交互/Build列表/全局fallback不变。批准范围外传播停止，不扩大工程迁移。

## 真实执行顺序

1. 记录加载场景、活动场景、dirty、保存恢复点、scene/meta及目标字体/材质SHA，保留CoverTitle迁移前同镜头证据。使用公开双映射重载 PreviewApprovedMigration(baseMapping, baseEvidence, supplementalMapping, supplementalEvidence, planPath) 生成AI179实际版本的全新计划。真实检查231覆盖/7资源、身份/源传播/三材质/非目标指纹/理由和executeAllowed。
2. 公开 DiagnoseApprovedNonTargetFingerprints(planPath, diagnosticPath) 要求两个批准场景均未loaded。先核所有要关闭的精确场景为clean且无用户未保存成果，再用Editor API暂开本任务拥有的空场景（需要时），仅关闭这两个目标场景，保留其它加载场景。记录原加载布局，try/finally恢复原活动场景和加载状态，清理仅属于本任务的临时空场景。不能SaveScene未知dirty或用MarkSceneClean掩盖。
3. 调用上述公开诊断：五Prefab两次独立加载/卸载、两场景打开关闭两轮；success/stableAcrossReloads/referencesValid=true，rowCount231、approvedAssetCount7、unstableRowCount0，两轮逐行指纹与引用身份一致。引用身份必须有效且非空，不得把不同实例都归空串；核NULL、持久资源、本地对象/组件及新增内部Prefab引用身份与真实对象/保存资产/实例归属对应；不得空身份或忽略内部关系。对照本轮新计划逐行指纹；若不同解释并停止，不手改计划或删断言。核CSV/7资源/meta/SHA未变、Console无新增Error/Exception，并恢复主Editor原布局。恢复后Begin仍会再核现场。
4. 只读诊断通过后，检查点CONTINUE才用公开 BeginApprovedMigration(taskId, baseMapping, baseEvidence, supplementalMapping, supplementalEvidence, planPath, transactionPath)。单FromSourceHan样例明确只改1个真实TMP（approvedRowIdentities.Length==1，不靠Prefab源扩散）。核字体/material/atlas、旧风格及非目标字段；公开RollbackApprovedMigration完整回退，并实核7资源/meta/原引用/继承和override结构、新增资产归属回到保存基线。
5. CreateBackup按taskId复用DevTools/Fonts/backup/AI-000170；原资源仅同SHA复用，不提供任意backupRoot。全量Begin前将样例的7资源/meta、backup-manifest及字体材质指纹/新资产清单按精确清单保全到独立样例快照，记录SHA和事务对应关系，再更新当前manifest；不得无留档覆盖旧manifest/旧资源、递归复制父目录到自身子目录、反射private换路径。回退后不一致停止。
6. 独立全量事务用公开Begin/ApplyApprovedBatch/FinalizeApprovedMigration。实例先于Prefab源，每批checkpoint、scope/备份/停止检查，批后全231行待办/已完成/非目标/外部漂移检查。失败留现场与日志，只有公开API可靠回退；不得伪造executeAllowed、改CSV、手写事务或手改YAML。范围/引用真实变化仍必须拦截。

## 机器验收与保持

完成231行实际引用/atlas配对重审、去重解释、非目标与override一致性。原ShortCycle五视图中文/标题截图、CoverTitle同镜头前后字形/宽度/换行对照，Lab文字可见/双向滚轮/上下界真实验证。Play与Build前后Static SHA不变，DynamicFallback清空，字体manifest始终PENDING_REVIEW，不改Build列表。旧warning与本轮新错误分开记录；最终单目标正常场景Edit clean、Console无新增Error/Exception。所有临时资源/场景恢复按清理规范，不覆盖未知用户修改。

保护AI169布局：P0Left=-9.6，Escape/Return viewport(.06,.08)，唯一ClueBoard持续视觉及P1构图；AI169报告/verification-summary/geometry.csv为保存结果。迁移前ShortCycle SHA233113A72258444BD69C6FD014424435C4D15DD4D1EA9C01A8CF61F13E71BECB、Lab SHA4086672BB61AB57B8D32913922A80BD4708E56A1FF96C8D7CD644EB2857CC02D，实际执行重读；漂移不盲还原。LayoutAudit旧-12.8断言误报已交AI171修源码/172复验，不回滚布局或误报整个审计全绿。

实际平台拒绝保留原文和已有批准，不反复索要同一批准、不换通道绕过。源码问题交控制端CODE，不在ENGINE临时改工具。六要素报告、真实可观测工具/返回体/阶段用量落本attempt；provider不可得null原因。成功SUCCEEDED+PENDING_USER，不代签字体/构图，不放行font guard哈希，不Git提交/推送/合并，不清迁移副本或处理配表。Complete/Fail原样handoff回控制台并结束，后继171/172由控制台派发。
