# PRE-1c [ENGINE_MCP] 231行批准字体材质迁移执行

## AI180工具修复等待点（2026-09-24）

AI179已SUCCEEDED/VERIFIED（CODE范围），其严格内部Prefab保存身份修复保留，不重跑成功前置。AI170 attempt5真实schema6/v3预览已越过旧内部引用错误，但raw231/rows191/unique161、executeAllowed=false：40个TraySlot_01_TUNE～20_TUNE的NameLabel/BadgeLabel出现SOURCE_DRIFT/MATERIAL_GLOBAL_ID，另1条覆盖不足。加载及合法临时卸载两种状态均失败，未诊断/Begin/事务/备份/生产写入；已恢复单ShortCycle Edit clean/Console0。

控制台只读观察：40项当前m_sharedMaterial都是WithFallback默认材质；已核样例的批准SourceHan材质存在但atlas与当前font不同，TMP LoadFontAsset确有此时回落font.material的逻辑。样例为真实Prefab实例，不能由所读override为空推断独立对象。磁盘原引用/批准CSV/生产哈希保持。此为工具修复依据，不代表允许忽略材质漂移或真实Editor迁移成功。

新增依赖AI180 PRE-1c-MATERIAL-RESOLUTION-R1。170保持PAUSED_CIRCUIT，只有180实际成功，控制台核源码、生产共用回归/真实DLL与公开移交后才决定正式Recover。尚未获得恢复票据时不得执行本卡或自行领取。证据位于outputs/U1-PRE-R1/AI-000170/attempt-5-prefab-reference-r1/及outputs/control/U1-PRE-R1-20260923/ai170-attempt5-*.json；180卡PRE-1c-MATERIAL-RESOLUTION-R1_CODE.md。

## 历史、恢复预算与后继方案

AI170五条错误、六条issue、总四次恢复全部保留；当前稳定ProblemKey=pre1_unity6_tmp_material_resolution_drift，本key尚无恢复。此为有独立证据的材质加载解析问题，原pre1_non_target_fingerprint_transient_fileid与EXECUTION别名仍合并稳定身份家族两次恢复（上限3）；全任务总4/上限6继续累计。不得Reset、改key重置或另建迁移任务清预算。attempt1～5目录、计划及失败记录全部保留。

正式恢复后使用独立attempt-6-material-resolution-r1和新sample/full事务，版本按180实际交付，不预填schema/unique。必须由真实Editor观察批准前态、磁盘序列化引用/继承或override、加载后有效引用三者及归属/SHA，逐231行输出证据与normalizationReason。不能拿批准CSV充观察、将所有mismatch接受、改CSV、虚构override或伪造executeAllowed。只有180已实现并经现场证实的精确归一化条件可解释；未知/真实资源或非目标变化仍停止。

保持原FromSourceHan等批准材质风格来源和三份目标材质，不因effective为默认材质改风格或增第4份。双轮重载诊断必须覆盖231行/7资产，引用稳定且有效、0异常；通过才Begin→单真实TMP→完整回退（磁盘引用、override结构、7资源/meta/SHA及独立解释的加载状态）→全量分批。样例回退无法还原精确保存基线时停止，不保存加载归一化覆盖旧基线。所有公开API按180实际移交调用，不用反射private、手写事务或YAML写入绕过。

复用现主Editor/MCP；禁止已打开主工程再起batch、不停止共享Editor/MCP、不自动保存未知用户工作。以下既有执行及机器验收条款继续有效。
## 必读、宿主与边界

先读 .ai-workspace/CORE.md、workers/ENGINE_MCP.md、SUPERVISED.md、UNITY_SCENE_CLEANUP.md、toolkit/LOC.md TK-LOC-03及字体/Editor坑；ENGINEERING_CONVENTIONS.md C1～C4。读两份项目文档页首及Fonts/空间模块。本卡与AI180实际完成后交付的ENGINE-handoff.md共同使用，冲突以本卡的主Editor/场景保护及用户授权为准。

工作区D:/GameProject/Eat-What，codex/unity6-followup，6000.3.24f1。每次MCP使用前发现/选择实例并核Application.dataPath/version、Edit/Play/Compile、各loaded场景dirty和Console。exec_command显式shell=C:/Users/DDJ/.cache/codex-runtimes/codex-primary-runtime/dependencies/native/powershell/pwsh.exe；其内直接 & ./.ai-workspace/queue.ps1，不嵌套Windows5或降低ExecutionPolicy。先正常Refresh/Compile确认AI180实际程序集，不把旧DLL缺成员重报为本根因。

## 真实批准与范围

原批准旁证 .ai-workspace/inputs/U1-PRE_人工反馈与字体批准_20260923.md，映射 .ai-workspace/outputs/control/U1-PRE-20260923/PRE1_字体材质迁移逐项草案.csv，SHA EB0CED01C1BBB0050DCF30BAA3D5354E9F2C7326C3DF97375DE87467D8FE347B。
Lab60旁证 .ai-workspace/inputs/U1-PRE_Lab60_增量批准与接力_20260924.md，映射 .ai-workspace/outputs/control/U1-PRE-R1-20260923/PRE1_Lab60_增量迁移草案.csv，SHA E8AA50B24E3ACA11E55D21F752EB92CD801B83960F443DF12E199DBC1B33A579。
两CSV保持原样，历史PROPOSED_ONLY/PENDING_USER不是缺批准；批准不代表平台回执或最终人审。

- Assets/Scenes/Cooking/ShortCycle_P0P1.unity：原CSV路径+组件序号锁定161 TMP。
- Assets/Prefabs/Cooking/ShortCycle/GridPieces/下 CatalogCard.prefab、FridgeSlot.prefab、IngredientCard.prefab、Sticker.prefab、TraySlot.prefab：各2 TMP。
- Assets/Scenes/ToolTests/FridgeScrollLab.unity：Spaces/FridgeScrollModule/FridgeCat_Group/SlotPool/FridgeSlot_01～30各BadgeLabel/NameLabel组件0，共60 TMP。font原继承、material原override，回退必须还原结构。
- 总raw/逐行coverage231，7资源及meta备份；只改m_fontAsset与配对m_sharedMaterial及必要override。Static GUID9b07c6c50dde09d4b8719754c27ddc96；CoverTitle唯一源字体例外继续有效，单列字形/宽度/换行对比。
- 新资产仅 Assets/Font/Heavy/Materials/ShortCycle_Static_FromSourceHan.mat、ShortCycle_Static_FromLegacyShortCycle.mat、ShortCycle_Static_FromHeavy.mat及meta；Materials目录由AssetDatabase创建。复制原Shader/颜色/描边/Underlay风格，仅_MainTex/_TextureWidth/_TextureHeight/_GradientScale取Static。Lab复用FromSourceHan，不加第4份；同名未知资产不覆盖。
- 保留140wrap，旧30材质override仅映射内可变；其它Prefab/字段/文本/字号/颜色/Transform/布局/Renderer/sorting/交互/Build列表/全局fallback不变。批准范围外传播停止，不扩大工程迁移。

## 真实执行顺序

1. 记录加载场景、活动场景、dirty、保存恢复点、scene/meta及目标字体/材质SHA，保留CoverTitle迁移前同镜头证据。使用公开双映射重载 PreviewApprovedMigration(baseMapping, baseEvidence, supplementalMapping, supplementalEvidence, planPath) 生成AI180实际版本的全新计划（原schema1～6及attempt1～5旧计划/事务不得续用）。真实检查231覆盖/7资源、身份/源传播/三材质/非目标指纹/理由和executeAllowed。
2. 公开 DiagnoseApprovedNonTargetFingerprints(planPath, diagnosticPath) 要求两个批准场景均未loaded。先核所有要关闭的精确场景为clean且无用户未保存成果，再用Editor API暂开本任务拥有的空场景（需要时），仅关闭这两个目标场景，保留其它加载场景。记录原加载布局，try/finally恢复原活动场景和加载状态，清理仅属于本任务的临时空场景。不能SaveScene未知dirty或用MarkSceneClean掩盖。
3. 调用上述公开诊断：五Prefab两次独立加载/卸载、两场景打开关闭两轮；success/stableAcrossReloads/referencesValid=true，rowCount231、approvedAssetCount7、unstableRowCount0，两轮逐行指纹与引用身份一致。引用身份必须有效且非空，不得把不同实例都归空串；核NULL/PERSISTENT/LOCAL_GAME_OBJECT/LOCAL_COMPONENT/UNITY_INTERNAL_PREFAB_INSTANCE与真实对象/保存资产/实例归属对应；内部Prefab reference/owner皆type2、同保存资产GUID，reference.targetObjectId=owner.targetPrefabId且reference.targetPrefabId=0，不得空身份或忽略关系。对照本轮新计划逐行指纹；若不同解释并停止，不手改计划或删断言。核CSV/7资源/meta/SHA未变、Console无新增Error/Exception，并恢复主Editor原布局。恢复后Begin仍会再核现场。
4. 只读诊断通过后，检查点CONTINUE才用公开 BeginApprovedMigration(taskId, baseMapping, baseEvidence, supplementalMapping, supplementalEvidence, planPath, transactionPath)。单FromSourceHan样例明确只改1个真实TMP（approvedRowIdentities.Length==1，不靠Prefab源扩散）。核字体/material/atlas、旧风格及非目标字段；公开RollbackApprovedMigration完整回退，并实核7资源/meta/原引用/继承和override结构、新增资产归属回到保存基线。
5. CreateBackup按taskId复用DevTools/Fonts/backup/AI-000170；原资源仅同SHA复用，不提供任意backupRoot。全量Begin前将样例的7资源/meta、backup-manifest及字体材质指纹/新资产清单按精确清单保全到独立样例快照，记录SHA和事务对应关系，再更新当前manifest；不得无留档覆盖旧manifest/旧资源、递归复制父目录到自身子目录、反射private换路径。回退后不一致停止。
6. 独立全量事务用公开Begin/ApplyApprovedBatch/FinalizeApprovedMigration。实例先于Prefab源，每批checkpoint、scope/备份/停止检查，批后全231行待办/已完成/非目标/外部漂移检查。失败留现场与日志，只有公开API可靠回退；不得伪造executeAllowed、改CSV、手写事务或手改YAML。范围/引用真实变化仍必须拦截。

## 机器验收与保持

完成231行实际引用/atlas配对重审、去重解释、非目标与override一致性。原ShortCycle五视图中文/标题截图、CoverTitle同镜头前后字形/宽度/换行对照，Lab文字可见/双向滚轮/上下界真实验证。Play与Build前后Static SHA不变，DynamicFallback清空，字体manifest始终PENDING_REVIEW，不改Build列表。旧warning与本轮新错误分开记录；最终单目标正常场景Edit clean、Console无新增Error/Exception。所有临时资源/场景恢复按清理规范，不覆盖未知用户修改。

保护AI169布局：P0Left=-9.6，Escape/Return viewport(.06,.08)，唯一ClueBoard持续视觉及P1构图；AI169报告/verification-summary/geometry.csv为保存结果。迁移前ShortCycle SHA233113A72258444BD69C6FD014424435C4D15DD4D1EA9C01A8CF61F13E71BECB、Lab SHA4086672BB61AB57B8D32913922A80BD4708E56A1FF96C8D7CD644EB2857CC02D，实际执行重读；漂移不盲还原。LayoutAudit旧-12.8断言误报已交AI171修源码/172复验，不回滚布局或误报整个审计全绿。

实际平台拒绝保留原文和已有批准，不反复索要同一批准、不换通道绕过。源码问题交控制端CODE，不在ENGINE临时改工具。六要素报告、真实可观测工具/返回体/阶段用量落本attempt；provider不可得null原因。成功SUCCEEDED+PENDING_USER，不代签字体/构图，不放行font guard哈希，不Git提交/推送/合并，不清迁移副本或处理配表。Complete/Fail原样handoff回控制台并结束，后继171/172由控制台派发。



