# PRE-1c [ENGINE_MCP] 231行批准字体材质迁移执行

## AI177完成后的正式恢复接力（2026-09-24）

AI177已SUCCEEDED/VERIFIED；控制台核3源码、2原始CSV、2场景及5Prefab共12哈希全匹配，三新材质仍不存在。真实verify-all-AI-000177.jsonl只有一次Fonts Final、两runner exit0；编译真实Unity6/TMP DLL，231合成覆盖与第二场景失败回退通过。证据 `.ai-workspace/outputs/control/U1-PRE-R1-20260923/ai177-source-baseline-check.json`；报告 `.ai-workspace/outputs/U1-PRE-R1/AI-000177/AI-000177_PRE-1c-LAB60_完成报告.md`。不重跑CODE前置；只恢复当前AI170的真实Editor段。

必须调用AI177新增公开重载：`PreviewApprovedMigration(baseMapping, baseEvidence, supplementalMapping, supplementalEvidence, planPath)`；`BeginApprovedMigration(taskId, baseMapping, baseEvidence, supplementalMapping, supplementalEvidence, planPath, transactionPath)`。两个supplemental参数分别是 `.ai-workspace/outputs/control/U1-PRE-R1-20260923/PRE1_Lab60_增量迁移草案.csv` 和 `.ai-workspace/inputs/U1-PRE_Lab60_增量批准与接力_20260924.md`。原无补表重载只保留171模式，不能误调后又将已批准Lab60报未批准。schema4、raw/row coverage231、approvedAssetPaths7，真实unique和executeAllowed仍待Editor证明。

使用attempt-3-lab60中的独立sample/full事务路径。源码CreateBackup当前按taskId复用DevTools/Fonts/backup/AI-000170，已有资源只允许相同SHA复用、不同则拒绝，不提供任意backupRoot。每次Begin前先检查已有备份归属；全量Begin前将样例的7资源/meta与backup-manifest按精确清单保全到本任务独立样例快照，保存其SHA和与全量事务的对应关系，再允许更新当前manifest；不得无留档覆盖旧manifest、递归复制父目录到自身子目录、覆盖历史资源或用反射/private改备份路径。样例完整回退后若7资源基线不一致，停止并交回，不盲重建备份。

## 当前批准、依赖与恢复
2026-09-24用户已批准Lab60精确增量并继续监管。先读 .ai-workspace/inputs/U1-PRE_Lab60_增量批准与接力_20260924.md、.ai-workspace/inputs/U1-PRE_人工反馈与字体批准_20260923.md。原171行批准有效，本次新增60行只限FridgeScrollLab指定标签；不是全工程迁移或最终人工签收。
新增CODE前置AI177（PRE-1c-LAB60），在AI176基础上补充映射/231行覆盖/7资源事务备份/回退。只有AI177真实SUCCEEDED且控制台审核、正式Recover/新票据后才能执行；不Reset/重用旧票据或旧事务。执行前读AI177实际报告和公开API移交，其离线结果不能代签Editor预检。
使用新输出 .ai-workspace/outputs/U1-PRE-R1/AI-000170/attempt-3-lab60/，样例与全量分别新事务/新备份；后续恢复继续另开attempt，不覆盖旧输出。

## 已核历史
AI170 attempt1的8组CANONICAL_CONFLICT已由AI176修复。attempt2真实Editor为171行/141写入项/30源覆盖行，executeAllowed=false原因是60条UNAPPROVED_PREFAB_PROPAGATION；两轮均未Begin、未生产写入、未创建三份材质。现在补充批准后须重新真实预检，不沿用63/141/171作为新unique数。
保留两条错误、四条issue及第1条恢复；当前ProblemKey=pre1_unapproved_fridgeslot_lab_propagation，原VERIFICATION恢复史不改。旧目录 .ai-workspace/outputs/U1-PRE-R1/AI-000170/attempt-2-prefab-r1/、.ai-workspace/outputs/U1-PRE-R1/AI-000170/approved-plan-before.json 和失败报告均保留。
历史PS7内误套Windows5的票据指纹问题已解决，绝不复用此启动方式。exec_command显式shell=C:/Users/DDJ/.cache/codex-runtimes/codex-primary-runtime/dependencies/native/powershell/pwsh.exe，其内直接 & ./.ai-workspace/queue.ps1；不嵌套powershell.exe、不降低ExecutionPolicy。

## 必读与目标
.ai-workspace/CORE.md、.ai-workspace/workers/ENGINE_MCP.md、.ai-workspace/SUPERVISED.md、.ai-workspace/UNITY_SCENE_CLEANUP.md；.ai-workspace/toolkit/LOC.md TK-LOC-03及字体/Editor坑；.ai-workspace/ENGINEERING_CONVENTIONS.md C1～C4：现有世界Sprite/MouseInteract架构、层级与资源引用保持。读CODEBASE_MAP.md和项目整体阅读理解与推进基线_2026-08-14.md页首/Fonts/空间模块。工作区D:/GameProject/Eat-What，codex/unity6-followup，6000.3.24f1；每次MCP使用前发现选择实例并核Application.dataPath/version、Editor/脏场景/编译/Console。

## 用户授权表
| 路径 | 允许范围 | 备份及保持 |
| --- | --- | --- |
| Assets/Scenes/Cooking/ShortCycle_P0P1.unity | 原CSV按对象路径+组件序号锁定的161个TMP，配对m_fontAsset/m_sharedMaterial | 原171 CSV SHA EB0CED01C1BBB0050DCF30BAA3D5354E9F2C7326C3DF97375DE87467D8FE347B不改；scene/meta进入新事务备份 |
| Assets/Prefabs/Cooking/ShortCycle/GridPieces/CatalogCard.prefab、FridgeSlot.prefab、IngredientCard.prefab、Sticker.prefab、TraySlot.prefab | 各2个TMP相同两字段，仅原批准10行 | 五Prefab/meta备份，其它Prefab源不写 |
| Assets/Scenes/ToolTests/FridgeScrollLab.unity | Spaces/FridgeScrollModule/FridgeCat_Group/SlotPool/FridgeSlot_01～30下BadgeLabel/NameLabel组件0，共60，字体+配对材质及必要override | 补充CSV SHA E8AA50B24E3ACA11E55D21F752EB92CD801B83960F443DF12E199DBC1B33A579；Lab/meta备份，原font继承和material override完整回退 |
| Assets/Font/Heavy/Materials/ShortCycle_Static_FromSourceHan.mat、ShortCycle_Static_FromLegacyShortCycle.mat、ShortCycle_Static_FromHeavy.mat及meta | 原已批准3份材质；AssetDatabase建立Materials目录，复制对应原材质风格，仅_MainTex/_TextureWidth/_TextureHeight/_GradientScale取Static | 字体/材质指纹、新资产清单归属；同名未知资产不覆盖；Lab复用FromSourceHan，不新增第4份 |

两个原始输入具体路径见上述批准文件；独立解析并绑定批准，不改CSV内历史PROPOSED_ONLY/PENDING_USER。总raw及逐行coverage=231（171+60），uniqueEntryCount由真实Editor输出并解释每行源/实例覆盖。Static GUID=9b07c6c50dde09d4b8719754c27ddc96；CoverTitle可切Static但需单列字形/宽度/换行对照。Lab原font GUID75909fc3d0fa2c94baa5706654d37655继承，material GUID53ffd732c8bc2034f93d5a714c25eda2/fileID -5877652104868683785是override，配对改至Static+FromSourceHan。原140wrap保留，30材质override仅映射内可变。
7资源及meta、旧新字体材质指纹、非目标字段、原override结构和新增资产清单统一在DevTools/Fonts/backup/AI-000170/本恢复批次由公开API备份；不覆盖任何旧事务/备份。

## 真实执行顺序
1. 只读预检所有231行/7资产、批准哈希、before/after、实际身份/源关系、未批准传播、非目标指纹，输出完整reasons和executeAllowed。只有真实通过才Begin；不反射private/伪造executeAllowed/手改事务或YAML。任何新增其它场景/对象/字段受影响，列差异停止；不可依据本增量再拓范围。
2. 单FromSourceHan样例明确只改1个真实TMP，不靠Prefab源扩散。验证字体、材质atlas和旧风格/非目标字段，执行公开Rollback，再实核引用及继承/override结构、7资源/新增资产归属，确认完整回到保存基线；然后另起全量事务。
3. 全量使用公开BeginApprovedMigration/ApplyApprovedBatch/FinalizeApprovedMigration及AI177批准补充映射入口。按真实计划要求实例先于Prefab源，每批前checkpoint、scope/备份/停止检查，批后全行待办/已完成/非目标/外部漂移检查；批次恢复幂等，失败留现场与日志并按公开API可靠回退，不部分写入后假报成功。
4. 所有暂开场景恢复原Editor布局/活动场景，不能覆盖用户未知未保存成果；流水线自身可归属的临时dirty按清理规范自主恢复，不以MarkSceneClean掩盖。

## 机器验收与保持
231行重预览与覆盖/去重解释；两个场景和五Prefab atlas配对、原风格和非目标字段/override一致；新Console Error/Exception=0，最终Edit clean。原ShortCycle五视图中文/标题截图、CoverTitle同镜头前后字形/宽度/换行测量保留；Lab额外文字可见、双向滚轮与上下界真实验证。Play与Build前后Static SHA不变，DynamicFallback清空，manifest始终PENDING_REVIEW，不改Build列表。旧warning与当前新增异常区分记录，不称全部历史Console为0。
保护AI169保存布局：P0Left=-9.6、Escape/Return viewport=(.06,.08)、唯一ClueBoard持续视觉、P1构图。读 .ai-workspace/outputs/U1-PRE-R1/AI-000169/AI-000169_FIX-T5-R1b_完成报告.md、verification-summary.json、geometry.csv。当前迁移前ShortCycle SHA233113A72258444BD69C6FD014424435C4D15DD4D1EA9C01A8CF61F13E71BECB、Lab SHA4086672BB61AB57B8D32913922A80BD4708E56A1FF96C8D7CD644EB2857CC02D，执行前重读，漂移解释不盲还原。
LayoutAudit旧fixT5FourMarkers仍以-12.8误报，已交AI171修源码/AI172实测；本卡不回滚布局、不静默取消有效断言，不将此已知诊断写成全绿。
保留旧字体/材质、全局fallback、所有布局/Transform/文本/字号/颜色/sorting/Renderer/交互/滚轮/Modal和无关override。字体工具代码问题交控制端CODE修复，不绕过检查。任何实际平台拒绝留批准及原文，不能误称用户未批、不能换通道绕过。
六要素报告、真实工具/返回体/阶段计量落本attempt，provider不可得null原因；成功SUCCEEDED+PENDING_USER，不代签字体或构图人审、不放行字体guard哈希、不Git提交/推送/合并、不清理迁移副本。Complete/Fail原样handoff回控制台后结束，后继AI171→AI172由控制台派发。
