# PRE-1：FridgeScrollLab 60 个标签增量迁移审批草案

日期：2026-09-24。状态：PENDING_USER，仅草案，未执行。原171行批准继续有效；本次请求只涉及新发现的Lab范围。

## 已核事实与建议

AI170 attempt2 的真实Editor预检已消除旧8组归并冲突：171行、141个真实写入项、30行由Prefab源覆盖。现在的阻断是FridgeSlot源字体会传播到滚轮Lab的30个实例，每个BadgeLabel和NameLabel各1个TMP，共60个标签。这不是60个新Prefab，也不是用户已经批准的171行之一。

控制台只读核对Lab及Prefab的序列化内容，与Editor传播清单逐对象交叉核对：60个标签均继承旧字体ShortCycle_Heavy_WithFallback；60个共享材质均有SourceHan材质override。因此不建议仅允许字体传播后保留旧atlas材质。建议把这60个TMP的字体及配对材质作为精确增量纳入同一受控迁移，使Lab跟随正式工具的字体策略并保留原材质风格。

逐项清单：[PRE1_Lab60_增量迁移草案.csv](PRE1_Lab60_增量迁移草案.csv)。此表60行，每行明确对象路径、组件序号、源组件fileID、旧字体/材质、目标及PENDING_USER；不是可直接执行的原CSV替代品。

## 请求批准的精确范围

| 项目 | 范围 |
|---|---|
| 新增场景范围 | Assets/Scenes/ToolTests/FridgeScrollLab.unity |
| 对象 | Spaces/FridgeScrollModule/FridgeCat_Group/SlotPool/FridgeSlot_01～FridgeSlot_30 下的 BadgeLabel、NameLabel |
| 组件 | 各对象第0个TMP组件，共60个 |
| 允许字段 | m_fontAsset及配对m_sharedMaterial；允许Editor为这些字段生成必要的Prefab override，回退必须恢复原继承结构 |
| 原字体 | GUID 75909fc3d0fa2c94baa5706654d37655，ShortCycle_Heavy_WithFallback，当前为继承 |
| 原材质 | GUID 53ffd732c8bc2034f93d5a714c25eda2，fileID -5877652104868683785，SourceHanSansSC-Heavy SDF内材质，当前有override |
| 目标字体 | ShortCycle_Heavy_Static，GUID 9b07c6c50dde09d4b8719754c27ddc96 |
| 目标材质 | Assets/Font/Heavy/Materials/ShortCycle_Static_FromSourceHan.mat，复用原已批准三份中的一份，不新增第四份 |
| 总批准行覆盖 | 原171行加本增量60行，共231行；真实唯一写入数必须重新由Editor给出，不预设为231 |
| 保持项 | 滚轮输入、方向、范围、上下界、层级/Transform、视觉颜色/字号/文本、Renderer、非目标override、其它Lab对象、全局字体设置和Build场景列表不变 |

原171行CSV SHA：EB0CED01C1BBB0050DCF30BAA3D5354E9F2C7326C3DF97375DE87467D8FE347B，继续不可改写。Lab当前SHA：4086672BB61AB57B8D32913922A80BD4708E56A1FF96C8D7CD644EB2857CC02D；meta SHA：A80079CA142FB9CEBC0E76D95BC097D164C670A7D1239DCAE4DE694FA036E32D。完整核对：[ai170-lab-scope-inspection.json](ai170-lab-scope-inspection.json)。执行前重新Editor核实；来源内容漂移不得静默适配到新范围。

## 批准后的编排草案

1. CODE扩充现有TK-LOC-03工具：保留原171输入及哈希，以单独、批准绑定的60行补充映射承载增量；合法总覆盖变为231，允许资产从6扩为7（增加Lab）。所有白名单、备份、非目标指纹、传播守卫、实例/源顺序、事务覆盖和回退同步处理；不能只删除固定数量断言或关闭守卫。回归验证增量外的传播仍拒绝、原171输入未改、单样例仍只改1个TMP、跨两个场景回退恢复继承与材质。
2. 该CODE任务成功并核实后，作为AI170新增依赖，通过正式Recover保留原任务/两条错误/恢复史。使用新attempt目录、独立样例与全量事务。先真实Editor预检覆盖231行，再单FromSourceHan样例→回退→正式分批，按实际源传播顺序执行。
3. 除原六份场景/Prefab及meta、字体材质指纹、新增资产清单外，备份Lab与meta至DevTools/Fonts/backup/AI-000170/对应恢复批次归属；旧备份不覆盖，目录策略由现有API实现并记录。
4. 迁移后机器检查两个场景和5个Prefab的字体/atlas配对、非目标字段、Static SHA、Dynamic清空、Console/clean；在Lab额外验证文字、双向滚轮与上下界。原正式场景五视图、CoverTitle对比、Play/Build要求保留。
5. 成功后继续AI171→AI172；最终视觉审查后置，不新增开发中途视觉签收。本批准不包含Git提交、推送、合并或删除迁移副本。

失败保持现场与证据；仅按经过验证的公开Editor API回退本事务拥有的目标引用/override及新增材质，不手改YAML、不恢复覆盖他人改动。若新增其它场景/Prefab/字段受影响，仍停止并列差异，不把本次60行批准推广成全工程迁移。

## 可直接回复的决定

推荐批准：“批准PRE1 Lab60增量草案：FridgeScrollLab指定60个TMP的字体及配对材质迁移，按草案补齐工具、备份和回归，原171批准保持不变，继续监管。”

若希望Lab保留旧字体，需另选隔离方案；隔离会新增资源或override，不应在本次171行授权下自动执行。当前没有修改任何Lab资产或创建该后继任务。
