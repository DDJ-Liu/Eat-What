# 待人工验收清单

> 此文件由 `queue.ps1 -Action PendingReview` 确定性生成。请勿手工修改；以队列运行时状态为准。

## 汇总

- 待验（PENDING_USER）：4
- 已驳回（REJECTED）：1
- 合计：5

## CODE | 目标线程 01a01316-9760-7911-a5d6-ac155907dddb

### 待验（PENDING_USER）

#### AI-000174 | [DATA-VIS-1] 建立可见 DATA 正式执行路由与长期配表分工
- ModuleId：DATA-VIS-1
- 验收状态：PENDING_USER
- 完成摘要：已建立可见 DATA 正式路由 API、原子审计与 route-key 防串线，统一 MANUAL/AUTOMATIC/SUPERVISED/轮次返回；旧 worker/租约/熔断/锁保持，生产绑定未执行。
- 验证证据：Workflow Final 必要第二次 6/6 runner 通过：WorkflowModes、Supervised 135、QueueReview/Modules、DataLane 89、Usage 13、DocumentationIndex 全绿；隔离夹具确认生产 queue/worker/mode/INSTRUCTIONS 哈希不变。生产 DataLaneStatus 收尾为 IDLE、bound=false、safeToBind=true、externalReachabilityVerified=false；未运行 Unity/MCP/batch，未改 CSV 或序列化资源。首次 DocumentationIndex 活动台账误报已登记 TEST_OBSERVATION 并以追加前缀契约修复。
- 产物路径：
  - .ai-workspace/queue.ps1
  - .ai-workspace/supervised.ps1
  - .ai-workspace/tests/Test-DataLane.ps1
  - DevTools/Workflow/Invoke-TaskTool.ps1
  - DevTools/Workflow/Test-DocumentationIndex.ps1
  - .ai-workspace/outputs/DATA-VISIBLE/AI-000174/AI-000174_DATA-VIS-1_完成报告.md
- 人工复核步骤：
  1. Workflow Final 中 DataLane(89)、Supervised(135)、WorkflowModes、UsageMetrics 均通过；Test-DocumentationIndex 将活跃队列台账 INSTRUCTIONS.md 与历史瘦身基线比较，报 Root document reduction 14.94%/active ledger overwritten。当前台账因监管任务合法追加而持续变化；未回滚或改写生产状态，按任务卡视为活跃队列下的测试观察，使用夹具生产哈希不变断言作为本卡路由验证证据。
- 通过回复：验收通过 AI-000174：<备注>
- 不通过回复：验收不通过 AI-000174：<原因>

### ⚠ 已驳回（REJECTED）

_无_

## ENGINE_MCP | 目标线程 01a01316-2d47-7861-9012-5ab5d3fd8458

### 待验（PENDING_USER）

#### AI-000162 | [PRE-1] 双字体资产生成、正式场景引用迁移和画面回归
- ModuleId：PRE-1
- 验收状态：PENDING_USER
- 完成摘要：已通过 Unity 6000.3.24f1 生成并幂等验证 ShortCycle Static/空 DynamicFallback 双字体，修复生成器在 Unity 6/TMP 下的控制字符、source 引用和序列化兼容问题；完成场景 Spaces 与 5 个引用 Prefab 的 171 项真实预览。因 171/171 共享材质 atlas 不兼容（CoverTitle 另有 source font 差异），按任务边界未执行 m_fontAsset 迁移、未扩写材质、未保存场景或 Prefab，已输出逐对象审批清单。
- 验证证据：Verify-All Fonts Final 通过（1/1 runner，27 静态断言，27/27 guard，Unity/TMP 实际 DLL 编译 66048 bytes）；Unity Console 0 Error；Static GUID 9b07c6c50dde09d4b8719754c27ddc96 / SHA E877950344A043B02BE025B7C2E12E2889E9EC69D20E72A3C90785F5B8EE1220，Dynamic GUID fc95b2390c022e443b26b9c50a865c8d / 0 character/glyph；manifest PENDING_REVIEW；场景未脏且 SHA 与备份一致，30/140/0 override 基线保留。迁移预览 executeAllowed=false，171/171 材质不兼容，故新字体 Play/Build 画面回归需用户审定材质/atlas 方案后继续；本任务应为 PENDING_USER。
- 产物路径：
  - Assets/Font/Heavy/ShortCycle_Heavy_Static.asset
  - Assets/Font/Heavy/ShortCycle_Heavy_Static.asset.meta
  - Assets/Font/Heavy/ShortCycle_Heavy_DynamicFallback.asset
  - Assets/Font/Heavy/ShortCycle_Heavy_DynamicFallback.asset.meta
  - DevTools/Fonts/ShortCycleFontBuildManifest.json
  - Assets/Editor/Fonts/ShortCycleFontAtlasBuilder.cs
  - DevTools/Fonts/README.md
  - .ai-workspace/outputs/U1-PRE/AI-000162/font-swap-preview.json
  - .ai-workspace/outputs/U1-PRE/AI-000162/AI-000162_PRE-1_双字体生成与迁移预检报告.md
  - DevTools/Fonts/backup/PRE-1/
- 人工复核步骤：
  1. 双字体资产生成与结构验证通过，但全量预览 171/171 项均因共享材质 atlas 不兼容而 executeAllowed=false，CoverTitle 另有 source font 差异。按任务边界未扩大材质写入、未迁移场景/Prefab，因此新字体的全视图 Play/Build 画面回归必须等人工审定材质/atlas 迁移方案后执行；逐对象清单见 .ai-workspace/outputs/U1-PRE/AI-000162/font-swap-preview.json。
- 通过回复：验收通过 AI-000162：<备注>
- 不通过回复：验收不通过 AI-000162：<原因>

#### AI-000165 | [FIX-T5-G69-R1] ④左页保留压暗与板外返回的场景修复验证
- ModuleId：FIX-T5-G69-R1
- 验收状态：PENDING_USER
- 完成摘要：修复 ShortCycle_P0P1 的④线索板态：保留 Browse/书页结构并增加左页区域压暗与板外返回 Guard；未改运行时代码、Prefab、字体、材质、ProjectSettings 或 meta。
- 验证证据：Unity 6000.3.24f1 Refresh/Compile 成功；LayoutAudit 关键断言通过、missing scripts=0、Console Error/Exception/Assert=0。Play 验证①↔④保持 P0Left 且零 Pan，真实 MouseManager.RaycastPressable 在 StartCooking 坐标优先命中 OutsideClose_HitArea，点击与 Esc 均仅返回 Browse且不穿透；完整 Browse→P1→Browse→Catalog→Cover 回归通过。最终 Edit Mode 稳定、场景未脏，diff 为333 insertions/0 deletions，meta SHA及AI-000154 override计数保持。两张PNG签名/哈希/本地视觉读取通过；压暗强度与构图需用户人工确认。
- 产物路径：
  - Assets/Scenes/Cooking/ShortCycle_P0P1.unity
  - DevTools/Scenes/backup/AI-000165/ShortCycle_P0P1.unity
  - DevTools/Scenes/backup/AI-000165/ShortCycle_P0P1.unity.meta
  - .ai-workspace/outputs/U1-PRE/AI-000165/screenshots/01_Browse.png
  - .ai-workspace/outputs/U1-PRE/AI-000165/screenshots/04_ClueBoardShell.png
  - .ai-workspace/outputs/U1-PRE/AI-000165/AI-000165_FIX-T5-G69-R1_④左页压暗与板外返回报告.md
- 人工复核步骤：
  1. 需用户人工复核 01_Browse.png 与 04_ClueBoardShell.png 的压暗强度、构图和视觉观感；机器验证已确认同机位、书页仍可见、交互不穿透。
- 通过回复：验收通过 AI-000165：<备注>
- 不通过回复：验收不通过 AI-000165：<原因>

#### AI-000169 | [FIX-T5-R1b] 连续空间构图、返回键锚定与P1画面恢复
- ModuleId：FIX-T5-R1b
- 验收状态：PENDING_USER
- 完成摘要：完成 FIX-T5-R1b：连续空间构图、双返回键视口锚定、Shared线索板跨空间保活与P1构图恢复；清理本轮Unity保存产生的字体override漂移并保留140 wrap/30材质基线。文档影响：无项目级入口变化，新增任务证据报告。工具登记影响：复用既有TK，无新增。
- 验证证据：Unity 6000.3.24f1 Refresh/Compile完成；LayoutAudit missingScripts=0、anchors=2/invalid=0、Clue持久视觉=true、冰箱槽30/30唯一；Play两轮P0-P1-P0、Clue/StepDetail Modal、六层滚动0-5-0通过，frame/unscaledTime推进且timeScale=1；Console Error=0，最终Edit Mode且scene clean。场景SHA=233113A72258444BD69C6FD014424435C4D15DD4D1EA9C01A8CF61F13E71BECB，meta不变；基线140 wrap/30 sharedMaterial及材质GUID计数保持。7张PNG签名/SHA/本地视觉检查通过。16:9/4:3最终构图与压暗强度待用户人工确认，故PENDING_USER。
- 产物路径：
  - .ai-workspace/outputs/U1-PRE-R1/AI-000169/AI-000169_FIX-T5-R1b_完成报告.md
  - .ai-workspace/outputs/U1-PRE-R1/AI-000169/verification-summary.json
  - .ai-workspace/outputs/U1-PRE-R1/AI-000169/geometry.csv
  - .ai-workspace/outputs/U1-PRE-R1/AI-000169/screenshots
  - DevTools/Scenes/backup/AI-000169
  - Assets/Scenes/Cooking/ShortCycle_P0P1.unity
  - Assets/Scripts/Tools/Layout/CameraViewportAnchor.cs
- 人工复核步骤：
  1. 机器验证已完成；仍需用户人工确认 16:9/4:3 Browse 与 P1 构图、全书约66.88%和右页约33.76%的观感、猫/板/托盘比例及ClueBoard压暗强度。证据见 .ai-workspace/outputs/U1-PRE-R1/AI-000169/screenshots/ 与完成报告；不得由机器代签。
- 通过回复：验收通过 AI-000169：<备注>
- 不通过回复：验收不通过 AI-000169：<原因>

### ⚠ 已驳回（REJECTED）

#### AI-000156 | [FIX-T5] 正式场景四区空间重排与④命中区接入
- ModuleId：FIX-T5
- 验收状态：REJECTED
- 完成摘要：完成 FIX-T5 四区空间重排、P0Left/P1 镜头路由、线索板双锚点、P1 Kitchen/Tray bounds 定位、真实 ClueBoard_HitArea 接入与旧按钮退役；补充只读 LayoutAudit 断言。AI-000154 的 30 材质/140 换行基线和 Modal 业务接线均保留，字体/meta/GUID 未变。文档影响：无项目级入口变化；新增本任务六要素与坐标/截图报告。工具登记影响：仅复用 TK-INT-03、TK-MOT-06、TK-DBG-06、TK-DBG-04，无新工具编号。
- 验证证据：Unity 6000.3.24f1 Refresh/Compile 完成；Console Error/Exception/Assert=0；LayoutAudit FIX-T5 四项断言全 True，Heavy 目标 208/208 Renderer enabled、Missing=0；完整 Play 流程及锁定/释放通过，PanStarted 精确 4 次；真实 Physics2D 命中只返回 ClueBoard_HitArea，④无 Pan 且 Browse 交互禁用，Esc/Return 栈与 Kitchen 构图通过；5 张 1280x720 PNG 已逐张视觉检查并记录 SHA；最终 Edit Mode、场景 clean、临时资产/运行时计数器已清理。场景 SHA=3B474E9AC69703A124E1E871DEEAB2C8A448BB6852D8090469A5051A7BEBC143；scene meta、Heavy font/meta SHA 与基线一致；AI154 override 计数为 30/140/0，场景差异无 TMP/材质字段。④右半区为空暗背景与既有 CoverTitle 字体边界已登记 TEST_OBSERVATION，完整人工路径已登记 MANUAL_VERIFICATION，故按协议为 PENDING_USER。
- 产物路径：
  - Assets/Scenes/Cooking/ShortCycle_P0P1.unity
  - Assets/Editor/ShortCycle/ShortCycleLayoutAudit.cs
  - DevTools/Scenes/backup/FIX-T5b_ShortCycle_P0P1.unity
  - .ai-workspace/outputs/U1-PRE/AI-000156/AI-000156_FIX-T5_四区空间与命中区报告.md
  - .ai-workspace/outputs/U1-PRE/AI-000156/screenshots/01_Cover.png
  - .ai-workspace/outputs/U1-PRE/AI-000156/screenshots/02_Catalog.png
  - .ai-workspace/outputs/U1-PRE/AI-000156/screenshots/03_Browse.png
  - .ai-workspace/outputs/U1-PRE/AI-000156/screenshots/04_ClueBoardShell.png
  - .ai-workspace/outputs/U1-PRE/AI-000156/screenshots/05_Kitchen.png
- 人工复核步骤：
  1. ShortCycleLayoutAudit 的 FIX-T5 新断言均为 True，目标 Heavy TMP 为 208/208 Renderer 已启用、缺失 0、禁用 0；但总 kTakeoverValid 仍因既有 CoverTitle 使用 Heavy SDF 而为 False。该字体范围属于 PRE-1，AI-000156 未修改字体资产，需人工按既有 PRE-1 边界复核，不阻断本任务。
  2. ④ ClueBoardShell 运行截图与状态/命中验证均通过：真实 ClueBoard_HitArea 唯一命中，Browse Set 与旧按钮已禁用，Esc 返回与相机槽正确；但截图右半区表现为空暗背景，而非可明确辨识的书页变暗效果。该纯视觉判断交由用户查看 04_ClueBoardShell.png 人工确认，不再自动改场景。
  3. 请在 Unity 6000.3.24f1 打开 ShortCycle_P0P1，按 Cover→OpenCover→SelectRecipe→点击线索板→Esc→StartCooking→Return→Esc→Esc 路径人工复核：四区构图、P0Left/P1 平滑移动、④遮罩/变暗观感、线索板区域只触发一次且不穿透、Esc 返回栈、Kitchen 冰箱/托盘/线索板同时可见。对照 01_Cover.png 至 05_Kitchen.png；自动证据 PanStarted 精确 4 次、Console 0 Error/Exception/Assert、场景 clean。
- 通过回复：验收通过 AI-000156：<备注>
- 不通过回复：验收不通过 AI-000156：<原因>

## DATA | 目标线程 01a0ce9d-8e5a-7542-82b6-6d27609d99e0

### 待验（PENDING_USER）

_无_

### ⚠ 已驳回（REJECTED）

_无_

## ART_AIGC | 目标线程 01a01316-d3fa-7af3-a5e5-25fa0ed5dfb8

### 待验（PENDING_USER）

_无_

### ⚠ 已驳回（REJECTED）

_无_

## ART_ASSET | 目标线程 01a07f70-c76d-72c3-8ad4-08dc6ec14538

### 待验（PENDING_USER）

_无_

### ⚠ 已驳回（REJECTED）

_无_
