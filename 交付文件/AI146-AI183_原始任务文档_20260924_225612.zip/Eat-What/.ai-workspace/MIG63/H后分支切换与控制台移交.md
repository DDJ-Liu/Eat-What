# H 后分支切换与主控制台移交

核对日期：2026-09-22。依据：用户本轮明确要求当前成果合入main，关闭并删除原2022内容开发分支，从新main建立后续开发分支，F及E2交主控制台管理。此决定覆盖旧迁移计划的分支保留规则和管理端建议的“继续在旧content上开发”。

## 当前开发规则

- 存续工作区：`D:/GameProject/Eat-What`，固定Unity `6000.3.24f1`。禁止用2022打开升级后目录。
- 本次main接收原content的全部成果，包括`358173f`、格式专用提交`b1e2ce4`、H记录`3e91c8f`及本轮管理交接文档。main只快进集成，不直接开发。
- 旧`content/p0p1-layout`在提交全部可从main到达后删除本地和远端引用。旧提交仍在main历史和H异盘备份中。
- 新开发分支为`codex/unity6-followup`，直接从本次集成后的main创建，建立同名origin跟踪。F开发、后续验收补修和E2收尾均在此分支完成；用户已授权在E2完整关闭时再次集成main，此前不自行安排中途合并。
- `unity6.3-baseline`继续固定E1人工验收点`37bb854`，不随main移动。`backup/pre-unity6-20260920`和`pre-unity6-baseline`保持`ec3aa7c`；`migration/unity-6.3`仍保留`37bb854`，`DDJ_260817`不在删除范围。
- `D:/GameProject/Eat-What-U6`只作为F前后对照和E2待归档副本，不承接新业务。分支删除与副本清理分开处理。

分支操作前后SHA、远端检查和哈希证据存放`.ai-workspace/outputs/control/MIG63_执行_20260921/Handoff-Control/`。资产树在本轮不变，旧content删除前核对main包含其全部提交；远端更新使用原子推送和期望旧SHA校验。新clone先安装Git LFS并拉取对象；本地被忽略的TMP可能被版本库文件覆盖，应先保全后核对。

## 主控制台接手

接收任务：**AI工作流-控制台（接管）**，ID `01a08798-8b2a-7d41-9aa8-ab44affd520a`。

2026-09-22 后续决定：145项历史及下一编号146保留；用户已选择 F-α（MIG-F04 → MIG-F01 → A0 → A1）并要求 AUTOMATIC。旧定时领取保持暂停、独立美术日审不变；精确范围见 `inputs/F-alpha_任务精确范围_20260922.md`。最终“13步驱动器 + 滚轮手感 + 导表结果”仍由用户一次验收，MIG-F09不并入F。

H已解除代码冻结、双工作区路由标记和独占文件分区；不再要求每条业务指令带`[WS:CONTENT]`/`[WS:MIG]`。派发仍必须写明真实工作区、分支及固定引擎版本，操作Unity前核实实例路径、场景与编译/Play状态。main/backup禁止直接提交、字体保护、G26和资源安全规则继续有效。

F验收后主控制台组织E2：证据归档及恢复验证、长期工具按功能改名并保留GUID/能力、解除迁移专用配置、核准副本绝对路径后清理。E2是否删除本地Spine Examples先由用户决定。E2完整关闭后的成果再集成main；不提前宣告迁移行政关闭。

## 管理端新增事项

| ID | 事项 | 边界与验收 |
| --- | --- | --- |
| MIG-F08 | 文本资产保护改用Git规范化内容 | 接受为工具改进待办，本轮不改工具。比较基线blob、index与经当前`.gitattributes`/clean规则规范化的工作树内容，不能只比较HEAD/index而漏检未暂存变更；保留原始SHA作同机备份完整性证据。测试LF/CRLF等价、真实字段变化必拦、未暂存变化、缺失文件；不全仓重写行尾。LFS文件使用内容OID/SHA，不能把指针blob当实际字体字节。 |
| MIG-F09 | 固定主字体与动态回退分离 | 待用户设计决定，文案批量录入前解决。本轮不改变D-G的216字形基线或放行字体SHA。方案需保留材质/GUID/回退链和视觉表现，验证新增中文、重入、构建、全新clone及缺字。动态回退配置、源字体和GUID仍需可恢复，“不锁动态图集SHA”不等于忽略整个资产；同时明确缓存提交与清理规则。 |
| MIG-F10 | 本地Spine Examples的去留 | E2待用户决定；612文件有写前备份，H后32文件有差异留档。迁移副本无需它们能完成验证是当前依赖证据，删除前仍须重新查引用、默认程序集影响和保留的Spine预研。未授权删除该目录；Tomato及两处业务预研不在此清理建议内。 |

MIG-F01～07沿用[E1/H记录](E1H_接棒与后续项.md)。其中 MIG-F01、MIG-F04 已纳入用户批准的 F-α 精确范围；字体、Spine清理及其它挂起项没有随之获得写入授权。

当前UGUI/TMP源码提供`Clear Dynamic Data On Build`，构建前处理在`TMP_PreBuildProcessor`，退出Editor也有清理回调；这是清理时点，不是日常Play不会写回的保证。现有`.gitattributes`对`Assets/Font/**/*.asset`设置LFS与`-text`，字体保护保持内容SHA，不能一起换成指针blob。

## 两份常驻规范与设计总档

- `KNOWN_PITFALLS.md`：复核P-001/P-036/P-038涉及的当前版本假设；保留2022故障历史，将现行API核对目标改为ProjectVersion的6000.3.24f1。依据本机UnityEditor.xml、现有导入器/CameraFrameGizmoMenu源码及H真实编译证据，本轮未重新运行Editor。
- `ENGINEERING_CONVENTIONS.md`：没有2022专用API条款；C1～C8/A1～A11架构约束保留。新增当前环境与程序集事实核验说明，不宣布未完成的业务asmdef分层。业务主要位于Assembly-CSharp/Assembly-CSharp-Editor，现有asmdef为第三方资产。
- 设计总档v1.5存放`.ai-workspace/design/AI开发工作流总档_设计端_v1_5.md`，由Downloads的v1.4生成，保留输入原件及SHA。移除双工作区管理节和迁移必读项，G47/G48/G49/G52/G53失效，G54保留到E2，更新当前分支/版本/Build和待办。读取到的v1.4未实际写出asmdef分层，v1.5明确补上事实，未虚构一次源码架构重构。
- 设计端会话/云端文档本轮没有直接写入；该文件交用户带回设计端。E2后再出v1.6记录关闭与归档。

文档影响：更新AGENTS、项目基线、CODEBASE_MAP、控制台/工作流入口、坑账本与惯例核验注记。没有运行时代码、场景、字体或配置参数变化，无新增视觉组件使用说明要求。
