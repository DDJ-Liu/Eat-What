# 配表 Excel / CSV 双入口

最后核对：2026-09-22；范围：14 份 schema、当前权威 CSV、共享 `Validate-DataTables.ps1`，未进入 Unity。

本目录提供 `TK-DAT-07` 配表往返工具。Excel 与直接编辑 CSV 两条路径最终都调用同一份项目校验器；这里不复制 V-01～V-12，也不导入或改写 Unity 资产。Unity `Import All` 仍由后续 ENGINE 任务执行。

## 运行依赖

工具只使用 Codex 桌面随附的 Node.js 与 `@oai/artifact-tool`，不会联网或静默安装包。默认从 `%USERPROFILE%/.cache/codex-runtimes/codex-primary-runtime/dependencies/node/` 定位；若运行时位于别处，可设置：

- `CODEX_ARTIFACT_NODE`：`node.exe` 的绝对路径；
- `CODEX_ARTIFACT_NODE_MODULES`：包含 `@oai/artifact-tool` 的 `node_modules` 绝对路径。

脚本运行期间会在本目录临时建立 `node_modules` 目录联接，结束后删除；若该路径已有非本工具内容，脚本会拒绝覆盖。

## Excel 入口

1. 从当前 CSV 生成或刷新工作簿：

   ```powershell
   powershell -NoProfile -ExecutionPolicy Bypass -File DevTools/DataTables/Authoring/Import-CsvToAuthoring.ps1
   ```

2. 编辑 `DataTables_Authoring.xlsx`。每个 schema 对应一个 sheet：首行冻结；橙色表头表示必填；单值引用提供下拉；无效单值/列表引用使用红色条件格式；表头批注说明类型、引用目标和列表分隔符。`KitchenAreas.containerTags`、`preset_tools` 使用 `|`，其余正式列表字段按 schema 使用 `;`。
3. 导出到隔离目录并自动校验：

   ```powershell
   powershell -NoProfile -ExecutionPolicy Bypass -File DevTools/DataTables/Authoring/Export-AuthoringToCsv.ps1 `
     -InputWorkbook DevTools/DataTables/Authoring/DataTables_Authoring.xlsx `
     -OutputRoot C:/Temp/EatWhat-DataTables
   ```

确认差异后，才由内容流程决定是否以该输出更新权威 CSV。导出固定为 UTF-8 无 BOM + CRLF。只有表头、没有数据的空 sheet 会被跳过，目标目录中同名 CSV 不会被覆盖。

## 直接 CSV 入口

直接编辑 `DataTables/` 后运行：

```powershell
powershell -NoProfile -ExecutionPolicy Bypass -File DevTools/DataTables/Authoring/Invoke-DataTableAuthoring.ps1 -Mode Csv
```

该入口先调用共享校验器的 `-Quick` 模式，再从通过校验的 CSV 刷新工作簿。`-Quick` 不省略规则，只输出错误/警告摘要与 slot 引用、孤儿本地化、步骤链、白名单覆盖四类核心报告路径。若仅想校验：

```powershell
powershell -NoProfile -ExecutionPolicy Bypass -File DevTools/DataTables/Validate-DataTables.ps1 -Quick
```

需要带 BOM 的 CSV 仅可另存到工程外用于本地查看，不能回写权威源。

## 一键 Excel 导出

```powershell
powershell -NoProfile -ExecutionPolicy Bypass -File DevTools/DataTables/Authoring/Invoke-DataTableAuthoring.ps1 `
  -Mode Excel -OutputRoot C:/Temp/EatWhat-DataTables
```

Excel 路径与 CSV 路径均使用 `Validate-DataTables.ps1`；通过只是编辑器外数据门，不等同于 Unity 导表、编译或 Play Mode 通过。

## G53 新增字形清单

每次工作簿导出都会在输出根目录生成 `新增字形清单_yyyyMMdd.txt`。报告明确列出基线 `Localization.csv`、比较输入、发生变化的 `loc_key`、相对基线新增的去重 Unicode 字符及其来源 key。报告只供 MIG-F09/字体保护复核；工具不会修改任何字体、材质或其它 `Assets/**` 文件。

## 回归

```powershell
powershell -NoProfile -ExecutionPolicy Bypass -File DevTools/DataTables/Test-Authoring.ps1
```

回归在系统临时目录建立状态副本，覆盖 14 sheet、冻结/着色/引用辅助、规范化字节往返、重复导出幂等、空 sheet 不覆盖、G53 新字形与共享校验器；不写权威 CSV。
