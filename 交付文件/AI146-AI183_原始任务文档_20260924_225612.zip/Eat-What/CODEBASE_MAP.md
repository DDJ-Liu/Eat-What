# 《是啊，吃什么》代码结构与修改导航

2026-09-24 17:30 用户改为手动诊断：已正式 ExitSupervision，当前 MANUAL / PAUSED_MODE，stopRequested、exitRequested=true，原 ai 保持 PAUSED。仅诊断，不修复/回退/重试/派发。已用不保存的材质副本复现 FromHeavy 的 TMP ScaleRatioA/B/C 重算导致指纹失效；回退在复制备份前被同一材质守卫拦住。40 条 kern 非目标 override 来源已定位为旧字段加载转换及保存结构保护缺口，另有 ROLLBACK_FAILED 重入条件的源码推导，未执行重入。失败现场24文件及字体/CSV10文件本轮SHA不变，部分保存状态尚未恢复；原错误/恢复史和人工结论不改。详细报告：`.ai-workspace/outputs/control/U1-PRE-R1-20260923/manual-diagnosis-20260924/AI170失败原因定位报告.md`。下方较早接力均为历史，不构成新的执行授权；本条专项核验不提升完整复核日期。

2026-09-24 PRE-1c-META-GUARD-R1专项（不更新完整结构复核日期）：AI183 将 `ShortCycleFontSwapTool` 升为schema10，并以生产/测试共用的 `BuildApplyingBatchRecord`、`BuildBatchStageMutationPolicy`、`EvaluateApplyingStageSnapshot` 收口阶段变更范围。选中场景/Prefab仅有资产内容的 `MODIFY_EXISTING` 规则，其既有meta、未选中资产和批准输入不再放行；三份固定材质及meta仅在首个创建批次从缺失转存在，创建后记录GUID/资产SHA/meta SHA，后续不可继续修改。同名已有材质拒绝；必要时新建的Materials目录另记GUID/meta SHA并检查精确内容，回退只在自有内容删除后安全删空目录。稳定/`APPLYING`回退均重建同一策略并核契约SHA，之后才核14项备份并恢复。真实Unity6/TMP DLL编译与隔离生产策略反例通过，生产场景/Prefab/材质/CSV写入0；AI183准入检查通过后，AI170真实全量批次及回退已失败；当前停止现场见下方最新段。AI182停止详情继续保留于 `.ai-workspace/outputs/control/U1-PRE-R1-20260923/AI182控制审查停止与全队列未关闭清单.md`。

2026-09-24 PRE-1c-TRANSACTION-CONTRACT-R1专项（不更新完整结构复核日期）：AI182 将 `ShortCycleFontSwapTool` 升为schema9。Preview、双轮诊断和事务逐行检查共用同一三态证据构造/分类；诊断schema4不仅比较两次加载，还逐行与计划中的40场景窄解释、8源窄解释及其余正常态对照，两个相同但共同错误的pass也拒绝。不可变批准/备份原SHA与事务当前阶段SHA分离：每批修改前核`expectedFiles`并持久化`APPLYING`身份/前快照/允许文件，保存后只接受选中资产和首次自有材质的受控差异，逐行验证后才推进阶段；同文件其余待办行不再被原始整文件SHA误拒。公开回退先证明稳定阶段或`APPLYING`部分态归属，再核14项manifest/备份内容，最后byte-exact恢复7资源/meta并重验231行/冻结SHA；未知非目标、override、meta/外部文件、日志或备份漂移复制前失败关闭。真实Unity6/TMP DLL编译及隔离40/8/183、同文件身份、阶段/备份篡改、多批/传播/失败回退回归通过，生产写入0；仍需控制台重新运行schema9只读Preview/诊断和审查回退方案，AI170未Recover。

2026-09-24 PRE-1c-SAVED-STATE-R1专项（不更新完整结构复核日期）：AI181 将 `ShortCycleFontSwapTool` 升为schema8，批准CSV观察、精确磁盘保存raw与Unity加载effective三态不再互相回填。保存override由资产GUID+组件fileID+PrefabInstance磁盘modification解析，内存`prefabOverride/GetPropertyModifications`仅记录加载派生证据；精确40个Tray场景行与8个源Prefab行分别使用窄范围解释，8源目标仍`FromLegacyShortCycle`。计划/事务冻结7资源及meta批准SHA，Begin重验且批间继续用阶段快照；回退改为核验manifest后byte-exact恢复批准资源/meta、同步导入并重验231行和SHA，防止TMP生命周期把默认材质误保存。真实Unity 6000.3.24f1/TMP DLL编译与隔离231行/7资源/分批/失败回退回归一次通过，生产资源写入0；下一步仍是控制台只读新版Preview与双轮诊断，AI170未Recover。

2026-09-24 17:16 最新停止状态：AI170第7次执行真实失败，full事务ROLLBACK_FAILED、第一批APPLYING，原7错误/6issue/6恢复完整保留。单FromSourceHan样例1项已成功并回退，但全量第一批FromHeavy新材质出现OWNED_MATERIAL_DRIFT且公开回退同样失败；不能称零写入或已恢复。控制台只读核实两场景SHA已变、五Prefab与7个既有meta不变，三新材质保留，其中FromHeavy内容SHA与创建记录不同；主场景另有40条新增m_ActiveFontFeatures.Array.data[0] override待归属核验。正式备份和样例快照各14文件均匹配，失败现场另保全24文件。17:20主Editor单ShortCycle/Edit/clean/Console0仅表示无未保存脏场景，不代表磁盘已回基线。session CIRCUIT、stopRequested=true，原ai已PAUSED；CODE/ENGINE均idle，不Reconcile放行、不派发、不追加补丁/Reset/换key绕最后额度。原批准有效，需用户明确新的现场诊断与受控恢复范围，不能自动继续全量迁移。详细报告outputs/control/U1-PRE-R1-20260923/AI170第七轮失败现场与全队列未关闭清单.md；AI171/172等待，DATA已验保持，人审/Git/E2条件不变。

2026-09-24 PRE-1c-LAB60专项：AI177已在同一 `ShortCycleFontSwapTool` 增加独立Lab60映射/批准旁证重载；不传补表时原171模式不变，传入时以两个固定SHA组成231行、两个场景+五Prefab共7资源及meta的schema4事务。预检逐项锁定Lab的FridgeSlot源关系、font继承/material override结构，实例先于源，未批准传播仍熔断；备份/文件快照覆盖7资源，两个场景仅暂开且恢复原活动场景，已加载dirty场景拒绝覆盖。真实Unity6/TMP DLL编译与双场景离线事务回归通过，生产序列化写入0；真实unique/executeAllowed、材质创建、样例/全量迁移和画面仍由恢复后的AI170/人工验证，不能用合成231 unique代签。原171与Lab60 CSV均未改，AI170失败/恢复史保留；本段不更新完整结构复核日期。

2026-09-23 空间反馈修复专项：现行自有MouseInteract/世界Sprite按钮保留；AI168新增通用 `Assets/Scripts/Tools/Layout/CameraViewportAnchor.cs`，用显式Camera/viewport/inset/世界平面在CameraPan后同帧移动视觉+Collider共同根，无Find/Camera.main，并从PresentationSet世界bounds排除锚定控件。AI169已通过Editor在ShortCycle_P0P1接入Escape/Return两个按钮，viewport=(0.06,0.08)，仅Shared/ClueBoard_Group开启`KeepVisualActiveAcrossSpaces`；focus/StateGate/InteractionLayer/Modal/输入锁仍独立门控。当前marker X为P1=-25.6、P0Left=-9.6、Center=0、Right=25.6，Kitchen=-25.6、Tray.localX=0；全书/右页可见比例实测66.88%/33.76%。两轮P0-P1-P0、Modal和整猫六层滚动回归通过，最终Edit/clean、Console Error=0，16:9/4:3最终画面仍PENDING_USER。LayoutAudit旧P0Left=-12.8断言已登记为过时诊断，AI171修正工具、AI172真实Editor复验，不能将当前整份审计宣称全绿。实际坐标、7图及场景SHA见[AI169报告](.ai-workspace/outputs/U1-PRE-R1/AI-000169/AI-000169_FIX-T5-R1b_完成报告.md)。PRE1正式迁移AI170只读预检报8组CANONICAL_CONFLICT（171批准行、63有效计划项），零生产写入；AI176已在纯代码边界修复Prefab源/实例身份、不同材质目标、传播顺序和override结构回滚，仍须由ENGINE重新预检，不能沿用63项或用离线171唯一项代签。不得以错误去重数缩小批准行或跳过冲突。完整结构复核日期不变。

最后结构一致性复核：2026-09-17。范围：源码入口、Build Settings、Packages、关键 Scene/Prefab/生成数据、Resources 路径和 Git 差异；Unity 只读确认正式 P0 编辑态、场景 clean、Console Error=0。本次运行既有离线回归，不重做全项目 Play Mode；本轮视觉与交互沿用已落账的用户验收。

最后专项核验：2026-09-22（MIG63 E1/H及MIG-F06）。用户确认37bb854人工终验通过，main与unity6.3-baseline已集成同一候选，backup保持起点。原工作区content已在6000.3.24f1完成H接棒，TMP84/LFS、9组离线、5组Play及4项长期探针通过，业务冻结解除。其后独立定向重序列化处理3场景/11Prefab，仅3场景有磁盘变化；7934项对象/设置记录一致，meta/GUID、旧参考场景和字体未变，格式更新后的5组Play与Windows构建通过。用户本轮批准将H后格式提交及记录集成main，关闭旧content并从新main建立codex/unity6-followup；主控制台承接F/E2，E1标签不动。详情见[E1/H报告](.ai-workspace/MIG63/E1H_接棒与后续项.md)。完整结构复核日期仍2026-09-17，未新增全项目人工视觉验收。

本文件记录当前结构。整理前逐次变更与失败/恢复记录完整保存在 [.ai-workspace/archive/2026-09-17](.ai-workspace/archive/2026-09-17/README.md)，不再将历史状态堆在页首。完成度和下一轮边界见[项目基线](项目整体阅读理解与推进基线_2026-08-14.md)。

2026-09-23 工作流导航专项（不改完整结构复核日期）：共同规则入口为 [.ai-workspace/CORE.md](.ai-workspace/CORE.md)；完整队列/监管/控制协议在 `.ai-workspace/protocol/`；坑编号从 `.ai-workspace/pitfalls/INDEX.md` 进入四车道正文；工具编号从 `.ai-workspace/toolkit/INDEX.md` 进入 INT/MOT/LAY/RND/DAT/LOC/DBG/CMD/WF 域。旧 `KNOWN_PITFALLS.md`、`TOOLKIT_REGISTRY.md` 和三份协议根路径保留兼容入口。活动 `INSTRUCTIONS.md` 与 `runtime/` 不参与归档瘦身。

2026-09-23 PRE-1 CODE 专项（不改完整结构复核日期）：新增 `Assets/Editor/Fonts/ShortCycleFontAtlasBuilder.cs`，从历史字体实际216字符与 `Localization.csv/zh_cn`（项目CSV parser）计算当前338字符联合集合，目标资产路径为 `ShortCycle_Heavy_Static.asset` 与 `ShortCycle_Heavy_DynamicFallback.asset`，链为 Static→DynamicFallback→现SourceHan且不改TMP全局回退。`ShortCycleFontSwapTool.cs` 保留原显式白名单只读/仅字体兼容入口；AI167新增批准CSV+用户旁证双绑定的配对迁移入口，按asset/object/component精确读取并区分Prefab源、实例继承和override做真实写入身份去重，先全量校验font/material/非目标指纹，再复制三份旧材质风格且仅替换四个atlas属性，成对写`m_fontAsset/m_sharedMaterial`，并提供六资源+meta备份、事务记录、部分失败回退和幂等显式回退。`ShortCycleLayoutAudit` 新增Spaces字体逐路径断言；`DevTools/Fonts/Test-ShortCycleFonts.ps1`、`Test-FontSwap.ps1` 和 Verify-All `Fonts` profile使用Unity 6000.3.24f1真实DLL编译并运行隔离事务夹具。AI162已通过Editor生成双字体及meta：Static GUID=9b07c6c50dde09d4b8719754c27ddc96，337实际glyph覆盖338需求（含TMP内建换行），Dynamic为空，manifest仍PENDING_REVIEW；用户随后批准171项、三材质、5Prefab与CoverTitle精确增量。AI167生产迁移仍为0，真实Editor去重数、材质创建、正式引用迁移、Play/Build与最终画面由后续ENGINE/人工阶段完成，不能用离线夹具代签。

2026-09-23 PRE-1b-R1 补充：AI173 在同一 `ShortCycleFontSwapTool` 核心增加公开 `BeginApprovedMigration`、显式 `ApplyApprovedBatch` 与 `FinalizeApprovedMigration`。ENGINE 可从真实全量计划选择 `approvedRowIdentities.Length == 1` 的单引用样例，再用独立事务按批推进；每批前后核验全部待办/已完成身份、非目标指纹和输入/资源文件快照，相同 batchId+相同集合恢复为零写入，非法身份/重复选择零写，批失败执行全事务回退。兼容一次性入口也走 Begin→全量批次→Finalize。Verify-All 子 runner 改为正常 PS7 `-NoProfile -File`，不再强制绕过 ExecutionPolicy；真实 Unity/材质创建/序列化写入仍由 AI170 执行，本卡生产写入0。

2026-09-24 PRE-1c-PREFAB-R1 补充：AI176 将批准行的实际写入身份与 Prefab 源关系分离；只有源行存在、实例无对应字段 override、迁移前引用相同且批准目标对也相同才折叠。目标不同或真实 override 的实例独立保留，并要求实例先于源 Prefab 写入；事务 schema 3 冻结全部171行、源关系、before/after、override结构和依赖资产传播 guard，未批准继承传播在建事务前熔断。每批逐行校验未知/待办/既成状态、非目标指纹和关系稳定性，回退恢复精确引用及原 override 结构。真实 Unity6/TMP DLL 编译和隔离事务回归通过；本卡未打开Unity，生产场景/Prefab/材质写入0，AI170后继仍须重新只读预检、样例回退和正式分批执行。

2026-09-20 资产清理专项核验：用户确认 CookingPrepare 已弃用，现有 Build 列表仍保留该场景，本次未调整发行入口。已从 Resources/Customer、Resources/DialogSystem/TestDialog、Sprites/Cooking/Customer 删除 14 张已确认的第三方游戏角色图及 meta；TitlePage、DialogManager、DropDown 三个 Prefab 的对应图片引用/对象名已清理。StreamingAssets/Dialog.dat 保留 TestDialog 表名，内容改为单行中性测试（Uid=1、DefaultNextUid=-1、无角色图片/选项）；两组 TestCustomerPlaceOrder 表不变。旧 E 盘 Dialog.xlsx 不属于本次工程清理范围，再导入前须同步去除旧测试内容；可审阅的当前数据见[Dialog.cleaned.json](.ai-workspace/outputs/control/资产转让审查_20260920/后续清理/Dialog.cleaned.json)。当前 ShortCycle P0/P1 入口与运行架构未改；核验范围和残留扫描见[处理记录](.ai-workspace/outputs/control/资产转让审查_20260920/后续清理/处理记录.md)。

## 1. 工程入口

| 项目 | 当前事实 |
| --- | --- |
| 引擎与渲染 | Unity 6000.3.24f1、URP 17.3.0；原工作区H接棒通过 |
| 输入 | 本迁移分支Input System 1.20.0、Uniform；MIG-F01源码已统一滚轮单位并移除Windows `×120`桥接，Play/真实硬件仍待本批验收 |
| 当前 Build 列表 | ShortCycle_P0P1 index0、CookingProcess index1，Profile不覆盖，Prepare文件保留；原目录已同步 |
| 本轮开发/验收入口 | Assets/Scenes/Cooking/ShortCycle_P0P1.unity；两目录均已加入Build；原目录H通过、冻结解除，后续开发在codex/unity6-followup分支 |
| 视觉统一试验 | Assets/Scenes/ToolTests/VisualEffectsLab.unity |
| 滚轮独立试验 | Assets/Scenes/ToolTests/FridgeScrollLab.unity |
| 盘点 | Assets/Scripts 249 个 C#；Assets/Editor 63 个 C#（含4个保留迁移验证文件）；Assets/Scenes 15 个场景；Prefabs/Resources 共 71 个 Prefab |
| 配表 | 14 个 schema；Assets/Generated/DataTables 实际 122 个 asset（含 catalog、共享资源） |
| 程序集 | 项目主要使用默认 Assembly-CSharp / Assembly-CSharp-Editor；第三方程序集另计 |
| 验证 | DevTools 离线编译/契约测试、Unity 场景探针和人工验收；Assets/Tests 当前为视效夹具，不等于已有 NUnit 测试程序集 |

Packages清单/锁文件及LocalPackages/com.coplaydev.unity-mcp固定Editor包进入版本管理。DevTools/MCP记录服务端10.1.2、源码提交和uv锁文件；Editor为同提交10.1.3-beta.4，迁移目录6.3连接与实例路由已实测。自动客户端改写已用10文件本地补丁关闭；主动Configure仍可用，未提供完整服务端离线镜像。详见DevTools/MCP/README.md。原目录H接棒已恢复相同本地包及独立venv，新实例Eat-What@d5759c75ae7cb5de连接/路由通过；本轮验证服务收尾停止，未来使用重新发现实例。

以上版本表指已验收E1基线及已经完成H接棒的原工作区。独立Eat-What-U6副本已导入6000.3.24f1：URP17.3.0、Input System1.20.0、UGUI2.0.0、Cinemachine2.10.7；Coplay已收敛为工程内固定包；M4连接MIG、H重新发现并验证原目录实例，原队列未接入。API Updater把HorizontalPlayerController.cs与QuickAddForce.cs的Rigidbody2D.velocity改为linearVelocity。M2已保存Compatibility=false、无兼容宏，Windows构建通过；TMP目录已升级为84文件，M3R按N1取消忽略并随Git/LFS跟踪，保留原GUID和快照。精确变化和人工复核见[M2/M3执行结果](.ai-workspace/MIG63/M2M3_执行结果与人工验收.md)，原目录H运行回归已通过，H后格式更新已按用户最新决定随本次集成进入main；unity6.3-baseline标签保持37bb854，新业务使用codex/unity6-followup。

迁移侧验证工具变化：DevTools/Rendering/Test-OutlineMerge.ps1、Test-EtherBubbleDistortion.ps1、DevTools/ShortCycle/Test-CK01CShortCycle.ps1及CoordinateSpaceRegression/Invoke-CoordinateCompilation.ps1按项目版本定位Hub/旧Editor；泡泡测试引用URP17的2D.Runtime程序集。H磁盘接棒已同步这些工具，九组离线回归通过。原临时验证链已移除；本轮按用户决定长期保留迁移侧Assets/Editor/MIG63Validation/MIG63WheelProbe.cs、MIG63TomatoProbe.cs、MIG63SpineSceneProbe.cs和MIG63ValidationSession.cs，菜单Tools/MIG63/Validation，说明DevTools/MIG63/README.md。两侧新增DevTools/GitHooks字体工作树/index保护，最终机器结果不覆盖硬件鼠标和同分辨率全视觉对照。

引擎迁移须同时检查Assets内依赖：Spine 3.8（2021-11-10）、Text Animator 2.3.1、NuGet/EPPlus及MCP相关DLL。旧链CookingPhaseState.cs、CameraFollower.cs使用Cinemachine 2 API；自制视效通过相机回调及离屏RT调度，Renderer2D的Renderer Features为空。当前执行依据为[MIG63迁移基线](.ai-workspace/MIG63/迁移基线.md)，不沿用历史6.6候选评估作为目标。

Spine保护范围：Assets/Scenes/Spine Sample.unity和Assets/Scenes/ToolTests/HorizontalPlayerControllerTest.unity。M4在这两处保留原Prefab/对象身份，使用场景override绑定现有Tomato 3.8.99；动画控制器为Avatars/Tomato/Tomato_MIG63.controller（idle/walk/kick，Idle/Walk/Kick触发器）。三个SkeletonMecanim的MeshRenderer磁盘均为禁用，由已有SpineRuntimeMeshRendererBootstrap在Start启用，避免场景恢复旧网格产生Invalid worldAABB。CharacterEquipment采用Tomato_Non和7部位；Sample的Bottom槽保持Test_EquipBottom按钮契约。HorizontalPlayerController保留Rigidbody2D移动和Animator路径，spineAnimation仍为空；另一SkeletonAnimation用法由长期Tomato双路径探针覆盖。旧Sample/output4 3.8.75及Prefab/runtime/Shader未覆盖或删除，直接读取旧骨骼仍是已登记历史缺陷。ShortCycle/两个Lab不依赖Spine。保存场景与双路径GPU通过并不表示全部皮肤、混合模式或重打包均验收。

迁移侧滚轮专项：`Assets/Scripts/MouseInteractive/MouseManager.cs` 直接累计Input System统一滚轮单位，冷却期最多保留一步，目标/层/失焦时清理，冷却使用unscaled time；Windows专用`×120`桥接已在MIG-F01移除。手感参数来自T8 `fridge_scroll_threshold`（缺失/非法默认1）与`fridge_scroll_cooldown`（缺失/非法默认0.2秒），由`CK01GeneratedDataCatalog`按invariant culture解析，再经`ShortCycleSessionManager.Start → MouseManager.ConfigureScrollInput`单一路径应用，FridgeScrollLab不设旁路。配置人员入口见[区域滚动说明](组件说明文档/区域滚动_配置与复用说明.md)。本轮源码/静态验证完成，生成资产刷新、Play与Windows/Mac真实硬件手感由后续F3/F4及人工验收完成；旧2022回退基线不用于打开已接棒目录。Windows API保持D3D11优先/D3D12第二，Auto=false。

2026-09-23 FIX-T5 专项：`ShortCycleCameraPanController` 的原三槽序列化值保持不变并扩为 P1/P0Left/P0Center/Right；`ShortCycleSpace.viewTable[].cameraSlot` 决定 Phase0 子视图目标槽。Director 仅在目标槽变化时复用既有 Pan/输入锁/generation，Pan 完成后才激活目标视图；同槽 ①↔④ 不产生 PanStarted。Set 的逻辑激活再与正交相机世界矩形、缓存的子 Renderer 世界 bounds 并集相交，无 Renderer/无可用相机均保留逻辑可见并只发节流诊断。AI168增加TK-MOT-14 `CameraViewportAnchor` 和显式 `keepVisualActiveAcrossSpaces`：锚定控件Renderer不参与世界bounds；持续结构绕过相机裁切导致的逻辑Deactivate，但焦点与交互仍单独关闭，普通Set/Modal默认行为不变。AI156 已完成原正式场景接线：四 Marker 的 x=-25.6/-12.8/0/25.6；线索板两锚点同为(-19.2,-2.1168,-0.3)，Shared/ClueBoard_Group/ClueBoard_HitArea 复用鼠标动作/状态门控，旧实体按钮退役。AI165的④书页压暗和板外返回保持；后续AI169已完成ClueBoard持续标志和两个返回按钮viewport(.06,.08)接线，P0Left改为-9.6，并通过连续构图/Play机器回归，最终多宽高比画面仍PENDING_USER。上列-12.8为AI156历史值，不是现布局。配置入口见[镜头视口锚定说明](组件说明文档/镜头视口锚定_配置与复用说明.md)。CoverTitle例外及171行、Lab60迁移范围已由用户批准；正式字体执行当前等AI179修复后恢复原AI170，最终视觉不代签。

## 2. ShortCycle 当前主链

```text
InputManager → MouseManager → MouseInteractionLayer 栈顶
→ MouseActionBinding / ShortCycleActionRouter
→ ShortCycleSessionManager → ShortCycleStateMachine
→ IShortCyclePresentationHost → ShortCyclePresentationDirector
→ Space / PresentationSet / Modal / Traveler / Tray / CameraPan
```

源码以 `Assets/Scripts/Cooking/ShortCycle/` 为根：

| 功能 | 文件/目录 |
| --- | --- |
| 会话入口与运行数据 | ShortCycleSessionManager.cs、ShortCycleContext.cs、ShortCycleRuntimeManagers.cs |
| 三相/Phase0 子态、托盘状态 | ShortCycleStateMachine.cs、ShortCycleTrayStateMachine.cs |
| 具名动作与命令桥 | ShortCycleActionRegistry.cs、ShortCycleActionRouter.cs、ShortCycleCommandBridge.cs |
| 表现编排 | Runtime/ShortCyclePresentationDirector.cs |
| Space/Set/Traveler | Presentation/ShortCycleSpace.cs、ShortCyclePresentationSet.cs、ShortCycleTravelingElement.cs |
| 冰箱/线索板内容绑定 | Content/ShortCycleFridgeBinder.cs、ShortCycleClueBoardBinder.cs |
| 整猫与层级池 | Presentation/FridgeCatRig.cs、FridgeCatTier.cs、FridgeCatEye.cs |
| 镜头与层栈 | ShortCycleCameraPanController.cs、ShortCycleInteractionLayerStack.cs、ShortCycleInputLockController.cs |
| 滚轮物理入口 | Interaction/ShortCycleScrollAdapter.cs |
| P2 交接 | ShortCycleContracts.cs、ShortCyclePhase2HandoffPresenter.cs；TransitionAdapter 定义于 SessionManager.cs |
| 人工/自动验证 | ShortCycleManualVerificationDriver.cs、ShortCycleAutomatedProbe.cs、Debug/ |

Session 初始化顺序：Catalog 校验 → FridgeBinder.Bind → 无菜谱时跳过线索板绑定 → 本地化刷新 → FSM Enter；选菜成功后再绑定业务内容。默认菜谱调试开关不等于正式自动选菜。

跨 Space 或 P0 子视图目标槽不同时调用 CameraPan 并持有输入锁；Cover/RecipeCatalog 解析到 P0Center，RecipeBrowse/ClueBoardShell 解析到 P0Left，同槽切换同步完成且不发 PanStarted。当前正式曲线为 2-key Linear、0.45 秒；空曲线源码回退为线性，中途返向从真实当前位置重新发起，取消请求不晚到写回。跨 Space 进入带 View 路由的 P0 时由随后 ShowView 一次性确定最终槽，避免 P0Center→P0Left 重复移动。

Cover 隐藏旧书底/展开页；Catalog/Browse 恢复；目录签只在 Browse 显示；CurrentRecipeTab 保持 Browse-only。Scene 的唯一 Host 是 Managers/PresentationDirector；旧 Presenter/Builder 兼容实现不能替代此入口。

## 3. 冰箱与通用滚动

```text
MouseManager → MouseScrollableObject → ShortCycleScrollAdapter.MapPhysicalStep
→ ActionRouter → Session → FridgeBinder → FridgeCatRig → ScrollArea_Controller
```

- 正式 P0 的 ScrollRegion 启用 Invert Physical Scroll Direction；业务 Dispatch(+1)=下一层、(-1)=上一层不变，Lab 保留独立参考方向。
- 滚轮手感配置链为 `CookingGameConfig CSV/schema → CK01GeneratedDataCatalog.ResolveFridgeScrollSettings → ShortCycleSessionManager.Start → MouseManager.ConfigureScrollInput`；解析使用invariant culture，缺失/非法值逐项回退并告警。
- 绑定/重绑按 ceil(容量/5) 设置层数；demo 容量30，对应6层/30槽。正数量库存紧密绑定，真实初始库存10项。
- ApplyFilterView(visibleCount) 提供 max(1,ceil(visibleCount/5)) 契约与测试；本轮生产调用方仍未接入，shortcycle.fridge.filter 仍属后续段的桩。
- 源 Prefab：Assets/Prefabs/Cooking/ShortCycle/FridgeCat/FridgeCat_Rig.prefab；格件：Assets/Prefabs/Cooking/ShortCycle/GridPieces/FridgeSlot.prefab。
- VisualContent_TUNE 包含整猫视觉、层、双眼与随动装饰。运行时挂到 ContentArea_TUNE；ScrollController/Viewport/TierAlignmentTarget 与场景 ScrollRegion 固定。
- AnchorAlignedAutoBounds 使用真实 Anchor 计算层目标和边界；不可只靠层索引断言实际可见。
- 当前场景后15个数量标签经过 AI145 实例修复；源 FridgeSlot 默认值与已修场景覆盖并不相同，不可盲目 Revert 到源 Prefab。
- 通用组件位于 Assets/Scripts/MouseInteractive/ScrollArea/ScrollArea_Controller.cs、Drag/DragContainer.cs、Drag/DragLimit.cs；可独立复用，冰箱业务适配器是可选桥接。

配置入口、参数与探针操作见[区域滚动说明](组件说明文档/区域滚动_配置与复用说明.md)、[整猫说明](组件说明文档/视觉特效/冰箱猫整体滚动_配置与使用说明.md)。FridgeScrollLabDriver 的 SIMULATED 只调 Adapter，不伪造硬件事件；真实鼠标验收已由用户通过。

## 4. 数据与本地化

- 权威 CSV：DataTables/Cooking、DataTables/Localization；schema：DataTables/Schemas。
- CK01 业务规则已到 v2.4；JSON 中 schemaVersion=2 是格式版本，不应机械改成 2.4。
- 导入入口：Assets/Editor/DataTables/DataTableImportService.cs；人工菜单为 Tools > Data Tables > Import All，无 UI batch 入口为 `EatWhat.DataTables.DataTableImportService.ImportAllBatch`，失败写 `[DATA]` 并返回非零。
- 唯一聚合入口：Assets/Scripts/DataBase/CookingData/CK01GeneratedDataCatalog.cs；资产 Assets/Generated/DataTables/CK01GeneratedDataCatalog.asset。
- 生成目标位于 Assets/Generated/DataTables；静态 CK01 类型位于 Assets/Scripts/DataBase/CookingData/CK01*.cs。
- CookingGameConfig 中 unknown_product_item=prd_unknown，demo_fridge_capacity_level=fcap_lv2；Catalog 解析实际容量30，getter 不设静默兜底。滚轮T8键为`fridge_scroll_threshold=1.0`、`fridge_scroll_cooldown=0.2`；旧granularity/damping已退出当前CSV/schema，F4导入后须确认旧生成资产与Catalog引用无残留。
- RecipeSlots 保留 standard_action + sub_01～08 及对应数量；序列化改动须保持兼容。KitchenAreas 既有路径和字段合同保留。
- 本地化资产/服务：Assets/Scripts/DataBase/Localization/；组件入口 Assets/Scripts/Tools/Localization/LocalizedText.cs。
- 长期回归夹具位于 DevTools/DataTables/Fixtures/；不得再让测试依赖临时 AI inputs。
- DATA 调度与轮次入口：`.ai-workspace/workers/DATA.md`、`queue.ps1 -Action RegisterDataLane/DataLaneStatus/BindDataPipeline/ConsumeDataRound`。旧注册 worker 兼容 `CONTROL_SUBAGENT/null`；控制台提供应用可达/闲置证据后把同一 worker 原子绑定为 `THREAD`/固定可见任务，routeRevision 防止旧票据跨路由，绑定损坏拒绝回退。2026-09-23 23:24控制台正式读回THREAD/01a0ce9d-8e5a-7542-82b6-6d27609d99e0/revision1；2026-09-24控制台核实AI175 SUCCEEDED/VERIFIED，实际票据领取、检查点、Complete及原样handoff闭环，6范围452文件0差异，端到端验收完成；未导表/发布或写用户DONE。导出先写 EXPORTED，`DevTools/DataTables/Set-U1RoundStatus.ps1` 显式写 DONE 后才能幂等入队；CODE 维护工具/schema/源码，DATA 执行轮次，ENGINE 只做拆出的 Unity 接线/验证。
- 隔离导表入口：`DevTools/DataTables/Run-DataPipeline.ps1`，固定调用 `EatWhat.DataTables.DataTableImportService.ImportAllBatch`，后者复用 ImportAll 并接 PRE-1 `ShortCycleFontAtlasBuilder.BuildAll`。共享全程锁、输入/源/目标哈希冲突、绝对路径边界与保全式回滚在 `DataPipeline.Common.ps1`；工作区固定为忽略的 `DevTools/DataTables/.batch-workspace/`。正常 DATA-Rn 仍须 USER-U1 DONE；显式 `-CurrentCsvValidation` 仅用于已授权首跑并强制禁止发布/写DONE，可选 overlay 只改隔离 CSV。
- 2026-09-23 PRE-2b CODE 核验：`Test-BatchImport.ps1` 的45项离线断言覆盖准备/备份/交换/回退失败、源/目标漂移、零变化不重写和仅一项生成物变化；`Test-DataLane.ps1` 36项与导入器21源静态编译通过，生产CSV/生成物/字体哈希不变。这里只证明源码和编辑器外状态机，不声称 Unity batch、字体资产重建或 Play 已通过；真实首跑仍归 DATA AI-000164。
- 2026-09-23 AI164真实首跑：`Invoke-DataBatchCommand` 对Windows GUI Unity.exe未显式等待，实际隔离进程仍运行时已写SUCCEEDED/0并释放锁，故首跑未通过。只中止自建隔离PID，主Editor仍响应且5,715受检文件零变化。需CODE修正进程等待/退出码/完成凭据，再由DATA复验；[证据与修复清单](.ai-workspace/outputs/U1-PRE/AI-000164/AI-000164_PRE-2b_首跑阻断与修复接力.md)。
- 2026-09-23 AI166修复专项：`DataPipeline.Common.ps1` 改用明确 `System.Diagnostics.Process` 句柄隐藏启动、等待真实退出并从该句柄取码，超时只终止本次进程树；锁覆盖退出与凭据校验。`ImportAllBatch` 只在导表和 `BuildAll` 均成功后于隔离工程内写唯一runId/nonce凭据，Runner验证新鲜时间、字体manifest与项目 `DataTableCsvParser` 的238字形结果后才登记API执行；报告分列可空 `batchProcessExitCode` 和 `runnerExitCode`。输入快照改为与复制一致的 `Assets/Packages/LocalPackages/ProjectSettings/DataTables` 五根。65项离线回归含真实 Windows GUI 延迟非零/超时归属清理/成功/缺失与旧凭据、锁持续/释放；未启动 Unity，AI164仍须由DATA恢复真实复验。[AI166修复报告](.ai-workspace/outputs/U1-PRE/AI-000166/AI-000166_PRE-2b-PROCESS-R1_修复报告.md)。

导表会校验后再写资产；新增/替换美术先比对和审批最终命名路径，再由 Unity 导入，保留 GUID 和引用。数据验证通过不等于所有未来业务链已实现。

2026-09-23 AI164最终恢复核验：此前[受限宿主许可失败](.ai-workspace/outputs/U1-PRE/AI-000164/user-retry-20260923/AI-000164_用户重试与宿主许可阻断.md)保留；两个精确启动分别通过正常宿主正式审批后，Unity0/Runner0及独立nonce均通过。baseline生成目录261文件零差异；overlay只有Localization.asset一项变化，catalog和meta/GUID不变。两个catalog均14表/120有效引用，238字形，Static未重写；主五根5722文件SHA及当前测试场景clean保持。未Publish/未USER-U1 DONE，不代过字体审批。零diff时Runner缺空JSON文件的非阻碍观察已留WARNING并用独立manifest补证。详见[正常宿主两用例报告](.ai-workspace/outputs/U1-PRE/AI-000164/host-context-recovery-20260923/AI-000164_正常宿主两用例通过报告.md)。

## 5. 描边、阴影与泡泡

| 功能 | 源码入口 |
| --- | --- |
| 正式描边参数 | Assets/Scripts/Rendering/SpriteOutline2D.cs、SpriteOutlineGroup2D.cs、SpriteOutlineDefaults.cs |
| 合并后端 | Assets/Scripts/Tools/Rendering/SpriteOutlineMergeRenderer2D.cs、SpriteOutlineMergeMember2D.cs |
| Shader | Assets/Shaders/2D/ |
| 泡泡折射与池 | Assets/Scripts/Tools/Rendering/SceneColorCapture2D.cs、EtherBubbleDistortion2D.cs、EtherBubbleEmitter2D.cs |
| Lab 驱动/装配 | Assets/Scripts/Tools/Debug/VisualEffectsLabDriver.cs；Assets/Editor/VisualEffects/；Assets/Editor/Rendering/ |

逐组像素 alpha 遮罩与显式离屏调度，组内 _MergedShadow/_MergedOutline 宿主参与普通排序；每组两张 RT，尺寸按包围盒和像素边距取8倍数，无成员级 RT。组阴影并集后使用组参数，ForceOff 使用本地；描边参与合并与参数来源是两种不同开关。正式 Outline Color 支持 HDR RGB 和 Alpha，Hover 恢复完整 RGBA。

配置与限制以[视觉特效说明索引](组件说明文档/视觉特效/README.md)为准。所有视觉改动先进入统一 Lab；保留现有探针、夹具与回归场景。

## 6. 旧 Build 链与其边界

旧链为 CookingPrepare → IngredientInventory/SceneSwitchManager → CookingProcess → CookingManager → Room/Container → Recipe 白名单 + RuleBook → InteractionController → CutDice/Stir。

主要目录：
- Assets/Scripts/Cooking/Prepare：PrepareIngredientManager、RecipeBookManager、FridgeManager。
- Assets/Scripts/Cooking/Cook：CookingManager、CookingDropZone。
- Assets/Scripts/Cooking/CookingRoom：CookingRoomManager、Container。
- Assets/Scripts/Cooking/Interaction：InteractionController、具体加工小游戏。
- Assets/Scripts/Cooking/IngredientInventory.cs：旧跨场景托盘库存。
- Assets/Scripts/Command、Dialog、DataBase：命令、对话与旧表格读取。
- Assets/Scripts/GridPlacement、Tools：独立网格、Transition、布局及路径工具。

ShortCycleDataHandoff 已携带 RecipeId 和 PrepZoneContents；当前 Phase2TransitionAdapter 仅发 Requested 事件，不代表已把 P2 生产场景、最终成菜、评分与变体保存全部接通。CookingManager 的 isFinal 分支仍只有下一阶段注释；onChooseRoom 仍只更新房间ID。旧问题不能因 P0/P1 阶段完成自动视为修复，也不能从旧报告直接建立新任务。

## 7. Resources 字符串契约

统一辅助入口 Assets/Scripts/Tools/Tools.cs。以下旧运行链契约仍须在重命名时检查：

| 用途 | Resources 路径 |
| --- | --- |
| 食材实体 | Ingredient/{IngredientData.name} |
| 加工控制器 | Cook Interaction/InteractionObjects/{ToolTag} |
| 容器/工具表现 | Cook Interaction/Container_Interaction/{ContainerTag}；Tool_Interaction/{ToolData.name} |
| 食材/结果表现 | Cook Interaction/Ingredient_Interaction/{name}_{ToolTag}；Results/{ProcessedIngredientData.name} |
| 菜谱详情/冰箱说明 | Prepare/RecipePage/{Recipe.name}；Prepare/FridgeIngredientList/{Recipe.name} |
| 命令默认绑定 | Command/DefaultCommandBinding.asset |
| 对话角色图 | DialogSystem/{dialogSheetName}/{characterName} |

这些字符串关系没有 GUID 自动重命名保护；目录存在不等于所有动态名称都能命中。关键资源变更需查调用方并在对应业务场景验证。

## 8. 验证与维护

- 数据：DevTools/DataTables/Validate-DataTables.ps1、Test-Validate-DataTables.ps1、Test-CK01BSchemas.ps1、Test-CK01BImportContracts.ps1、Test-BatchImport.ps1；真实 Unity batch 结果必须与离线回归分开记录。
- 短循环：DevTools/ShortCycle/Test-CK01CShortCycle.ps1；坐标空间另走 CoordinateSpaceRegression/Test-DragLimitCoordinateSpace.ps1。
- 视效：DevTools/Rendering/Test-SpriteOutlineShadow.ps1、Test-OutlineMerge.ps1、Test-EtherBubbleDistortion.ps1。
- 工作流：`.ai-workspace/tests/`；归档校验/查阅：`DevTools/Workflow/Archive-Stage.ps1`。任务用量入口为 `DevTools/Workflow/UsageMetrics.ps1`（队列生命周期写 `runtime/usage-YYYYMM.jsonl`）、`Initialize-TaskUsage.ps1`、`Invoke-TaskTool.ps1` 与 `Get-UsageReport.ps1`；不可见 token/model 必须为 null+原因。统一验证入口为 `DevTools/Verify-All.ps1`，按 Workflow/ShortCycle/DataTables/Rendering profile 去重调用既有 runner，中途仅增量解析，最终失败码向上传播。
- 离线测试不替代 Unity GPU、实际事件、生命周期与用户手感验收。源码修改后仍须 Compile/Console，序列化改动须先读现场、优先 MCP、复核差异和清理本任务临时变化。
- 历史未保存恢复点仅从归档提取到独立缓存；不覆盖当前生产资产。
- 新开发同步维护本文件、项目基线和适用组件说明；日常不再追加长篇过程日志到页首，过程证据写到任务输出并在阶段末归档。

H后待办归属：用户于2026-09-22选择 F-α；MIG-F04、MIG-F01、A0、A1从AI-000146起串行推进。客户端配置MIG-F03、E2功能命名MIG-F05、官方AI接口评估MIG-F07仍见E1/H报告；F-α之外不自动展开业务或清理副本。
